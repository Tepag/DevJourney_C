/*
programma che legge un numero num e visualizza tutti i numri pari e inferiori a tale numero

RECORD: 2m 34s
*/

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>

int main()
{
    int input = 0;
    int i = 0;

    printf("\ninserire numero di numeri di cui si vuole vedere i numeri pari e minori:");
    scanf("%d", &input);
    fflush(stdin);

    for (i = input; i >= 0; i--)
    {
        printf("\n%d", i);
    }

    return 0;
}