/*
programma che effetua il calcolo della media dei voti terminando con l'isnerimento di zero

RECORD: 3m 39s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float sum = 0;
    float cnt = 0;
    float input = 0;

    do
    {
        printf("insert your grade (0 for exit): ");
        scanf("%f", &input);
        fflush(stdin);

        sum += input;
        if (input != 0)
            cnt++;

    } while (input != 0);

    printf("\nyour average grade is: %.2f", sum / cnt);

    return 0;
}