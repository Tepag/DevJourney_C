/*
un programma che legge da tastiera una sequenza di numeri interi terminante con un numero negativo e al termine
stampa a video il numero dei numeri letti che sono maggiori di zero, minori e uguali

RECORD: 5m 48s
*/

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>

int main()
{
    int input = 0;
    int i = 0;
    int somma = 0;
    int limite = 0;
    int cnt_mag = 0, cnt_min = 0, cnt_ugu = 0;

    do
    {
        printf("\ninserire numero:");
        scanf("%d", &input);
        fflush(stdin);

        if (input > 0)
        {
            cnt_mag++;
        }
        else
        {
            if (input < 0)
            {
                cnt_min++;
            }
            else
            {
                cnt_ugu++;
            }
        }

    } while (input >= 0);

    printf("\nnumeri maggiori di zero: %d\nnumeri minori di zero: %d \nnumeri uguali a zero: %d", cnt_mag, cnt_min, cnt_ugu);
    return 0;
}