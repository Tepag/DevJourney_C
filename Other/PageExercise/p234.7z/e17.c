/*
programma che legge un numero in ingresso e lo converte in binario mediante successiva 
divisione per due

RECORD: 6m 37s
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 16

int main()
{
    int input = 0;
    int bin_arr[DIM];
    int i = 0;

    printf("insert number which you want to convert in binary: ");
    scanf("%d", &input);
    fflush(stdin);

    for (i = 0; i < DIM; i++)
    {
        bin_arr[i] = input % 2;
        input /= 2;
    }

    printf("\n\n");
    for (i = DIM - 1; i >= 0; i--)
    {
        printf("%d", bin_arr[i]);
        if (i % 4 == 0)
        {
            printf(" ");
        }
    }

    return 0;
}