/*
programma che legge una sequenza di numeri interi terminanti con uno zero e strettamente maggiori di zero e ne ricerca il valore valore 
minimo visualizzandolo sullo schermo

RECORD: 4m 12s
*/

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>

int main()
{
    int input = 0;
    int min = 0;
    int flag = 0;

    do
    {
        printf("\ninserire numero (0 per terminare):");
        scanf("%d", &input);
        fflush(stdin);

        if (flag == 0)
        {
            min = input;
            flag++;
        }
        if (input < min)
        {
            min = input;
        }

    } while (input != 0);

    printf("\n\nil numero minore inserito e\' %d", min);
    return 0;
}