/*
programma che effetua random il lancio di due dadi visualizzando i risultati

RECORD: 4m 20s
*/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

int main()
{
    srand(time(NULL));
    int dado = 0;

    dado = (rand() % 5) + 1;
    printf("\ndado 1: %d", dado);
    dado = (rand() % 5) + 1;
    printf("\ndado 2: %d", dado);
    return 0;
}