/*
un programma che gestisce un gioco di fiammifer: da un insieme n fiammiferi, a turno due giocatori ne tolgono un numero qualunque che vada da 1 a k
(dov3e N e K sono definiti a priori,; perde chi toglie l'ultimo fiammifero)

RECORD: 8m 06s
*/

#include <stdlib.h>
#include <stdio.h>

#define N 10 //tot fiammiferi
#define K 3  //massimo per turno

int main()
{
    int input = 0;
    int tot = N;

    do
    {
        //do while per assicurarsi che il giocatore del turno faccia la scelta nel range consentito
        do
        {
            printf("\ninserisci il numero di fiammiferi che vuoi togliere (max: %d): ", K);
            scanf("%d", &input);
            fflush(stdin);

        } while (input > K || input <= 0);
        tot -= input;

    } while (tot > 0);
    printf("\n\nhai perso");

    return 0;
}