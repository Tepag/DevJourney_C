/*
programma che effetua il prodotto tra due numeri con somme successive accettando solo numeri positivi

RECORD: 5m 58s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int input1 = 0;
    int input2 = 0;
    int prod = 0;
    int i = 0;

    do
    {
        printf("insert number: ");
        scanf("%d", &input1);
        fflush(stdin);

        printf("insert number: ");
        scanf("%d", &input2);
        fflush(stdin);
    } while ((input1 <= 0) || (input2 <= 0));

    for (i = input2; i > 0; i--)
    {
        prod += input1;
    }

    printf("\nthe product is: %d", prod);

    return 0;
}