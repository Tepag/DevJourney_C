/*
programma che effetua la somma dei numeri inseriti dall'utente fino a raggiungfere il numero 1000 e indica quanti numri sono stati sommati

RECORD: 6m 42s
*/
#include <conio.h>
#include <stdlib.h>
#include <stdio.h>

int main()
{
    int somma = 0; // la somma dei numeri
    int i = 0;     //il contatore fino a arrivare a 1000 e anche input da cui iniziare
    int cnt = 0;   //il contatore di quanti numeri sono stati sommatai

    printf("\n inserisci il numero da cui partire la somm: ");
    scanf("%d", &i);
    fflush(stdin);

    for (i = i; i <= 1000; i++)
    {
        somma += i;
        cnt++;
    }
    printf("la somma e\' di %d, sono stati sommati %d numeri", somma, cnt);
    return 0;
}