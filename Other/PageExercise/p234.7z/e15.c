/*
programma che legge due numeri esegue la moltiplicazione visualizzando le somme successive di ogni iterazione

RECORD: 1m 57s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int input1 = 0;
    int input2 = 0;
    int prod = 0;
    int i = 0;

    printf("insert number: ");
    scanf("%d", &input1);
    fflush(stdin);

    printf("insert number: ");
    scanf("%d", &input2);
    fflush(stdin);

    for (i = input2; i > 0; i--)
    {
        prod += input1;
        printf("\n%d", prod);
    }

    printf("\nthe product is: %d", prod);

    return 0;
}