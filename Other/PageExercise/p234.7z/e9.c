/*
programnmac he genera num(utente) numeri random e visualizza quanti numeri pari e quanti numeri dispari sono stati generati

*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
    srand(time(NULL));
    int input = 0;
    int i = 0;
    int num = 0;
    int cnt_pari = 0, cnt_dispari = 0;

    printf("\ninserire il numero di numeri random: ");
    scanf("%d", &input);
    fflush(stdin);

    for (i = 0; i < input; i++)
    {
        num = rand() % 1000;
        if (num % 2 == 0)
        {
            cnt_pari++;
        }
        else
        {
            cnt_dispari++;
        }
    }
    printf("\nsono stati generati %d numeri pari e %d numeri dispari: ", cnt_pari, cnt_dispari);
    return 0;
}