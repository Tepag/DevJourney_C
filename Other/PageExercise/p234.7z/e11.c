/*
programma che effetua il calcolo della media dei voti, dove ogni volta dovrà  rispondere s o N

RECORD: 13m 33s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int sum = 0;
    int cnt = 0;
    int input = 0;
    char choose = 'y';

    do
    {
        printf("insert your grade: ");
        scanf("%d", &input);
        fflush(stdin);

        sum += input;
        cnt++;

        //pay attention with "" or ''
        printf("\ndo you want to continue (Y/N): ");
        scanf("%c", &choose);
        fflush(stdin);

    } while ((choose == (char)'y') || (choose == (char)'Y'));

    printf("\nyour average grade is: %d", sum / cnt);

    return 0;
}