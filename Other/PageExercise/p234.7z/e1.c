/*
programma chen legge una sequenza di numeri interi terminanti con uno 0 e visualizza quanti numeri sono stati inseriti

RECORD: 5m 57s
*/

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>

int main()
{
    int cnt = 0;
    int input = 0;
    do
    {
        printf("\ninserire numero (0 per terminare):");
        scanf("%d", &input);
        fflush(stdin);

        cnt++;
    } while (input != 0);
    printf("\n\nsono stati inseriti %d numeri", --cnt);
    return 0;
}