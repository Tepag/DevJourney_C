/*
programma che leggendo due numeri ne esegue la divisione mediante sottrazioni successive visualizzando
ogni iterazione sullo schermo

RECORD: 4m 30s
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    int input1 = 0;
    int input2 = 0;
    int cnt_div = 0;

    printf("insert number: ");
    scanf("%d", &input1);
    fflush(stdin);

    printf("insert number: ");
    scanf("%d", &input2);
    fflush(stdin);

    do
    {
        if (input1 < input2)
            break;
        input1 -= input2;
        cnt_div++;
        printf("\n%d", cnt_div);
    } while (input1 > 0);

    printf("\n\nthe result is %d + %f", cnt_div, (float)input1 / (float)input2);
    return 0;
}