/*
programma che leggendo due numeri sottrae il minore dal maggiore affinché la loro differenza 
diventa minore di 3, visualizando il risultato di ogni iterazione

RECORD: 5m 18s
*/

#include <stdio.h>
#include <stdlib.h>

void sub_successiva(int mag, int min);

int main()
{
    int input1 = 0;
    int input2 = 0;

    printf("insert number: ");
    scanf("%d", &input1);
    fflush(stdin);

    printf("insert number: ");
    scanf("%d", &input2);
    fflush(stdin);

    if (input1 > input2)
        sub_successiva(input1, input2);
    else
        sub_successiva(input2, input1);

    return 0;
}

void sub_successiva(int mag, int min)
{
    do
    {
        mag -= min;
        printf("\n%d", mag);
    } while (mag >= 3);
}