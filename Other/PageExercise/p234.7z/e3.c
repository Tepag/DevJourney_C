/*
programma che legge un numero num e quindi successivamente esegue la somma di num numeri inseriti dall'utente

RECORD: 2m 58s
*/

#include <stdlib.h>
#include <conio.h>
#include <stdio.h>

int main()
{
    int input = 0;
    int i = 0;
    int somma = 0;
    int limite = 0;

    printf("\ninserire numero di numeri di cui si vuole la somma:");
    scanf("%d", &limite);
    fflush(stdin);

    for (i = 0; i < limite; i++)
    {
        printf("\ninserire numero (0 per terminare):");
        scanf("%d", &input);
        fflush(stdin);

        somma += input;
    }

    printf("\n\nla somma dei numeri inseriti e\' %d", somma);
    return 0;
}