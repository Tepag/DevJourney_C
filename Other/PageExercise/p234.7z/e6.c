/*
programma che esegue la somma di tutti i numeri multipli di 5 compresi tra 10 e 100

RECORD: 2m 34s
*/

#include <stdlib.h>
#include <stdio.h>

int main()
{
    int i = 0;
    int somma = 0;
    for (i = 10; i <= 100; i++)
    {
        if (i % 5 == 0)
        {
            somma += i;
        }
    }
    printf("\nla somma di tutti i numeri multiplki di 5 trea 10 e 100 e\' %d", somma);
    return 0;
}
