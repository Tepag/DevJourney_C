/*
programma che effetua il conto alla rovescia a partiore da un valore minore di 20 inserito da utente

RECORD: 3m 12s
*/
#include <stdlib.h>
#include <stdio.h>

int main()
{
    int input = 0;
    int i = 0;
    printf("\n inserire il numero da cui partire il conto alla rovescia: ");
    scanf("%d", &i);
    fflush(stdin);
    for (i = i; i >= 0; i--)
    {
        printf("\n%d", i);
    }
    return 0;
}