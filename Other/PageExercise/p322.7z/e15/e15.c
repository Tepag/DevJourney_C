/*
visualizza una matrice secondo le seguenti disposizioni:
- matrice per diagonali             RECORD:49m 47s
- matrice a zigzag                  RECORD:22m 39s


*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define DIM 5

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

/*funzione che crea una matrice a forma di spirale NB: deve essere utilizzato insieme alla funzione di inizializzazione a zero NB: 
@param int[][] Matrice da mettere come spirale
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void Mat_per_diagonali(int _m[][DIM], int _d);

/*funzione che crea una matrice a forma di spirale NB: deve essere utilizzato insieme alla funzione di inizializzazione a zero
@param int[][] Matrice da mettere come spirale
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void Mat_a_zigzag(int _m[][DIM], int _r, int _c);

/*funzione che inizializza tutti i valori contenete nella matrice
@param int[][] Matrice da resettare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void init_mat(int _m[][DIM], int _r, int _c);

int main()
{
    int mat[DIM][DIM];
    int mat2[DIM][DIM];

    printf("matrice inizializzata:\n");
    init_mat(mat, DIM, DIM);
    init_mat(mat2, DIM, DIM);
    stampaMat(mat, DIM, DIM);
    printf("\n\n\n");

    printf("matrice per diagonali:\n");
    Mat_per_diagonali(mat, DIM);
    stampaMat(mat, DIM, DIM);
    printf("\n\n\n");

    printf("matrice a zigzag:\n");
    Mat_a_zigzag(mat2, DIM, DIM);
    stampaMat(mat2, DIM, DIM);
    printf("\n\n\n");

    return 0;
}

void init_mat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            _m[i][j] = 0;
        }
    }
}

void Mat_per_diagonali(int _m[][DIM], int _d)
{
    int i = 0, j = 0;
    int cnt = 0;
    int j_backup = 0;

    for (j = 0; j < _d; j++)
    {

        //decremento il cnt e aumento la i
        cnt = j + 1;
        for (i = 0; i <= j; i++)
        {

            _m[i][j] = cnt;
            cnt--;
        }
        i--;

        //incremento il cnt e diminuisco la j
        cnt++;
        for (j_backup = (j - 1); j_backup >= 0; j_backup--)
        {
            cnt++;
            _m[i][j_backup] = cnt;
        }
    }
}

void Mat_a_zigzag(int _m[][DIM], int _r, int _c)
{
    int i = 0, j = 0;
    int cnt = 1;

    /*ciclo che comprende: 
    ----->   
    <-----  
    */
    for (i = 0; i < _r; i++)
    {
        //incremento il cnt e faccio scorrere a destra incrementando la x/j
        for (j = 0; j < _c; j++)
        {
            _m[i][j] = cnt;
            cnt++;
        }

        //incremento di 1 la i per andare alla riga successiva
        i++;

        //incremento il cnt e faccio scorrere a sinistra diminuendo la x/j
        for (j = (_c - 1); j >= 0; j--)
        {
            _m[i][j] = cnt;
            cnt++;
        }
    }
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.3d ", _m[i][j]);
        }
        printf("\n");
    }
}