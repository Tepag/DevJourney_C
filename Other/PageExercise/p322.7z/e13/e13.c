/*
scrivi un programma che legge da tastiera due matrici a e b di dimensione NxN e calcola la matrice C = A'BA, dove A' è la matrice trasposta

RECORD: 26m 39s
*/

#include <stdlib.h>
#include <stdio.h>
#include <conio.h>

#define DIM 3

/*funzione che prende in input per una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void input_mat(int _m[][DIM], int _r, int _c);

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

/*funzione che un operazione tra due matrici
@param int[][] Matrice op1
@param int[][] Matrice op2
@param int[][] Matrice risultato
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@param int 0 --> op1 + op2 + op3   1 --> op1 - op2 - op3   2 --> op1 * op2 * op3   3 --> op1 / op2 / op3
@return void
*/
void op_three_mat(int _m1[][DIM], int _m2[][DIM], int _m3[][DIM], int _m[][DIM], int _r, int _c, int choose);

/*funzione che trasposta una matrice
@param int[][] Matrice da traspostare
@param int[][] Matrice che memorizzerà la matrice trasposta
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void trasposta_mat(int _m[][DIM], int _mt[][DIM], int _r, int _c);

int main()
{
    // 0. stampo le istruzioni del programma
    printf("\nprogramma che legge da tastiera due matrici a e b di dimensione NxN e calcola la matrice C = A'BA, dove A' è la matrice trasposta\n\n");

    // 1. inizializzo
    int mat_a[DIM][DIM];
    int mat_b[DIM][DIM];
    int mat_a1[DIM][DIM];
    int mat_c[DIM][DIM];

    // 2. prendo in input la matrice A e B
    printf("\ninserimento dei valori della matrice A:\n");
    input_mat(mat_a, DIM, DIM);
    printf("\ninserimento dei valori della matrice B:\n");
    input_mat(mat_b, DIM, DIM);

    // 3. stampo mat a e b
    printf("\ni valori inseriti nella matrice A:\n");
    stampaMat(mat_a, DIM, DIM);
    printf("\ni valori inseriti nella matrice B:\n");
    stampaMat(mat_b, DIM, DIM);

    // 4. trasposto la matrice A nella matrice A'
    trasposta_mat(mat_a, mat_a1, DIM, DIM);

    // 5. calcolo la matrice C = A'AB e la stampo
    op_three_mat(mat_a1, mat_a, mat_b, mat_c, DIM, DIM, 2);
    printf("\ni valori inseriti nella matrice C (risultato):\n");
    stampaMat(mat_c, DIM, DIM);
}

void input_mat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("\ninserisci il numero nella cella %d %d: ", i, j);
            scanf("%d", &_m[i][j]);
            fflush(stdin);
        }
    }
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.3d ", _m[i][j]);
        }
        printf("\n");
    }
}

void trasposta_mat(int _m[][DIM], int _mt[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            _mt[i][j] = _m[j][i];
        }
    }
}

void op_three_mat(int _m1[][DIM], int _m2[][DIM], int _m3[][DIM], int _m[][DIM], int _r, int _c, int choose)
{
    int i, j;

    switch (choose)
    {

    case 0:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] + _m2[i][j] + _m3[i][j];
            }
        }
        break;
    }

    case 1:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] - _m2[i][j] - _m3[i][j];
            }
        }
        break;
    }

    case 2:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] * _m2[i][j] * _m3[i][j];
            }
        }
        break;
    }

    case 3:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] / _m2[i][j] / _m3[i][j];
            }
        }
        break;
    }

    default:
    {
        printf("\nscelta nella funzione non disponibile");
        break;
    }
    }
}