/*
programma che lege da tastiera due matrici A e B di dimensione NxN e calcola la somma C = A + B e il prodotto D = AB, visualizzando le matrici 
ottenute: l'ordine della matrice viene letto come primo dato

RECORD: 33m 46s
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define DIM_MAX 100

/*funzione che prende in input per una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void input_mat(int _m[][DIM_MAX], int _r, int _c);

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM_MAX], int _r, int _c);

/*funzione che un operazione tra due matrici
@param int[][] Matrice op1
@param int[][] Matrice op2
@param int[][] Matrice risultato
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@param int 0 --> +   1 --> -   2 --> *   3 --> /
@return void
*/
void op_two_mat(int _m1[][DIM_MAX], int _m2[][DIM_MAX], int _m[][DIM_MAX], int _r, int _c, int choose);

int main()
{
    int mata[DIM_MAX][DIM_MAX];
    int matb[DIM_MAX][DIM_MAX];
    int matc[DIM_MAX][DIM_MAX];
    int matd[DIM_MAX][DIM_MAX];

    int dim = 0;
    printf("insert matrix dimension (the max is 100): ");
    scanf("%d", &dim);
    fflush(stdin);

    // inserimento dei numeri nelle rispettive celle
    input_mat(mata, dim, dim);
    input_mat(matb, dim, dim);

    // stampo a
    printf("\nmatrice A: \n");
    stampaMat(mata, dim, dim);

    // stampo b
    printf("\nmatrice A: \n");
    stampaMat(matb, dim, dim);

    // nella matrice C deve esserci la somma tra a e b
    op_two_mat(mata, matb, matc, dim, dim, 0);
    // stampo c
    printf("\nmatrice C: \n");
    stampaMat(matc, dim, dim);

    // nella matrice D il prodotto tra a e b
    op_two_mat(mata, matb, matd, dim, dim, 2);
    // stampo d
    printf("\nmatrice D: \n");
    stampaMat(matd, dim, dim);

    return 0;
}

void input_mat(int _m[][DIM_MAX], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("\ninserisci il numero nella cella %d %d: ", i, j);
            scanf("%d", &_m[i][j]);
            fflush(stdin);
        }
    }
}

void stampaMat(int _m[][DIM_MAX], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.3d ", _m[i][j]);
        }
        printf("\n");
    }
}

void op_two_mat(int _m1[][DIM_MAX], int _m2[][DIM_MAX], int _m[][DIM_MAX], int _r, int _c, int choose)
{
    int i, j;

    switch (choose)
    {

    case 0:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] + _m2[i][j];
            }
        }
        break;
    }

    case 1:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] - _m2[i][j];
            }
        }
        break;
    }

    case 2:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] * _m2[i][j];
            }
        }
        break;
    }

    case 3:
    {
        for (i = 0; i < _r; i++)
        {
            for (j = 0; j < _c; j++)
            {
                _m[i][j] = _m1[i][j] / _m2[i][j];
            }
        }
        break;
    }

    default:
    {
        printf("\nscelta nella funzione non disponibile");
        break;
    }
    }
}
