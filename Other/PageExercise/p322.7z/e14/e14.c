/* 
visualizza una matrice secondo le seguenti disposizioni:
- matrice a spirale         RECORD 01h 41m 22s
- matrice traslata          RECORD 23m 16s
*/

#include <stdio.h>
#include <stdlib.h>
//#include <conio.h>

#define DIM 4

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

/*funzione che crea una matrice a forma di spirale NB: deve essere utilizzato insieme alla funzione di inizializzazione a zero
@param int[][] Matrice da mettere come spirale
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void Mat_spirale(int _m[][DIM], int _r, int _c);

/*funzione che crea una matrice traslata
@param int[][] Matrice da mettere come spirale
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void Mat_traslata(int _m[][DIM], int _r, int _c);

/*funzione che inizializza tutti i valori contenete nella matrice
@param int[][] Matrice da resettare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void init_mat(int _m[][DIM], int _r, int _c);

int main()
{
    int mat[DIM][DIM];
    int mat2[DIM][DIM];

    printf("la matrice a spirale:\n\n");
    Mat_spirale(mat, DIM, DIM);
    stampaMat(mat, DIM, DIM);

    printf("\n\n\n\nla matrice a traslata:\n\n");
    Mat_traslata(mat2, DIM, DIM);
    stampaMat(mat2, DIM, DIM);

    return 0;
}

void init_mat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            _m[i][j] = 0;
        }
    }
}

void Mat_spirale(int _m[][DIM], int _r, int _c)
{
    int cnt = 1;
    int i = 0, j = 0;
    int dim_h = _r;
    int dim_l = _c;
    int start_h = 0;
    int start_l = 0;
    init_mat(_m, _r, _c); //!!!!!!!!!!!!!!!!NOTA BENE!!!!!!!!!!!!!!!!

    i = 0;
    j = 0;
    cnt = 1;
    while (cnt <= _r * _c)
    {
        for (j = start_l; j < dim_l; j++)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
                cnt++;
            }
        }
        j--;

        start_h++;
        for (i = start_h; i < dim_h; i++)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
                cnt++;
            }
        }
        i--;

        for (j = (dim_l - 1); j >= start_l; j--)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
                cnt++;
            }
        }
        j++;

        dim_h--;
        for (i = (dim_h - 1); i >= start_h; i--)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
                cnt++;
            }
        }
        start_l++;
        dim_l--;
        i = start_h;
    }
}

void Mat_traslata(int _m[][DIM], int _r, int _c)
{
    int start = 0;
    int cnt = 1;
    int i = 0;
    int j = 0;

    for (i = 0; i < _r; i++)
    {
        cnt = 0;
        for (j = 0; j < _c; j++)
        {
            _m[i][j] = start + cnt;
            cnt++;
        }
        start++;
    }
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.3d ", _m[i][j]);
        }
        printf("\n");
    }
}