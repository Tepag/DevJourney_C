/*
Leggi un numero N come ordine (dim) di una matrice quadrata: successivamente, inserisci i dati interi con il metodo rigaxcolonna. 
Il programma verfica se tale matrice è simmetrica rispetto alla diagonale principale e successivamente visualizza 

RECORD: 23m 01s
*/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 3

/*funzione che prende in input per una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void input_mat(int _m[][DIM], int _r, int _c);

/*funzione che verifica se una matrice è simmetrica rispetto alla diagonale che parte da [0][0] e finisce a [DIM][DIM]
@param int[][] Matrice da ispezionare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return return 1-->vero 0-->falso
*/
void simmetria_mat(int _m[][DIM], int _r, int _c);

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

int main()
{
    int mat[DIM][DIM];

    //1. inserimento riga x colonna
    input_mat(mat, DIM, DIM);

    //2. verifica se matrice è simmetrica cioè mat[i][j] == mat[j][i]
    simmetria_mat(mat, DIM, DIM);

    //3.visualizzazione della matrice
    stampaMat(mat, DIM, DIM);

    return 0;
}

void input_mat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("\ninserisci il numero nella cella %d %d: ", i, j);
            scanf("%d", &_m[i][j]);
            fflush(stdin);
        }
    }
}

void simmetria_mat(int _m[][DIM], int _r, int _c)
{
    int i = 0, j = 0;
    int flag_if_not = 0;
    // matrice è simmetrica quando mat[i][j] == mat[j][i]
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            if (!(_m[i][j] == _m[j][i]))
            {
                flag_if_not++;
                break;
            }
        }
    }
    if (flag_if_not == 0)
        printf("\n la matrice risulta simmetrica\n");
    else
        printf("\n la matrice non risulta simmetrica\n");
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.3d ", _m[i][j]);
        }
        printf("\n");
    }
}