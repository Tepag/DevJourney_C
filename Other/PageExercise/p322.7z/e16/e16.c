/*
Visualizza una matrice seguendo le seguenti disposizioni:
-matrice azteca                 
-matrice a doppi gradini

RECORD: 22m 32s         (prendendo le funzioni fatti nel es.14)
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 10

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

/*funzione che crea una matrice a forma di azteca NB: deve essere utilizzato insieme alla funzione di inizializzazione a zero
@param int[][] Matrice da mettere come azteca
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void Mat_azteca(int _m[][DIM], int _r, int _c);

/*funzione che crea una matrice a doppio gradino NB: deve essere utilizzato insieme alla funzione di inizializzazione a zero
@param int[][] Matrice
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void Mat_doppi_gradini(int _m[][DIM], int _r, int _c);

/*funzione che inizializza tutti i valori contenete nella matrice
@param int[][] Matrice da resettare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void init_mat(int _m[][DIM], int _r, int _c);

int main()
{
    int mat[DIM][DIM];
    int mat2[DIM][DIM];

    printf("la matrice a azteca:\n\n");
    Mat_azteca(mat, DIM, DIM);
    stampaMat(mat, DIM, DIM);

    printf("la matrice a doppio gradino:\n\n");
    Mat_doppi_gradini(mat2, DIM, DIM);
    stampaMat(mat2, DIM, DIM);

    return 0;
}

void init_mat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            _m[i][j] = 0;
        }
    }
}

void Mat_azteca(int _m[][DIM], int _r, int _c)
{
    int cnt = 1;
    int i = 0, j = 0;
    int dim_h = _r;
    int dim_l = _c;
    int start_h = 0;
    int start_l = 0;
    int volte = 0;
    init_mat(_m, _r, _c); //!!!!!!!!!!!!!!!!NOTA BENE!!!!!!!!!!!!!!!!

    i = 0;
    j = 0;
    cnt = 1;

    while (cnt <= (_c / 2))
    {
        for (volte = 0; volte < 2; volte++)
        {
            for (j = start_l; j < dim_l; j++)
            {
                if (_m[i][j] == 0)
                {
                    _m[i][j] = cnt;
                }
            }
            j--;

            start_h++;
            for (i = start_h; i < dim_h; i++)
            {
                if (_m[i][j] == 0)
                {
                    _m[i][j] = cnt;
                }
            }
            i--;

            for (j = (dim_l - 1); j >= start_l; j--)
            {
                if (_m[i][j] == 0)
                {
                    _m[i][j] = cnt;
                }
            }
            j++;

            dim_h--;
            for (i = (dim_h - 1); i >= start_h; i--)
            {
                if (_m[i][j] == 0)
                {
                    _m[i][j] = cnt;
                }
            }
            start_l++;
            dim_l--;
            i = start_h;
        }
        cnt++;
    }
}

void Mat_doppi_gradini(int _m[][DIM], int _r, int _c)
{
    int cnt = 1;
    int i = 0, j = 0;
    int dim_h = _r;
    int dim_l = _c;
    int start_h = 0;
    int start_l = 0;
    int volte = 0;
    init_mat(_m, _r, _c); //!!!!!!!!!!!!!!!!NOTA BENE!!!!!!!!!!!!!!!!

    i = 0;
    j = 0;
    cnt = 1;

    while (cnt <= (_c / 2))
    {
        for (j = start_l; j < dim_l; j++)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
            }
        }
        j--;

        start_h++;
        for (i = start_h; i < dim_h; i++)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
            }
        }
        i--;

        for (j = (dim_l - 1); j >= start_l; j--)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
            }
        }
        j++;

        dim_h--;
        for (i = (dim_h - 1); i >= start_h; i--)
        {
            if (_m[i][j] == 0)
            {
                _m[i][j] = cnt;
            }
        }
        start_l++;
        dim_l--;
        i = start_h;
        cnt++;
    }
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.2d ", _m[i][j]);
        }
        printf("\n");
    }
}