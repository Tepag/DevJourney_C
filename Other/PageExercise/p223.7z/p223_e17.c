/*
programma che cerca i primi tre numeri perfetti e li visualizza sullo schermo

RECORD:13m 04s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int num=1;
    int div=1;
    int somma=0;
    int cnt=0;

    //ricerca di tre numeri
    while(cnt<3){

        //trovare i divisori
        while(num>div){
            if(num%div==0){
                somma+=div;
            }
            div++;
        }

        //somma dei suoi divisori deve essere uguale al numero
        if(somma==num){
            printf("\nnumero perfetto trovato: %d", num);
            cnt++;
        }
            
        somma=0;
        num++;
        div=1;
            
    }

    getchar();
    return(0);
}