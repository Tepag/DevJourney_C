/*
esegue la molt. di due numeri inseriti da un utente utilizzzando il metodo delle somme successive

RECORD:5m 11s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int inp1=0;
    int inp2=0;
    int prod=0;

    //input
    printf("\ninserire il primo valore: ");
    scanf("%d",&inp1);
    fflush(stdin);

    //input2
    printf("\ninserire il secondo valore: ");
    scanf("%d",&inp2);
    fflush(stdin);

    for(int cnt=0; cnt<inp2; cnt++){
        prod+=inp1;
    }

    printf("\nprodotto %d", prod);

    return(0);
}