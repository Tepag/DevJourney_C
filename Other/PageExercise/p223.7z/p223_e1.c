/*
scrivi un programma che legge un numero num e quindi successivamente esegue la somma di num numeri inseriti dall'utente

RECORD:6m 21s
*/

#include<stdlib.h>
#include<conio.h>
#include<stdio.h>

int main(){
    int num=0;      //numero che inserisce l'utente ed è un limitatore
    int somma=0;
    int inp=0;

    printf("inserire il numero dei numeri della quale si vuole la somma: ");
    scanf("%d",&num);
    fflush(stdin);

    for(int cnt=0; cnt<num; cnt++){
        printf("inserire valore: ");
        scanf("%d",&inp);
        fflush(stdin);

        somma+=inp;         
    }

    printf("somma dei valori inseriti e\': %d",somma);

    getchar();
    return(0);
}