/*
scrivi un programma che legge da tastiera  una sequenza di numeri positivi e a ogni numero letto ne stampa la somma progressiva. il programma
termina quando si introduce un numerominore o uguale a zero.

RECORD:6m 22s
*/

#include<stdlib.h>
#include<stdio.h>
#include<conio.h>

int main(){
    int somma=0;
    int input=1;

    while(input>0){


        printf("\ninserire numero di cui si vuole sommare:");
        scanf("%d", &input);
        fflush(stdin);
        if(input>0){
            somma+=input;

            printf("\nsomma: %d",somma);
        }
    
    }
    return(0);
}