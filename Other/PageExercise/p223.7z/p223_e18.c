/*
calcolo del fattoriale di un numero(esempio 5 = 1*2*3*4*5)

RECORD:5m 50s
*/

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

int main(){
    int inp=0;
    int ftt=0;
    int prd=1;

    printf("inserire il numero di cui si viuole il fattoriale:");
    scanf("%d", &inp);
    fflush(stdin);

    while(inp>0){
        ftt=inp;
        prd*=ftt;
        inp--;
    }

    printf("\n fattoriale=%d", prd);

    getchar();
    return(0);
}
