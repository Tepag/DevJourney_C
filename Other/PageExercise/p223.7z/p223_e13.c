/*
legge una serie di numeri interi positivi arrestandosi quando la somma dei numeri immessi supera un valore costante lettocome primo numero della sequenza

RECORD:6m 37s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int inp=0;
    int lim=0;
    int somma=0;

    printf("inserire limite somma dei numeri che verranno inseriti successivamente: ");
    scanf("%d",&lim);
    fflush(stdin);

    while(somma<lim){
        
        printf("inserire numero: ");
        scanf("%d",&inp);
        fflush(stdin);

        somma+=inp;
    }

    return(0);

}