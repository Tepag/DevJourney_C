/*
programma che visualizza i numeri pari multipli di 8 compresi tra 10 e 100

RECORD:5m 28s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#define MULT 8

int main(){

    for(int cnt=11; cnt<=100; cnt++){
        if(cnt%2==0 && cnt%MULT==0){
            printf("\nil numero %d e\' multiplo di 8 tra 10 e 100", cnt);
        }
    }

    return(0);
}