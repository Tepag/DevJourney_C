/*
chiede in ingresso un numero finchè non inserisce un numero dispari, quando avviene, il programma termina scrivendo quanti numeri pari erano stati 
inseriti

RECORD:5m 4s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int num=0;
    int cnt=0;

    do{
        printf("\ninserire numero: ");
        scanf("%d", &num);
        fflush(stdin);

        if(num%2==0){
            cnt++;
        }
    }
    while(num%2==0);

    printf("numeri pari inseriti in precedenza: %d", cnt);

    getchar();
    return(0);
}
