/*
legge un numero num ed esegue il calcolo della somma dei primi num numeri interi pari positivi

RECORD:8m 36s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int num=0;
    int cnt=0;
    int somma=0;
    int prv=2;

    //input
    printf("inserire numero: ");
    scanf("%d", &num);
    fflush(stdin);

    //trovare i primi numeri pari positivi
    while(cnt!=num){
        if(prv%2==0){
            cnt++;
            somma+=prv;
        }
        prv++;
    }

    printf("\nsomma=%d", somma);


    getchar();
    return(0);
}