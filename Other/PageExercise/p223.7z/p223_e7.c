/*
input un numero num e calcola il doppio della somma dei primi num numeri

RECORD:6m 27s
*/

#include<stdio.h>
#include<stdio.h>
#include<conio.h>

int main(){
    int num=0;
    int somma=0;
    int cnt=0;

    //input
    printf("questo programma calcola il doppio della somma dei primi num numeri\n");
    printf("\ninserire valore: ");
    scanf("%d", &num);
    fflush(stdin);

    //primi numeri a partire da zero
    while(cnt<num){
        cnt++;
        somma+=cnt;
    }

    somma*=2;

    printf("output: %d", somma);

    return(0);
}