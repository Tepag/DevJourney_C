/*
somma di tutti i numeri multipli di 5 compresi tra 10 e 100.

RECORD:7m 15s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int somma=0;

    //compreso tra 10 e 100
    for(int cnt=11; cnt <= 100; cnt++){
        //multipli di 5
        if(cnt%5==0){

            //somma di questi
            somma+=cnt;
            printf("somma %d\n",somma);
        }
    }

    printf("somma dei multipli di 5 tra 10 e 100 e\' %d", somma);

    getchar();
    return(0);
}