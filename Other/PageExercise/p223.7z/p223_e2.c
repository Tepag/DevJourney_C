/*
programma che legge 10 numeri e ne stampa il massimo

RECORD:7m 30s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int inp=0;
    int vpgrande=0;
    
    //lettura di dieci numeri
    for(int cnt=0; cnt<10; cnt++){
        printf("inserire i valori di cui si vole trovare il più grande: \n");
        scanf("%d",&inp);
        fflush(stdin);

        //trovare il più grande
        if(inp>vpgrande){
            vpgrande=inp;
        }

    }

    printf("tra i dieci numeri che si sono inseriti, il piu\' grande è %d",vpgrande);

    getchar();
    return(0);
}