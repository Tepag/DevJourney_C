/*
inserire Y/F per iniziare il programma (utilizza lo switch); verifica se un anno è bisestile. termina con l'inserimento di un numero minore di 0
divisibile per 4 ma non per 100 oppure se è divisibile per 400

RECORD:23m 07s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    char choose;
    int inp=0;

    printf("questo programma verifica se un anno è bisestile; continuare (Y/N) ?");
    choose=getch();

    switch(choose){
        case 'Y':
        while(inp>=0){
            printf("\ninserire il numero: ");
            scanf("%d", &inp);
            fflush(stdin);

            if((inp%4==0 && inp%100!=0 && inp>0) || (inp%400==0 && inp>0)){
                printf("\nanno bisestile");
            }
            else{
                if(inp>0){
                    printf("\nanno non bisestile");
                }
            }
        }

        case 'y':
        while(inp>=0){
            printf("\ninserire il numero: ");
            scanf("%d", &inp);
            fflush(stdin);

            if((inp%4==0 && inp%100!=0 && inp>0) || (inp%400==0 && inp>0)){
                printf("\nanno bisestile");
            }
            else{
                if(inp>0){
                    printf("\nanno non bisestile");
                }
                
            }
        }

        case 'N':
        return(0);

        case 'n':
        return(0);

        default:
        printf("\nscelta non valida"); 
    }
     

    return(0);
}