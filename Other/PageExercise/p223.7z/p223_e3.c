/*
legge un numero num e visualizza tutti i numeri pari inferiori a tale numero

RECORD:8m 39s
*/

#include<conio.h>
#include<stdlib.h>
#include<stdio.h>

int main(){
    int inp=0;
    int cnt=1;

    //input
    printf("inserire valore: ");
    scanf("%d",&inp);
    fflush(stdin);

    
    //numeri minori di inp
    while(cnt<inp){

        //selezione numeri pari
        if(cnt%2==0){

            //visualizzazione numeri
            printf("\nnumero inferiore a %d pari e\' %d\n", inp, cnt);
        }

        cnt++;
    }

    getchar();
    return(0);
    
    //visualizzazione numeri
    
}