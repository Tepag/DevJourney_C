/*
legge un numero num e visualizza tutti i numeri primi inferiore a tale numero

RECORD:36m 33s
*/

#include<conio.h>
#include<stdlib.h>
#include<stdio.h>

int main(){
    int num=0;
    int ver=0;

    printf("inserire il numero di cui si vuole sapere i numeri primi inferiori: ");
    scanf("%d", &num);
    fflush(stdin);

    do{
        ver=0;
        //divisori
        for(int div=1; num>=div; div++){
            if(num%div==0){
                ver++;
            }
        }

        //cosa fare se il numero è primo
        if(ver<=2){
            printf("\nil numero %d, e\' primo", num);
        }
        /*
        else{
            printf("\nil numero %d, non e\' primo", num);
        }
        */

        //decremento num per trovate i numeri inferiori
        num--;
    }
    while(num>=0);
    

    getchar();
    return(0);
}
