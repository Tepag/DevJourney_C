/*
legge un numero num e visualizza i suoi fattori

RECORD:12m 42s
*/

#include<stdlib.h>
#include<conio.h>
#include<stdio.h>

int main(){
    int num=0;
    int div=2;

    printf("\ninserire il numero di cui si vuole sapere i suoi fattori: ");
    scanf("%d", &num);
    fflush(stdin);


    do{
        if(num%div==0){
            printf("\n%d", div);
            num/=div;
            div=1;
        }
        div++;
    }
    while(num!=1);

    getchar();
    return(0);

}
