/*
legge da tstiera una sequenza di lunghezza ingnotas a priori di numeri interi positivi. il programma a partire dal primo numero introdottro, stampa 
ognivolta la media di tutti i numeri introdotti. termina quando il numero inserito è negativo

RECORD:8m 48s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int media=0;
    int somma=0;
    int cnt=0;
    int inp=0;

    while(inp>=0){
        printf("\ninserire numero: ");
        scanf("%d",&inp);
        fflush(stdin);

        if(inp>=0){
            cnt++;
            somma+=inp;
            media=somma/cnt;

            printf("\nmedia: %d", media);
        }
    }

    return(0);
}