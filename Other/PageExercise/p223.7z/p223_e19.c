/*
ricerca i primi due valori amicabili(somma dei divisori dell'altro) e visualizzali sullo schermo

RECORD:m s
*/