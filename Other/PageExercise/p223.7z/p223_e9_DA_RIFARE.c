/*
legge sequenza di numer interi positi terminanti con inserimento di 0 e cerca il valore minimo e visualizzalo sullo schermo il valore minimo inserito

RECORD:m s 
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

int main(){
    int num=0;      //input
    int min=0;      //numero minimo che inseriamo
    int lim=0;      //limitare 

    do{
        //input
        printf("inserire numero: ");
        scanf("%d",&num);
        fflush(stdin);

        //il primo giro e setto il primo numero per comparare gli altri inseriti
        if(lim==0){
            min=num;
            lim++;
        }
        
        //se il numero inserito è minore del minimo inserito fino ad ora allora sostituisci
        if(num<min && num!=0){
            min=num;
        }
    }
    while(num!=0);

    printf("\n numero minimo inserito: %d", min);

    getchar();
    return(0);
}

/*
int main()
{
	int num;
	int minore;
	printf("Inserisci un numero positivo: ");
	scanf("%d", &num);
	fflush(stdin);

	minore=num;

	while(num!=0){
		
		if(  num>0 &&   num< minore )
			minore = num;
		printf("Inserisci un numero positivo: ");
	    scanf("%d", &num);
		fflush(stdin);
	}

	printf("Il numero minore inserito e\' %d", minore);
	getchar();
	return(0);
}
*/