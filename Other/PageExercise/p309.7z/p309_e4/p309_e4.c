/*
leggi N numeri e visualizzali al contrario

RECORD:5m 27s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#define DIM 10

int main(){
    int vet[DIM];
    int i=0;

    for(i=0;i<DIM;i++){
        vet[i]=0;
    }

    for(i=0;i<DIM;i++){
        printf("\ninserire numero %d : ",i);
        scanf("%d",&vet[i]);
        fflush(stdin);
    }

    for(i=DIM-1; i>=0;i--){
        printf("\n%d ",vet[i]);
    }

    return(0);
}