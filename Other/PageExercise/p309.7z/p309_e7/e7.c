/*
leggi n numeri inseriscili in un vettore e individua i elementi duplicati e visualizzali sullo schermo

RECORD: 10m 18s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e7_lib.c"

#define DIM 10

int main()
{
    int vet[DIM];
    random_array(vet, DIM, 1, 10);
    stampaVettore(vet, DIM);
    printf("\n");
    orderarr(vet, DIM);
    stampaVettore(vet, DIM);
    printf("\n");
    searchdouble(vet, DIM);
    printf("\n");
    stampaVettore(vet, DIM);

    getchar();
    return (0);
}