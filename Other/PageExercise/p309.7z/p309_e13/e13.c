/*
array di 10 el. memorizzati e ordinati, poi si inerisce un 
altro numero da parte dell' utente che verra` inserito nel vettore nel posto giusto

RECORD:21m 51s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e13_lib.c"

#define DIM 11

int main(){
    int vet[DIM];
    int inp=0;

    //funzione che va a randomizzare il vettore
    random_array(vet,DIM-1,10,99);
    orderarr(vet,DIM-1);
    stampaVettore(vet,DIM-1);

    printf("\ninserisci numero:");
    scanf("%d",&vet[DIM-1]);
    fflush(stdin);
    orderarr(vet,DIM);
    printf("\n");
    stampaVettore(vet,DIM);

    getchar();
    return 0;
}