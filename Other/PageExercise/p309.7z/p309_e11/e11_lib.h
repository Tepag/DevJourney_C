/*funzione che va a randomizzare i valori in un vettore dati inizio e fine
@param int[] vettore da randomizzare
@param int dimensione 
@param int numerominimo random
@param int numero massimo random
@return void*/
void random_array(int _v[], int _d, int _start, int _end);

/*funzione che va a stampare un vettore dato vettore e dimensione
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void*/
void stampaVettore(int _v[], int _d);

/*funzione che va a calcolare con la formula fornita
@param int vetoore di cui si vuole filtrare con la formula
@param int dimensione vettore
@return void
*/
void calcola(int [], int);