/*
dato un array di numeri non negativi (n<0 = fine inserimento) e 
calcola con la formula v[i]=(v[i-1]+v[i+1])/3

RECORD: 11m 27s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e11_lib.c"

#define DIM 50

int main(){
    int vet[DIM];
    random_array(vet,DIM,10,99);
    stampaVettore(vet,DIM);
    printf("\n\n\n");
    calcola(vet,DIM);
    stampaVettore(vet,DIM);

    getchar();
    return 0;
}