/*
genera casualmente 10 numeri e effetua lo scambio tra il maggiore e il minimo elemento

RECORD:24m 40s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#define MAX 10

int main(){
    int vet[MAX];
    int i=0;
    int j=0;
    int tmp=0;

    
    for(i=0; i<MAX; i++){
        printf("%d\n", vet[i]);
    }
    printf("\n\n");
    

    //faccio un ciclo per girare il vettore
    for(i=0;i<MAX; i++){
        //faccio un secondo ciclo per comparare il cettore con tutti i suoi successivi
        for(j=i+1; j<MAX; j++){
            if(vet[i]>vet[j]){
                tmp=vet[j];
                vet[j]=vet[i];
                vet[i]=tmp;
                /*
                printf("\n\n i=%d \n\n",vet[i]);
                printf("\n\n tmp=%d \n\n",tmp);
                printf("\n\n j=%d \n\n",vet[j]);
                */
            }
        }
    }
    
    for(i=0; i<MAX; i++){
        printf("%d\n", vet[i]);
    }

    return(0);
}