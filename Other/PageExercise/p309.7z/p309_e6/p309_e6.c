/*
dato un array di n numeri,costruire altri due vettori,dove il vet2 prenderà i numeri minore e l'altro i numeri maggiori del numero scelto dall'utente

RECORD:16m 26s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<time.h>

#define DIM 50

int main(){
    srand(time(NULL));

    int vet1[DIM];
    int vet2[DIM];
    int vet3[DIM];
    int i=0;
    int j=0;
    int k=0;
    int inp=0;

    //inizializzo vet1
    for(i=0;i<DIM;i++){
        vet1[i]=(rand()%100)+1;
    }

    //inizializzo vet2 e 3
    for(i=0;i<DIM;i++){
        vet2[i]=0;
        vet3[i]=0;
    }

    //input utente
    printf("\ninserire numero:");
    scanf("%d",&inp);
    fflush(stdin);

    for(i=0;i<DIM;i++){
        if(vet1[i]<inp){
            vet2[j]=vet1[i];
            j++;
        }
        else{
            vet3[k]=vet1[i];
            k++;
        }
    }   

    printf("\n\n\n");

    //stampo array 2 e 3
    for(i=0;i<DIM;i++){
        printf("%d ",vet1[i]);
    } 

    printf("\n\n\n");

    for(i=0;i<DIM;i++){
        if(vet2[i]!=0){
            printf("%d ",vet2[i]);
        }
    }

    printf("\n\n\n");

    for(i=0;i<DIM;i++){
        if(vet3[i]!=0){
            printf("%d ",vet3[i]);
        }
    }

    return 0;
}