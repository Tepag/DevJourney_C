/*
leggi da tastiera 10 numeri interi e visualizzali in sequenza senza stampare uno stesso numero due volte. Per esempio:
valori inseriti: 15,3,5,3,11,5,15,5,15,11
valori stampati: 15,3,5,11

RECORD:11m 46s
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

#include "p309_e3_lib.c"

#define DIM 10

int main()
{
    int vet[DIM];

    random_array(vet, DIM, 1, 10);
    stampaVettore(vet, DIM);
    printf("\n");
    orderarr(vet, DIM);
    stampaVettore(vet, DIM);
    printf("\n");
    stmp_only_one(vet, DIM);

    getchar();
    return (0);
}