#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

#include "p309_e3_lib.h"

void random_array(int _v[], int _d, int _start, int _end)
{
    int i;
    for (i = 0; i < _d; i++)
        _v[i] = rand() % (_end - _start + 1) + _start;
}

void orderarr(int _v[], int _d)
{
    int tmp = 0;
    int i = 0;
    int j = 0;

    for (i = 0; i < _d; i++)
    {
        for (j = i; j < _d; j++)
        {
            if (_v[i] < _v[j])
            {
                tmp = _v[j];
                _v[j] = _v[i];
                _v[i] = tmp;
            }
        }
    }
}

void stmp_only_one(int _v[], int _d)
{
    int i = 0;
    for (i = 0; i < _d; i++)
    {
        if (_v[i] != _v[i + 1])
        {
            printf("%d ", _v[i]);
        }
    }
}

void stampaVettore(int _v[], int _d)
{
    int i = 0;
    for (i = 0; i < _d; i++)
    {
        printf("%d ", _v[i]);
    }
}
