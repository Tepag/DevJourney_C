/*
input di n numeri interi e calcola la media e la varianza con le formule che vedi sul libro;

RECORD: 29m 51s
*/
#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#include "e15_lib.c"

#define N 5

int main(){
    int vet[N];
    int i=0;

    for(i=0; i<N; i++){
        printf("\ninserire il numero:");
        scanf("%d",&vet[i]);
        fflush(stdin);
    }

    printf("\n la media risulta: %d", funcmedia(vet, N));
    printf("\n la varianza risulta: %d", funcvariazione(vet, N, funcmedia(vet, N)));
}