#include<time.h>
#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#include "e15_lib.h"

int funcmedia(int _v[], int _n){
    int i=0;
    int somma=0;
    for(i=0;i<_n;i++){
        somma+=_v[i];
    }
    return(somma/_n);
}

int funcvariazione(int _v[], int _n, int _m){
    int i=0;
    int somma=0;
    for(i=0;i<_n;i++){
        somma += (_v[i]-(_m*_m));
    }
    return(somma/(_n-1));
}