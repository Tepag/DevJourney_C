/*funzione che calcola la media

*/
int funcmedia(int [], int);

/*funzione che calcola la variazione

*/
int funcvariazione(int [], int, int);