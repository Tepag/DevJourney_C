/*
genera casualmente N numeri e visualizza il loro quadrato

RECORD:3m 14s
*/

#include<conio.h>
#include<stdio.h>
#include<stdlib.h>

#define DIM 8

int main(){
    int vet [DIM];

    for(int i=0; i<=DIM; i++){
        printf("%d\n",vet[i]*vet[i]);
    }

    getchar();
    return(0);
}