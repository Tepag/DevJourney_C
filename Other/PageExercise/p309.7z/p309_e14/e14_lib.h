/*Funzione che dato numero, base e dimensione stampa la conversione
@param int numero da convertire
@param int base in cui si vuole trasformare il numero
@param int lunghezza di padding
@return void*/
void dec_to_(int num, int base, int , int []);

/*funzione che va a stampare un vettore dato vettore e dimensione
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void*/
void stampaVettore(int _v[], int _d);

/*Funzione farà la somma tra due dumeri in BIN
@param int ar1
@param int ar2
@return void
*/
void sum_bin(int[],int[],int[],int,int);