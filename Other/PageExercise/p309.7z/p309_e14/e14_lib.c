#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e14_lib.h"

void dec_to_(int num, int base, int _d, int ris[]){                            
    int i=0;

    for(i=0; i<_d; i++){
        ris[i]=0;
    }
    for(i=0; i<_d; i++){
        ris[i]=num%base;
        num/=base;
    }
    if(base>10){
        for(i=_d-1;i>=0;i--){
            if(ris[i]>=10){
                printf("%c",('A'+ris[i]-10));
            }
            else{
                printf("%d",ris[i]);
            }
            if(i%4==0){
                printf(" ");
            }
        }
    }
    else{
        for(i=_d-1; i>=0; i--){
            printf("%d", ris[i]);
            if(i%4 == 0){
                printf(" ");
            }
        }
    }
}

void stampaVettore(int _v[], int _d){                       
    int i = 0;
    for (i = 0; i < _d; i++)
    {
        printf("%d ", _v[i]);
    }
}

void sum_bin(int _a1[], int _a2[],int _a3[], int _d, int _b){
    int i=0;
    for(i=0; i<_d; i++){
        _a3[i]=_a1[i]+_a2[i]+_a3[i];
        _a3[i+1]=_a3[i]/_b;
        _a3[i]=_a3[i]%_b;
    }
    for(i=_d-1;i>=0;i--){
        printf("%d",_a3[i]);
        if(i%4==0){
            printf(" ");
        }
    }
}


