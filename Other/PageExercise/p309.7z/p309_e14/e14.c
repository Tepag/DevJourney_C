/*
dati due numeri positivi minori di 100, trasformali in binario
somma i due numeri in binario

RECORD: 24m 14s
*/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e14_lib.c"

#define DIM 4

int main(){
    int v1;
    int v2;
    int arr1[DIM];
    int arr2[DIM];
    int arr3[DIM];

    printf("\n\ninserire il primo valore:");
    scanf("%d",&v1);
    fflush(stdin);
    printf("\n\ninserire il secondo valore:");
    scanf("%d",&v1);
    fflush(stdin);

    dec_to_(v1, 2, DIM, arr1);
    printf("\n");
    dec_to_(v2, 2,  DIM, arr2);
    printf("\n");

    sum_bin(arr1,arr2,arr3,DIM,2);
    


}