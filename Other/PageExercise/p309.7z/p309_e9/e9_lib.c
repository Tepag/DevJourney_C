#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e9_lib.h"

void random_array(int _v[], int _d, int _start, int _end){
    int i;
    for (i = 0; i < _d; i++)
        _v[i] = rand() % (_end - _start + 1) + _start;
}

void orderarr(int _v[], int _d){
    int tmp = 0;
    int i = 0;
    int j = 0;

    for (i = 0; i < _d; i++)
    {
        for (j = i; j < _d; j++)
        {
            if (_v[i] > _v[j])
            {
                tmp = _v[j];
                _v[j] = _v[i];
                _v[i] = tmp;
            }
        }
    }
}

void stampaVettore(int _v[], int _d){
    int i = 0;
    for (i = 0; i < _d; i++)
    {
        printf("%d ", _v[i]);
    }
}

void unisci_vet(int _a1[],int _a2[], int _a3[], int _d1, int _d2){
    int i=0;
    for(i=0;i<_d1;i++){
        _a3[i]=_a1[i];
    }
    for(i=_d1;i<(_d1+_d2);i++){
        _a3[i]=_a2[i];
    }
}