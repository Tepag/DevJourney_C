/*
dati due array di numeri interi, ordinatri in senso crescente, anche con misure differenti, creare un tenzo array che li ordini e lo visualizzi

RECORD:16m 59s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e9_lib.c"

#define DIM1 12
#define DIM2 14

int main(){
    int arr1[DIM1];
    int arr2[DIM2];
    int arr3[DIM1+DIM2];

    random_array(arr1,DIM1,10,99);
    random_array(arr2,DIM2,10,99);

    orderarr(arr1,DIM1);
    orderarr(arr2,DIM2);

    stampaVettore(arr1,DIM1);
    printf("\n");
    stampaVettore(arr2,DIM2);

    unisci_vet(arr1,arr2,arr3,DIM1,DIM2);
    printf("\n");
    orderarr(arr3,DIM2+DIM1);
    stampaVettore(arr3,DIM2+DIM1);
    

    getchar();
    return(0);
}