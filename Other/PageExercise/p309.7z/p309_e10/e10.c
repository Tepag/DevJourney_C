/*
dato un vettore contente numeri da -20 a 20 riordinare il vettore in modo tale che i numeri positivi stiano a destra e quelli negativi a sinistra

RECORD:8m 39s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e10_lib.c"

#define DIM 20

int main(){
    int vet[DIM];
    random_array(vet,DIM,-20,20);
    stampaVettore(vet,DIM);
    printf("\n");
    orderarr(vet,DIM);
    stampaVettore(vet,DIM);
    getchar();
    return(0);
}

