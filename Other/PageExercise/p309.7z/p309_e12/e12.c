/*
dati due vet, stampare solo in caso nella la cella dei due vettori 
non corrispondano

RECORD:11m 27s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#include "e12_lib.c"

#define DIM 20

int main(){
    int vet[DIM];
    int arr[DIM];
    random_array(vet,DIM,0,9);
    random_array(arr,DIM,0,9);
    stampaVettore(vet,DIM);
    printf("\n");
    stampaVettore(arr,DIM);
    printf("\n");
    stampa_se(arr,vet,DIM);
    return 0;
}

