void random_array(int _v[], int _d, int _start, int _end){          
    int i;
    for (i = 0; i < _d; i++)
        _v[i] = rand() % (_end - _start + 1) + _start;
}

void stampaVettore(int _v[], int _d){                               
    int i = 0;
    for (i = 0; i < _d; i++)
    {
        printf("%d ", _v[i]);
    }
}

void stampa_se(int _v[],int _a[], int _d){
    int i=0;
    for(i=0;i<_d;i++){
        if(_v[i]-_a[i]!=0){
            printf("%d ",_v[i]);
        }
    }
}