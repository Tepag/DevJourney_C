/*
generare un valore di n numeri, dove scleto una cella all'interno del vetoore genera cusalmente valori random minori o uguali a sinistra e adestra genera numeri casuali maggiori

RECORD:11m 54s
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>
#include<time.h>
#define DIM 10
int main(){
    int vet[DIM];
    int scl=0;
    int i=0;
    srand(time(NULL));

    //input
    printf("\ninserire cella di cui si vole fare la prtizione:");
    scanf("%d",&scl);
    fflush(stdin);

    for(i=scl+1;i<DIM;i++){
        vet[i]=(rand()%1000)+vet[scl];
    }

    for(i=0;i<scl;i++){
        vet[i]=(rand()%vet[scl]);
    }

    for(i=0;i<DIM;i++){
        printf("%d",vet[i]);
        printf("  ");
    }

    getchar();
    return(0);
}