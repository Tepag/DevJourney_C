/*funzione che va a randomizzare i valori in un vettore dati inizio e fine
@param int[] vettore da randomizzare
@param int dimensione 
@param int numerominimo random
@param int numero massimo random
@return void
*/
void random_array(int _v[], int _d, int _start, int _end);

/*funzione che non restituisce nulla e che cerca un valore dato dall'utente
@param int vettore 
@param int dimensione vettore
@return void
*/
void ricerca_arr(int _v[],int _d);

/*funzione che va a stampare un vettore dato vettore e dimensione
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void
*/
void stampaVettore(int _v[], int _d);

/*funzione che va a stampare un vettore dato vettore e dimensione
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void
*/
void input_array(int _v[], int _d);