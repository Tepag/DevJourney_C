/*
dato un certo numero inserito in un array, l'utente inserisce un altro numero, infine troverà se è eseistente nel vet e stampa la posizione nel vettore

RECORD: 13m 28s
*/
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include"e8_lib.c"

#define DIM 10
int main(){
    int arr[DIM];
    //random_array(arr,DIM,10,99);
    input_array(arr,DIM);
    stampaVettore(arr,DIM);
    printf("\n");
    ricerca_arr(arr,DIM);
    getchar();
    return(0);
}