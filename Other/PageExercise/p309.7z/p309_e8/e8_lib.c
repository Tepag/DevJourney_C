
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include"e8_lib.h"

void random_array(int _v[], int _d, int _start, int _end)
{
    int i;
    for (i = 0; i < _d; i++)
        _v[i] = rand() % (_end - _start + 1) + _start;
}

void input_array(int _v[], int _d)
{
    int i;
    for (i = 0; i < _d; i++){
        printf("\ninserire numero nel vettore %d:",i);
        scanf("%d",&_v[i]);
        fflush(stdin);
    }
}

void ricerca_arr(int _v[],int _d){
    int inp=0;
    int i=0;
    printf("\ninserire numero da cercare:");
    scanf("%d",&inp);
    fflush(stdin);
    for(i=0;i<_d;i++){
        if(inp==_v[i]){
            printf("\nTrovato numero %d nella cella: %d",_v[i],i);
        }
    }
}

void stampaVettore(int _v[], int _d)
{
    int i = 0;
    for (i = 0; i < _d; i++)
    {
        printf("%d ", _v[i]);
    }
}