
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#include "e6_lib.h"

float aquad(float _i)
{
    float a = 0;
    a = _i * _i;
    return (a);
}

float acerc(float _r)
{
    float a = 0;
    a = _r * _r * 3.14;
    return (a);
}