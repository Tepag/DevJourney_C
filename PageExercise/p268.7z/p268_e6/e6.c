/*
area cercio o quadrato dopoi che luntent5e ha inserito un numero non negativo, esuccessivamente decide se è del quadra=to o raggio e calcolca area

RECORD:23m 41s
*/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#include "e6_lib.c"

int main()
{
    float inp = 0;
    int choose = 0;
    float area = 0;

    printf("\ninserire numero raggio/lato :");
    scanf("%f", &inp);
    fflush(stdin);

    if (inp >= 0)
    {
        printf("\n1-> area cerchio;");
        printf("\n2-> area quadrato;");
        printf("\n\ninserire scelta:");
        scanf("%d", &choose);
        fflush(stdin);

        switch (choose)
        {
        case 1:
        {
            area = acerc(inp);
            break;
        }
        case 2:
        {
            area = aquad(inp);
            break;
        }
        default:
        {
            printf("\nscelta non disponibile");
            break;
        }
        }

        printf("\narea equivale a: %.2f", area);
    }
    else
    {
        printf("\nil numero inserito non e\' accettabile");
    }

    getchar();
    return (0);
}