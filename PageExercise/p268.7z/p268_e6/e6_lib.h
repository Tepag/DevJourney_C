

/*funzione che va a calolare area quadrato
*/
float aquad(float);

/*funzione che va a calcolare area cerchiop e ritorna l'area
*/
float acerc(float);
