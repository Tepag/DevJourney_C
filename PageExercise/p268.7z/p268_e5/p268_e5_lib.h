/*funzione che va a randomizzare i valori dati inizio e fine e ritorna il valore random
@param int num da randomizzare
@param int numerominimo random
@param int numero massimo random
@return void
*/
int generanumero(int _start, int _end);

int indovinaNumero(int _n);