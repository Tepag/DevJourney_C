#include <time.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include "p268_e5_lib.h"

int generanumero(int _start, int _end)
{
    return (rand() % (_end - _start + 1) + _start);
}

int indovinaNumero(int _n)
{
    int inp = 0;
    printf("\ninserire numero:");
    scanf("%d", &inp);
    fflush(stdin);
    if (inp > _n)
    {
        printf("\nil numero inserito e\' troppo grande");
    }
    else
    {
        if (inp < _n)
        {
            printf("\nil numero inserito e\' troppo piccolo");
        }
        else
        {
            printf("\ncomplimenti hai indovinato!");
            return (1);
        }
    }
}