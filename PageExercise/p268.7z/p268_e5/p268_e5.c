/*
programma con due funzioni:
generanumero(): che va a generere un numero da 4 cifre
indovinaNumero(): che dato un numero inserito: dice se è troppo grande o troppo piccolo
il main controllerà i tentativi utilizzzati

RECORD:20m 44s
*/

#include <time.h>
#include <conio.h>
#include <stdio.h>
#include <stdlib.h>
#include "p268_e5_lib.c"

int main()
{
    int chance = 3;
    int win = 0;
    int num = 0;

    num = generanumero(1000, 9999);
    printf("%d", num);

    //girerà finchè ci sono i tentativi
    while (chance != 0 || win == 0)
    {
        win = indovinaNumero(num);
        chance--;
        if (win == 1)
        {
            chance = 0;
        }
        else
        {
            if (chance == 0)
            {
                printf("\ntentativi esauriti");
            }
        }
    }

    return (0);
}