/*
leggi n numeri e inseriscili in un vettore, inserito un numero num, mettere i numeri minori o ugali in una e maggiori nell'altra, infine stampa 
i numeri non ripetitivi nel vettore

RECORD:22m 08s
*/ 

#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"p268_e3_lib.c"

#define DIM 15

int main(){
    int v1[DIM];
    int v2[DIM];
    int v3[DIM];
    int inp=0;

    initVettore(v1, DIM, 0,99);
    initVettore(v2, DIM, 0,0);
    initVettore(v3, DIM, 0,0);


    printf("inserisci numero:");
    scanf("%d",&inp);
    fflush(stdin);

    spostase(v1, v2, v3, DIM, inp);

    stampaVettore (v2, DIM);
    printf("\n");
    stampaVettore (v3, DIM);
    return 0;
}
