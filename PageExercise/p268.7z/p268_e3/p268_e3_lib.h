
void initVettore(int [], int , int , int );

void spostase(int [], int [], int[], int , int );

void stampaVettore (int [], int );