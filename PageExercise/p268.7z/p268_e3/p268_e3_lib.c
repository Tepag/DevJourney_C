#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"p268_e3_lib.h"

void initVettore(int _v[], int _length, int _start, int _end){
    int i;
    for(i=0; i<_length; i++)
        _v[i] = rand()%(_end-_start+1) + _start;
}

void spostase(int _v[], int _ar[],int _ar2[], int _d, int _inp){
    int i=0;
    int j=0;
    int k=0;
    for (i=0;i<_d;i++){
        if(_v[i]<=_inp){
            _ar[j] = _v[i];
            j++;
        }
        else{
            _ar2[k] = _v[i];
            k++;
        }
    }
}

void stampaVettore (int _v[], int _d){
    int i=0;
    for(i=0;i<_d;i++){
        printf("%d ",_v[i]);
    }
}
