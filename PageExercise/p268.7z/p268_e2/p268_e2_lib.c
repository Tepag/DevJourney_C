#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include"p268_e2_lib.h"

void input(int _arr[], int _d){
    int i=0;
    i=0;
    for(i=0;_arr[i-1]!=0;i++){
        printf("\ninserire numero: ");
        scanf("%d",&_arr[i]);
        fflush(stdin);
        cnt++;
    }
    for(;i!=_d;i++){
        _arr[i]=0;
    }
}

int menuscelta(){
    int c=0;
    system("CLS");
    printf("\nscegliere la base in cui si vuole convertire:");
    printf("\n1-BIN\n2-OCT\n3-HEX");
    printf("\n4-ventesimale");
    printf("\n5-Romano");
    printf("\n\nscelta:");
    scanf("%d",&c);
    fflush(stdin);
    switch(c){
        case 1:{
            return(2);
            break;
        }
        case 2:{
            return(8);
            break;
        }
        case 3:{
            return(16);
            break;
        }
        case 4:{
            return(20);
            break;
        }
        case 5:{
            printf("\nnon sono capace di farlo");
            break;
        }
        default:{
            printf("\nseclta non disponibile");
            break;
        }
    }
}

void decto_(int _vet[], int _b){
    int _d=32;
    int _arr[_d];
    int i=0;
    int j=0;

    for(;j!=cnt-1;j++){
        for(i=0;i<_d;i++){
            _arr[i]=_vet[j]%_b;
            _vet[j]/=_b;
        }

        if(_b<10){
            for(i=_d-1;i>=0;i--){
                printf("%d",_arr[i]);
            }
        }
        else{
            for(i=_d-1;i>=0;i--){
                if (_arr[i]>9){
                    printf("%c",('A'+_arr[i]-10));
                }
                else{            
                    printf("%d", _arr[i]);
                }
            }

        }
        printf("\n\n");
        //ripulisco _arr
        for(i=0;i<_d;i++){
            _arr[i]=0;
        }
    }
    
}