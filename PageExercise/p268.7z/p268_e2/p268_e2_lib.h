/*Funzione cha va a prendere i numeri inseriti dall'utente
@param int array che conterrà i numeri inseriti
@return void
*/
void input(int[], int);

/*Funzione che va a dare le varie scelte
@param int variabile contenmente la scelta fatta
@return int
*/
int menuscelta();

/*Funzione che va a trasformare nelle varie basi
@param int vettore che contengono i numeri da convertire
@param int base di cui si vuole la trasformazione
@return void
*/
void decto_(int[],int);