/*
realizza un convertitore di base dei sistemi di numerazione. Dopo aver letto una sequanza di numeri terminante con 0 (inserito dall'utente), il programma 
deve offrire all'utente la possibilità di convertire tale numero nei seguenti formati:
-BIN
-OCT
-HEX
-vigesimale (base 20)
-romano (facoltativo)

RECORD:46m 50s
*/
int cnt=0;

#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include"p268_e2_lib.c"

#define DIM 999

int main(){
    int vet[DIM];
    int base=0;

    input(vet, DIM);
    base=menuscelta();
    decto_(vet, base);

    system("PAUSE");
    return(0);
}

