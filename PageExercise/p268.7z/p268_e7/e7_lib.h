/*funzione che va a randomizzare il vettore
@param int vettore che si vuole inserire i numeri dalla parte dell'utente
@param int dimensione del vettore
@return void
*/
void initvet(int[], int);

/*funzione che va a randomizzare il vettore
@param int vettore che si vuole inizializzare
@param int dimensione del vettore
@return void
*/
void initvetr(int[], int);

/*funzione che va a fare la media
@param int vettore di cui si vuole trovare la media
@param dimensione vettore
@return int della media
*/
int media(int[], int);

/*funzione che va a calcolare la varianza
@param int vettore dei valori
@param int dimensione vettore
@param int media
@return int della varianza
*/
int varianza(int[], int, float);

/*funzione che stampa vettore media e variazione
@param int vettore che si vuole stampare
@param int dimensione del vettore
@param int media
@param int variazione
@return void
*/
void scrivi(int[], int, float, float);