#include<time.h>
#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include"e7_lib.c"

#define DIM 20

int main(){
    int vet[DIM];
    float med=0;
    float var=0;

    //initvetr(vet, DIM);
    initvet(vet, DIM);
    med=media(vet, DIM);
    //printf("\nla media e\': %d",med);
    var=varianza(vet, DIM, med);
    //printf("\nvarianza equivale a: %d",var);
    scrivi(vet, DIM, med, var);

    return(0);
}
