#include<time.h>
#include<stdlib.h>
#include<conio.h>
#include<stdio.h>
#include"e7_lib.h"

void initvet(int _v[], int _d){
    int i=0;
    for(i=0;i<_d;i++){
        printf("\ninserire numero:");
        scanf("%d",&_v[i]);
        fflush(stdin);
    }
}

void initvetr(int _v[], int _d){
    srand(time(NULL));
    int i=0;
    for(i=0;i<_d;i++){
        _v[i]=(rand()%50)+1;
        //printf("\n%d",_v[i]);
    }
}

int media(int _v[], int _d){
    int i=0;
    int somma=0;
    for(i=0;i<_d;i++){
        somma+=_v[i];
    }
    return(somma/_d);
}

int varianza(int _v[], int _d, float _m){
    //calcolo della varianza euivale a: somma dei quadrati della differenza tra numero e media
    int sommaquadrati=0;
    int i=0;
    for (i=0; i<_d; i++){
        sommaquadrati+=(_v[i]-_m)*(_v[i]-_m);
    }
    return(sommaquadrati/_d);
}

void scrivi(int _v[], int _d, float _m, float _var){
    int i=0;
    printf("\n\nvettore:"); 
    for(i=0;i<_d;i++){
       printf("%d ",_v[i]); 
    }
    printf("\nmedia: %.2f",_m);
    printf("\nvariazione: %.2f",_var);
}