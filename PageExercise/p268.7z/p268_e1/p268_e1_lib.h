/*funzione per dire se è uguale al numero precedente
@param int primo valore inserito precedentemente
@param int secondo valore
@param int contatore 
@param int contatore secondo tipo
@return void
*/
void inputfilter (int *, int *, int *, int *);              //ricorda di mettere * quando si fanno i passaggi per indirizzo

/*funzione che vada col menu
@param int contatore 1
@param int contatore 2
@param int scelta
@return void
*/
void menu (int, int, int *);
