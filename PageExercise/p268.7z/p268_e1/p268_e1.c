/*
sequenza di numeri interi positivi diversi da zero, con l'inserimento di più numeri finchè non viene inserito il numero zero, presenta un menu per
l'esecuzione di vari funzioni
-calcolo di coppie di numeri consecutivi uguali
-calcolo del numero di coppie in cui il secondo è divisorrre del primo (non uguali)
-visualizzazione di un messaggio che dica quale tipo di coppi tra i due precedenti è presente in numero maggiore

RECORD:quit
*/

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include"p268_e1_lib.c"

int main(){
    int v1=0;
    int v2=0;
    int cnt=0;
    int cnt2=0;
    int choose=0;

    //istruzioni
    printf("inserire 0 per fermare");

    do{
        inputfilter(&v1, &v2, &cnt, &cnt2);             //non ti serve dichiarare il tipo
        menu(cnt, cnt2, &choose);
    }while(choose!=0);
    
    
    return(0);
}