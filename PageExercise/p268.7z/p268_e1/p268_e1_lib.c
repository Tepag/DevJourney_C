#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include"p268_e1_lib.h"

void inputfilter (int *_v1, int *_v2, int *_c1, int *_c2){
    //inserimento dei numeri
    do{
        printf("\ninserire valore:");
        scanf("%d", _v1);
        fflush(stdin);

        printf("%d", *_v1);

        //controllo se il numero e il numero inserito precedentemente sono uguali o sono divisibili
        if(*_v1 == *_v2){
            *_c1 = *_c1+1;
            printf("cnt = %d",*_c1);
        }
        else{
            if(/**/(*_v1!=0)/**/ && (*_v2%*_v1 == 0 && *_v2!=*_v1)){    // mancava il controllo che _v1 non sia 0, altrimenti _v2%_v1 sarebbe un division by zero e ti blocca il programma.
                printf("cnt2 = %d",*_c2);
                *_c2++;
            }
        }
        *_v2=*_v1;
    }
    while(*_v1!=0);
}

void menu (int _cnt, int _cnt2, int *_choose){

    //visualizzazione menu
    printf("\n\n1-> coppie numeri consecutivi uguali");
    printf("\n2-> coppie dove il secondo numero e\' dicisore del primo");
    printf("\n3-> qual\' e\' il maggiore tra due opzioni precedenti");
    printf("\n0-> EXIT");
    printf("\n\n scelta:");
    scanf("%d", _choose);
    fflush(stdin);
        
    switch(*_choose){
        case 1:{
            printf("\nil numero di coppie uguali consecutive e\': %d", _cnt);
            break;
        }

        case 2:{
            printf("\nil numero di coppie uguali consecutive e\': %d", _cnt2);
            break;
        }

        case 3:{
            if(_cnt>_cnt2){
                printf("coppie uguali consecutive di %d", _cnt);
            }
            else{
                printf("coppie divisibili di %d", _cnt2);
            }
            break;
        }

        case 0:
            system("PAUSE");
            break;

        default:{
            printf("\nscelta non disponibile");
            break;
        }
    }
}
