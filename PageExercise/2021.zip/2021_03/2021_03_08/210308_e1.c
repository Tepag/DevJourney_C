//LE FUNZIONI

//LIBRERIE
#include<conio.h>
#include<stdio.h>
#include<stdlib.h>

//COSTANTI


//PROTOTIPI
/*
funzione che calcola il perimetro con dimensioni passati per valore
@param int lato 1
@param int lato 2
@return void.
*/
void perimetroRettangolo(int, int);


//MAIN
int main(){
    int a;
    int b;

    //acquisisco i due numeri in entrata
    printf("\ninserire lato 1:");
    scanf("%d",&a);
    fflush(stdin);

    printf("\ninserire lato 2:");
    scanf("%d",&b);
    fflush(stdin);

    //richiamo funzione
    perimetroRettangolo(a,b);

    getchar();
    return(0);
}

void perimetroRettangolo(int _l1, int _l2){
    _l2=_l1*2+_l2*2;
    printf("\n%d",_l2);
}