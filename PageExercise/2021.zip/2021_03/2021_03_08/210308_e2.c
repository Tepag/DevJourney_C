/*
inseriti numeri decimali da tastiera trasformarli in HEX e facciamo la somma
*/

#include<conio.h>
#include<stdio.h>
#include<stdlib.h>

#define HEX 16
#define DIM 12

/*
questa funzione trasforma da decimale a esadecimale
@param int valore da trasformare
@param int array dove si vuole contenere il numero
@return void
*/
void DECtoHEX (int, int[]);

/*
questa funzione farà la somma tra due dumeri in HEX
@param int ar1
@param int ar2
@return void
*/
void SUM (int[],int[]);

int main(){
    int ar1[DIM];
    int ar2[DIM];
    int v1=0;
    int v2=0;

    //input valori
    printf("inserire valore 1:");
    scanf("%d",&v1);
    fflush(stdin);
    printf("inserire valore 2:");
    scanf("%d",&v2);
    fflush(stdin);
    
    DECtoHEX (v1,ar1);
    //DECtoHEX (v2, ar2[]);
    //SUM (ar1[], ar2[]);
    getchar();
    return(0);
}

void DECtoHEX (int _v, int _a[]){
    int i=0;
    for(i=0;i<DIM;i++){
        _a[i]=_v%2;
        _v/=2;
    }
    for(i=DIM-1;i>=0;i--){
        printf("%d",_a[i]);
    }
}