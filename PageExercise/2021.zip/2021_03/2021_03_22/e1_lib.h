/*funzione che va a inizializzare il vettore
@param int vettore
@param int dimensione vettore
@return void
*/
void initVettore (int[], int);

/*funzione che va a stampare un vettore
@param int vettore
@param int dimensione vettore
@return void
*/
void stampaVettore (int[], int);

/*funzione che va a cercare il numero di volte in cui si ripete un numero data dall'utente
@param int vettore
@param int dimensione vettore
@return int
*/
int ricercaValore (int[], int);

/*funzione che dati due indici possibili esegue lo scambio
@param int vettore
@param int indice 1
@param int indice 2
@param int dimensione array
@return int
*/
int swapValori (int[], int, int, int);

/*funzione che dati due array di dimensioni uguali controlla se sono uguali o meno
@param int vettore1
@param int vettore2
@param int dimensione vettori
@return void
*/
int equalsVettori (int[], int[], int);