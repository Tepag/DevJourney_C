/*
Realizzare un programma C che sviluppi le seguenti funzioni:
1. initVettore -> inizializza un vettore di 15 elementi con valori casuali tra 1 e 50 estremi compresi.
2. stampaVettore -> visualizza l'intero vettore.
3. ricercaValore -> Riceve un vettore ed un valore da ricercare, restituisce il numero di volte che trova il valore nel vettore.
4. swapValori -> riceve un vettore e due indici, quindi scambia il valore delle celle identificate dagli indici. Ritorna 1 se l'operazione è stata eseguita, ritorna 0 se gli indici non sono validi.
5. equalsVettori -> riceve due vettori di uguale lunghezza e verifica che siano uguali oppure no.
ritorna 1 se i due vettori sono uguali, 0 se non sono uguali.
*/

//RECORD:40m 38s


#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<time.h>
#include"e1_lib.c"

#define DIM 15

int main(){
    int vet[DIM];
    int vet2[DIM];
    int cnt=0;
    int indice1=0;
    int indice2=0;


    initVettore(vet,DIM);
    initVettore(vet2,DIM);

    printf("\ncontenuto primo array:\n\n");
    stampaVettore(vet,DIM);

    printf("\ncontenuto secondo array:\n\n");
    stampaVettore(vet2,DIM);

    cnt=ricercaValore(vet,DIM);
    printf("\n\nil numero cercato si ripete per %d volta/volte nel vettore",cnt);
    printf("\n\ninserire due indici per scambiare le loro posizioni:\n1-");
    scanf("%d",&indice1);
    fflush(stdin);
    printf("\n2-");
    scanf("%d",&indice2);
    fflush(stdin);

    if (swapValori(vet, indice1, indice2, DIM)==1){
        printf("\noperazione completata");
    }
    else{
        printf("\noperazione non completata");
    }

    if((equalsVettori(vet, vet2, DIM))==1){
        printf("\ni due vettori risultano uguali");
    }
    else{
        printf("\ni due vettori non risultano uguali");
    }
    
    getchar();
    return(0);
}
