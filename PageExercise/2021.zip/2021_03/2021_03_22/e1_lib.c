#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<time.h>
#include"e1_lib.h"

void initVettore (int _v[], int _d){
    srand(time(NULL));
    int i=0;
    for(i=0;i<_d;i++){
        _v[i]=(rand()%50)+1;
    }
}

void stampaVettore (int _v[], int _d){
    int i=0;
    for(i=0;i<_d;i++){
        printf("%d ",_v[i]);
    }
}

int ricercaValore(int _v[], int _d){
    int inp=0;
    int i=0;
    int cnt=0;
    printf("\n\ninserire numero da cercare: ");
    scanf("%d",&inp);
    fflush(stdin);
    for(i=0;i<_d;i++){
        if(inp==_v[i]){
            cnt++;
        }
    }
    return(cnt);
}

int swapValori (int _v[], int _v1, int _v2, int _d){
    int tmp=0;
    if( (_v1<_d&&_v1>0) && (_v2<_d&&_v2>0)){
        tmp=_v[_v1];
        _v[_v1]=_v[_v2];
        _v[_v2]=tmp;
        return(1);
    }
    else{
        return(0);
    }
}

int equalsVettori (int _v1[], int _v2[], int _d){
    int i=0;
    int cnt=0;
    for(i=0; i<_d; i++){
        if(_v1[i] == _v2[i]){
            cnt++;
        }
    }
    if(cnt==_d){
        return(1);
    }
    else{
        return(0);
    }
}