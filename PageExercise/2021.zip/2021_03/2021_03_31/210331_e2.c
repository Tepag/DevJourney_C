#include<stdlib.h>
#include<stdio.h>
#include<conio.h>

int main()
{
    int dim, riga, i, output;

    //inserisco la dim finchè non sarà maggiore di 0
    do
    {
        printf("\nInserisci la dimensione: ");
        scanf("%d", &dim);
    } while (dim <= 0);



    riga = 0;
    do{
        i=0;
        do{
            printf(" ");
            i++;
        }while (i < dim - riga);

        i=0;
        do{
            if (i == 0)
                output = 1;
            else
                output = output * (riga - i + 1) / i;
            printf("%d ", output);
            i++;
        }while (i <= riga);

        printf("\n");
        riga++;
    }while (riga <= dim);
}
