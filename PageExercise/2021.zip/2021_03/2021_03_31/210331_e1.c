//triangolo di tartaglia

#include <stdio.h>
#include <stdlib.h>
/*
int main()
{
    int dim, riga, i, output;

    //inserisco la dim finchè non sarà maggiore di 0
    do
    {
        printf("\nInserisci la dimensione: ");
        scanf("%d", &dim);
    } while (dim <= 0);

    riga = 0;
    i = 0;
    output = 1;
    for (riga = 0; riga <= dim; riga++)
    {
        /*
        ___
        __
        _
        spaziatura a sinistra
        *//*
        for (i = 0; i < dim - riga; i++)
        {
            printf("  ");
        }

        //formula generazione numeri quadrato di tartaglia
        for (i = 0; i <= riga; i++)
        {
            if (i == 0)
                output = 1;
            else
                output = output * (riga - i + 1) / i;
            printf("%4d", output);
        }
        printf("\n");
    }
}
*/


int main()
{
    int dim, riga, i, output;

    //inserisco la dim finchè non sarà maggiore di 0
    do
    {
        printf("\nInserisci la dimensione: ");
        scanf("%d", &dim);
    } while (dim <= 0);



    riga = 0;
    do{
        i=0;
        do{
            printf(" ");
            i++;
        }while (i < dim - riga);

        i=0;
        do{
            if (i == 0)
                output = 1;
            else
                output = output * (riga - i + 1) / i;
            printf("%d ", output);
            i++;
        }while (i <= riga);

        printf("\n");
        riga++;
    }while (riga <= dim);
}

/*
int fat(int f)
{
    int output = 1;

    if (f == 0)
    {
        return 1;
    }

    for (; f >= 1; f--)
    {
        output = output * f;
    }

    return output;
}

main()
{
    int dim, i, i, n, k, x, val;
    do
    {
        printf("Inserisci la dim: ");
        scanf("%d", &dim);
    } while (dim < 1);

    for (i = 0; i <= dim; i++)
    {
        for (i = 0; i < dim - i; i++)
        {
            printf("  ");
        }
        for (i = 0; i <= i; i++)
        {
            n = fat(i);
            k = fat(i);
            x = fat(i - i);
            val = n / (k * x);
            printf("%4d", val);
        }
        printf("\n");
    }
    printf("\n\n");
    system("pause");
}
*/