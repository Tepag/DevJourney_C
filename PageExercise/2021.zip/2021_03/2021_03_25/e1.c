/*
Programma che risolva es 109 pagina 762 di matematica 
1--> inizializzo la matrice con numeri da tastiera
2--> stampa matrice 
3--> calcolo il totale delle righe e delle colonne e lo comunico 

fatto da: Marcheselli Alessandro
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int c, r;
/*Funzione che inzializza la matrice a 0
@param int [][c] matrice 
@param int righe matrice 
@param int colonne matrice 
@return void 
*/
void init(int[r][c], int, int);

/*
Funzione che inizializzi una matrice con valori da tastiera 
@param int [][C] matrice 
@param int dimensione righe matrice 
@param int dimensione colonne matrice 
@return void 
*/
void scanMat(int[r][c], int, int);

/*
Funzione che stampa una matrice 
@param int [][C] matrice 
@param int dimensione righe 
@param int dimensione colonne matrice 
@return void
*/
void printMat(int[r][c], int, int);

/*
Funzione che calcola il totale delle righe e delle colonne e lo inserisca al interno della matrice 
@param int [][C] matrice 
@param int dimensione righe matrice 
@param int dimensione righe matrice
@return void
 */
void calcTot(int[r][c], int, int);

int main()
{
    printf("\nnumero di righe: ");
    scanf("%d", &r);
    fflush(stdin);

    printf("\nnumero di colonne: ");
    scanf("%d", &c);
    fflush(stdin);

    int mat[r + 1][c + 1];
    init(mat, r, c);
    //1--> inizializzo la matrice con numeri da tastiera
    scanMat(mat, r, c);
    //2--> stampa matrice
    printMat(mat, r, c);
    //3--> calcola il totale di delle righe e delle colonne
    calcTot(mat, r, c);

    printf("\n");
    getchar();
    return 0;
}

void init(int m[r][c], int r, int c)
{
    int i, j;
    for (i = 0; i < r + 1; i++)
    {
        for (j = 0; j < c + 1; j++)
        {
            m[i][j] = 0;
        }
    }
}

void scanMat(int m[r][c], int r, int c)
{
    int i, j;
    for (i = 0; i < r; i++)
    {
        for (j = 0; j < c; j++)
        {
            printf("\ninserisci il numero nella cella %d,%d\n", i, j);
            scanf("%d", &m[i][j]);
            fflush(stdin);
        }
    }
}

void printMat(int m[r][c], int r, int c)
{
    int i, j;
    printf("\nstampa la matrice");
    for (i = 0; i < r; i++)
    {
        printf("\n");
        for (j = 0; j < c; j++)
            printf("%-5d", m[i][j]);
    }
}

void calcTot(int m[r][c], int r, int c)
{
    int i, j;
    int tot;
    printf("\nstampo la matrice con la distribuzione marginale");
    //printMat(m, r + 1, c + 1);
    tot = 0;

    // totale colonne
    tot = 0;
    for (i = 0; i < r; i++)
    {
        tot = 0;
        for (j = 0; j < c; j++)
        {
            tot = tot + m[j][i];
        }
        m[r][i] = tot;
    }
    //printMat(m, r + 1, c + 1);

    // totale righe
    for (i = 0; i < r; i++)
    {
        tot = 0;
        for (j = 0; j < c; j++)
        {
            tot = tot + m[i][j];
        }
        m[i][c] = tot;
    }

    //printMat(m, r + 1, c + 1);

    // cella r,c
    tot = 0;
    for (i = 0; i < r; i++)
    {
        tot = tot + m[r][i];
    }
    m[r][c] = tot;

    printMat(m, r + 1, c + 1);
}
