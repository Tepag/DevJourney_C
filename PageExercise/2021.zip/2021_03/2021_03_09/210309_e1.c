// funzione che calcola e stampa la media dei valori di un vettore

#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include"210309_e1_lib.c"

#define DIM 10

//void Media(int[], int)
//se si usano le librerie da file diverse non serve che lo dichiari

int main(){
    int vet[DIM];

    Rand(vet,DIM);
    Media(vet, DIM);
    magandmin(vet,DIM);

    return(0);
}