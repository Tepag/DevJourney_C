#include<conio.h>
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"210309_e1_lib.h"

void Rand(int arr[], int dim){
    int i=0;
    int rangemin=0;
    int rangemax=0;

    srand(time(NULL));

    printf("inserire range minimo di cui si vuole avere:");
    printf("\nfrom: ");
    scanf("%d",&rangemin);
    fflush(stdin);
    printf(" to: ");
    scanf("%d",&rangemax);
    fflush(stdin);

    for(i=0;i<dim;i++){
        arr[i]=(rand()%rangemax)+rangemin;
    }


}

void Media(int arr[],int dim){
    int i=0;
    int media=0;
    for(i=0;i<dim;i++){
        media+=arr[i];
        printf("%d ",arr[i]);
    }
    
    media/=dim;
    printf("\n\n\nmedia: %d\n\n\n",media);
}

void magandmin(int arr[], int dim){
    int i=0;
    int mag=0;
    int min=0;

    mag=arr[0];
    min=arr[0];

    for(i=0;i<dim;i++){
        if(arr[i]<min){
            min=arr[i];
        }
        else{
            if(arr[i]>mag){
                mag=arr[i];
            }
        }
    }

    i=0;
    for(i=0;i<dim;i++){
        if(arr[i]==mag){
            printf("%d maggiore alla posizione %d\n\n",mag,i);
        }
        else{
            if(arr[i]==min){
                printf("%d minimo alla posizione %d",min,i);
            }
        }  
    }
}
