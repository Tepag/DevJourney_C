/*Funzione che inizializza il vvettore con i valori scelti da utente
@param int range minimo
@param int range massimo
*/
void Rand (int [], int);

/*Funzione che calcola la media
@param int array contenenti i valori che si vuole fare la media
@param int numero dimensione
@return void
*/
void Media (int [], int );

/*Funzione che determina e stampa il valore maggiore e valore minore con le relative posizioni
@param int array
@param int dimensione
@return void
*/
void magandmin (int [],int );