
#include<stdio.h>
//#include<conio.h>
#include<time.h>
#include<stdlib.h> 
#include"e1_lib.h"

void trovadivisori(int _n, int _d){
    if(_n>=_d){
        if(_n%_d == 0){
            printf("%d ", _d);
            
        }
        trovadivisori(_n, _d+1);
    }
    else{
        printf("\nho terminato");
    }
}

void randvet(int *_v, int _d, int _start, int _end){
    srand(time(NULL));
    int i=0;
    for(i=0; i<_d; i++){
        *(_v+i)=rand() % (_end - _start + 1) + _start;
    }
}

void stampavet(int *_p, int _d){
    int i=0;
    for(i=0; i<_d; i++){
        printf("%d ",*(_p + i));
    }
}   

int verifica_numero_primo(num){
    int cnt = 0;
    int div=0;
    while(div<=num){
        if(num%div == 0){
            cnt++;
        }
        div++;
    }
    if(cnt <= 2 ){
        return(1);
    }
    else{
        return 0;
    }
}

void stampanumprimi(int *_p, int _d){
    int i=0;
    int cnt=0;
    for(i=0; i<_d; i++){
        if(verifica_numero_primo( *(_p+i)) == 1){
            printf("%d ", *(_p+i));
        }
    }
}

