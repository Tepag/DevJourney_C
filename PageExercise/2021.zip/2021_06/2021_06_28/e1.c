/*
    1- Visualizzare tutti i divisori di un numero con una funzione ricorsiva.
    2- Inizializzare un vettore di 10 elementi interi con numeri random tra 1 e 50.
        - Stampare il vettore (funzione).
        - Stampare solo i valori primi (due funzioni distinte).
        - Il vettore deve essere gestito con i PUNTATORI.

    RECORD: 1h 14m 34s
*/

#include<stdlib.h>
#include<stdio.h>
//#include<conio.h>
#include<time.h>
#include "e1_lib.c"

#define DIM 10

int main(){
    srand(time(NULL));
    //prima richiesta
    int num=8;
    int div =1;

    //seconda richiesta
    int vet[DIM];
    int *p = &vet[0];

    //prima richiesta
    trovadivisori(num, div);

    // seconda richiesta
    randvet(p, DIM, 1, 50);
    printf("\n");
    stampavet(p, DIM);
    printf("\n");
    stampanumprimi(p, DIM);

    return 0;
}