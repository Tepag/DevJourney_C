
void trovadivisori(int, int);

void randvet(int *, int _d, int _start, int _end);

void stampavet(int *, int _d);