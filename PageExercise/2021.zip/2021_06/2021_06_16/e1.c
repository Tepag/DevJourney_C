/*
riordinare un vettore tramite funzione e ordinare anche una matrice tramite puntatori
*/

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>

#define DIM 5

void rand_vet(int* , int);

void rand_mat(int*, int, int);

void stampa_vet(int *, int);
int main(){
    int vet[DIM];
    int mat[DIM][DIM];

    rand_vet(vet, DIM);
    stampa_vet(vet, DIM);
}

void rand_vet(int *_v, int _d){
    srand(time(NULL));
    int i=0;
    for(i=0; i <_d;i++){
        *(_v+i) = rand()%10;
    }
}

void stampa_vet(int *_v, int _d){
    int i=0;
    for(i=0; i<_d; i++){
        printf("%0.2d ", *(_v+i));
    }
}