#include <stdio.h>
#include<time.h>
#include<stdlib.h>
//#include"e1_lib.h"
void initvettore(int _v[],int _d){
    srand(time(NULL));
    int i=0;
    for(i-0;i<_d;i++){
        _v[i]=(rand()%99)+1;
    }
}
void visualizza_vettore(int _v[], int _d){
    int i=0;
    for(i=0;i<_d;i++){
        printf("%d ",_v[i]);
    }
}
int searchmax(int _v[], int _d){
    int i=0;
    int max=0;
    max=_v[0];
    for(i=0;i<_d;i++){
        if(max<_v[i]){
            max=_v[i];
        }
    }
    return (max);
}
void mediavet(int _v[], int _d){
    int i,media,somma;
    media=0;
    somma=0;
    for(i=0;i<_d;i++){
        somma+=_v[i];
    }
    media=somma/_d;
    printf("\n\nla media della matrice e\': %d",media);
}
void swapvet(int _v[], int _d ){
    int i=0;
    int p1=0;
    int p2=0;
    int tmp=0;
    printf("\ninserire la prima cella: ");
    scanf("%d",&p1);
    fflush(stdin);
    printf("\ninserire la seconda cella: ");
    scanf("%d",&p2);
    fflush(stdin);
    if(p1<_d&&p1>=0){
        if(p2<_d&&p2>=0){
            tmp=_v[p1];
            _v[p1]=_v[p2];
            _v[p2]=tmp;
        }
        visualizza_vettore(_v,_d);
    }
    else{
        printf("\nposizioni non corrette");
    }
}

