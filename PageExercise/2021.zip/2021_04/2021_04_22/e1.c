/*
adattare funzione di random vettore con le funzioni ricorsive
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e1_lib.c"

#define DIM 10

int main(){
    int vet[DIM];
    random_array_rcrs(vet,DIM,0,10,0);
    stampaVettore(vet,DIM);
    return 0;
}