#include <stdio.h>

int esponenziale(int _num, int _exp);

int main(){
    int num=0;
    int exp=0;
    int ris=0;

    printf("\ninserisci numero: ");
    scanf("%d",&num);
    fflush(stdin);
    printf("\nlo vuoi elevare alla: ");
    scanf("%d",&exp);
    fflush(stdin);

    ris=esponenziale(num, exp);
    printf("\n\nrisulatato: %4d\n\n",ris);
    return 0;
}

int esponenziale(int _num, int _exp){
    if (_exp>1){
        _num*=esponenziale(_num,_exp-1);
    }
    else{
        return(_num);
    }
}