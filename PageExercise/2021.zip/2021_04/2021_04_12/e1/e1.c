/*
    Programma che inizializza un vettore di 5 elementi random compresi tra 1 e 20 ed una
    matrice 10x5 con numeri random compresi tra 1 e 20.
    - Inizializzare vettore e matrice.
    - Stampare a video vettore e matrice.
    - Confrontare la matrice con il vettore e visualizzare solo quelle righe che hanno
    somma totale maggiore della somma del vettore.
    (CON FUNZIONI)

    RECORD:21m 29s
*/



#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e1_lib.c"

#define R 10
#define C 5
#define DIM 5

/*funzione che randomizza una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void random_mat(int _m[][C], int _r, int _c, int _start, int _end);

/*funzione che randomizza una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][C], int _r, int _c);

/*funzione che randomizza una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@param int somma
@return void
*/
void stampaMat_se(int _m[][C], int _r, int _c, int _s);


int main(){
    int vet[DIM];
    int mat[R][C];
    int somma=0;

    random_array(vet,DIM,1,20);
    random_mat(mat,R,C,1,20);

    stampaVettore(vet,DIM);
    printf("\n\n");
    stampaMat(mat,R,C);
    printf("\n\n");
    somma=somma_arr(vet,DIM);
    stampaMat_se(mat,R,C,somma);
    return 0;


}

void random_mat(int _m[][C], int _r, int _c, int _start, int _end){
    int i, j;
    for(i=0; i<_r; i++){
        for(j=0; j<_c; j++){
            _m[i][j] = rand() % (_end - _start + 1) +_start;
        }
    }
}

void stampaMat(int _m[][C], int _r, int _c){
    int i,j;
    for(i=0; i<_r; i++){
        for(j=0; j<_c; j++){
            printf("%3d", _m[i][j]);
        }
        printf("\n");
    }
}

void stampaMat_se(int _m[][C], int _r, int _c, int _s){
    int i,j;
    int somma_r=0;
    for(i=0; i<_r; i++){
        for(j=0; j<_c; j++){
            somma_r+=_m[i][j];
        }
        if(somma_r>_s){
            for(j=0; j<_c; j++){
                printf("%3d",_m[i][j]);
            }
        }
        else{
            for(j=0; j<_c; j++){
                printf("---");
            }
        }
        printf("\n");
    }
}