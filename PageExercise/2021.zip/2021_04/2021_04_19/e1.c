/*
FUNZIONI RICORSIVE
*/  

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

/*funzione ricorsiva che va a a stampare decrementando
@param int num numero da cui partire
@return void*/
void rovescia(int n);

int main(){
    int n=0;

    printf("\ninserisci numero: ");
    scanf("%d",&n);
    fflush(stdin);

    rovescia(n);

    return(0);
}

void rovescia(int n){
    if(n==0){
        printf("FINE!");
    }
    else{
        rovescia(n-1);
        printf("%d ",n);
        //rovescia(n-1);
    }
}