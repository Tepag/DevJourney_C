#include <stdio.h>
#include <stdlib.h>

// ! qua non ho capito
int main(int arg, char **args)
{
    printf("ciao");
    int n;

    for (int i = 0; i < 3; i++)
    {
        static int n2 = 2; //! la static funziona anche per i cicli
        printf("\n%d", n2);
        n2++;
    }

    return 0;
}

int count()
{
    // !la creazione della variabile solo una volta
    static int x = 0;
    x++;
    return x;
}

// malloc e free sono più utili per quando si utilizza un programma infinita, per esempio il serverweb
// memory leak: leak perde qualcosa(in questo caso la memoria), senza utilizzare la free, che prima o poi si riempirà
// ! la free deve essere utilizzata solo utilizzando il puntatore generato dalla malloc