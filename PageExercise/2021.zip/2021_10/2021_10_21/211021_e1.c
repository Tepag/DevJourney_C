#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

#define RIGHE 5
#define DIM 20

// qua ci va l'inserimento dei varie funzioni terze da includere

/*incapsulamento della funzione che va a restituire la lunghezza di una stringa
@param char* puntatore alla prima cella della parola
return int della lunghezza della stringa*/
int len_str_tail_fun(char *);

/*Funzione che va a restituire la lunghezza di una stringa
@param char* puntatore alla prima cella della parola
@param int numero iniziale del accumulatore
return int della lunghezza della stringa*/
int len_str_tail(char *, int);

/* Funzione che s�restituisce l'indice della stringa pi� lunga
@param char* puntatore alla prima cella della parola
@param int del numero delle righe
return int del indice della stringa pi� lunga
*/
int check_longest(char[][DIM], int);

/* Funzione che restituisce l'indice della stringa pi� lunga
@param char* puntatore alla prima cella della parola
@param int del numero delle righe
return int del indice della stringa pi� lunga
*/
int check_longest_with_pointer(char *, int, int);

int main()
{
	char elenco[RIGHE][DIM];
	int i = 0;

	// ciclo inserimentociclo
	for (i = 0; i < RIGHE; i++)
	{
		printf("inserisci stringa: ");
		scanf("%s", elenco[i][0]);
		fflush(stdin);
	}

	for (i = 0; i < RIGHE; i++)
	{
		printf("\n%d %s -> lun= %d", i, elenco[i], len_str_tail_fun(&elenco[i][0]));
	}

	printf("\n\nindice maggiore: %d", check_longest(elenco, RIGHE));

	printf("\n\nindice maggiore: %d", check_longest_with_pointer(&elenco[i][0], RIGHE, DIM));

	return 0;
}

int len_str_tail_fun(char *text_peek)
{
	return len_str_tail(text_peek, 0);
}

int len_str_tail(char *text_peek, int _acc)
{
	return *text_peek != '\0' ? len_str_tail(++text_peek, ++_acc) : _acc;
}

int check_longest(char list[][DIM], int _r)
{
	int longest_i = 0;
	// int i=0;
	for (int i = 0; i < _r; i++)
	{
		if ((len_str_tail_fun(&list[i][0])) > (len_str_tail_fun(&list[longest_i][0])))
		{
			longest_i = i;
		}
	}
	return longest_i;
}

int check_longest_with_pointer(char *text_peek, int _r, int _d)
{
	int longest_i = 0;
	for (int i = 0; i < _r; i++)
	{
		if ((len_str_tail_fun(text_peek + (i * _d)) > (len_str_tail_fun(text_peek + (longest_i * _d)))))
		{
			longest_i = i;
		}
	}
	return longest_i;
}
