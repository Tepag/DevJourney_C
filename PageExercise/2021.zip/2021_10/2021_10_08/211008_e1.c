#include <time.h>
#include <stdio.h>
#include <stdlib.h>

void fun(const int *_p);

int main()
{
    int vet[8] = {1, 2, 3, 4, 5, 6, 7, 8};
    int n = 0;

    //malloc (in byte)
    // int *p = (int)malloc(sizeof(int)*3);
    int *p = malloc(100);

    fun(vet);

    // condizione ? valore vero : valore falso
    printf("\n\n%d", n != 0 ? n : vet[4]);
    printf("\n\n%d", n == 0 ? n : vet[4]);
    n == 0 ? printf("ciao") : printf("nope");

    *p = 255;
    printf("\n\n%d ", *p);
    // dalla funzione free(const void *p);
    free(p);

    return 0;
}

//nelle librerie si utilizza il const int *puntatore
void fun(const int *_p)
{
    printf("%d", *(_p + 3));
}
