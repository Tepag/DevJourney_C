#include <stdio.h>
#include <stdlib.h>

#define DIM 21

/*Funzione che verifica se una stringa è maggiore di un'altra stringa
@param char* puntatore alla prima cella della prima stringa
@param char* puntatore alla prima cella della prima stringa
return int 0==no|1==sì
*/
int det_mag(char *, char *);

int main()
{
    char str[DIM], str2[DIM];
    char *start_testo = str, *start_testo2 = str2;

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo);
    fflush(stdin);

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo2);
    fflush(stdin);

    det_mag(start_testo, start_testo2) == 1 ? printf("\nerror detected") : printf("\nno error detected");
    // dato che la funzione richiede solo di trovare il caso di maggiore e di minore, ho fatto in modo che l'uguale sia considerato un errore

    return 0;
}

int det_mag(char *text_peek, char *text_peek2)
{
    for (; *text_peek != '\0'; text_peek++, text_peek2++)
    {
        if (*text_peek == *text_peek2)
            continue;
        else
        {
            if (*text_peek < *text_peek2)
            {
                printf("\nil primo e\' minore della seconda stringa");
                return 0; // stampo e ritorno che ci sono 0 errori
            }
            else
            {
                printf("\nil primo e\' maggiore della seconda stringa");
                return 0; // stampo e ritorno che ci sono 0 errori
            }
        }
    }
    return 1; // ritorno per dire che c'è stato un errore
}