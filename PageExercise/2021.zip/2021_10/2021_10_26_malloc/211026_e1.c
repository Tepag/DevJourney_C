/*
copia di una stringa dentro ad un'altra stringa
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

#define DIM 21

/*Funzione che verifica se una stringa è sottostringa di un'altra stringa
@param char* puntatore source
@param char* puntatore destination
@return void
*/
void copy_to(char *, char *);

char *clone(char *);

void stampa_str(char *);

char *merge(char *, char *);

// TODO: prova a farle da zero il funzione clone e merge

int main()
{
    char str[DIM], str2[DIM];
    char *start_testo = str, *start_testo2 = str2;

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo);
    fflush(stdin);

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo2);
    fflush(stdin);

    // funzione che va a copiare una stringa in un'altra stringa
    char *text1 = clone(start_testo);
    stampa_str(text1);
    printf("\n");

    // funzione che va a unire due stringhe
    char *text2 = merge(start_testo, start_testo2);
    stampa_str(text2);

    free(text2);

    return 0;
}

void stampa_str(char *text_start)
{
    if (*text_start != '\0')
    {
        printf("%c", *text_start);
        stampa_str(text_start + 1);
    }
}

void copy_to(char *source, char *destination)
{
    while (*source != '\0')
    {
        *destination = *source;
        destination++, source++;
    }
}

char *clone(char *s)
{
    int len = strlen(s);                              // funzione lunghezza della stringa;
    char *d = (char *)malloc(sizeof(char) * len + 1); //+1 per il \0
    copy_to(s, d);
    return d;
}

char *merge(char *s1, char *s2)
{
    int len1 = strlen(s1), len2 = strlen(s2);                     // funzione lunghezza della stringa;
    char *d = (char *)malloc((sizeof(char) * (len1 + len2)) + 1); //+1 per il \0
    copy_to(s1, d);
    copy_to(s2, d + len1);
    return d;
}