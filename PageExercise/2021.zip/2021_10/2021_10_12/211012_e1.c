/*
Creare una matrice di dimensioni 5x5, con diversi funzioni:
- inizializza a valori casuali tra 72 e 124
- stampa la matrice
- reverse della matrice

RECORD: 15m 32s
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 5

void init_mat(int *, int, int, int);

void view_mat(int *, int, int);

void reverse_mat(int *, int);

int main()
{
    int mat[DIM][DIM];
    int *mat_allias = &mat[0][0];

    init_mat(mat_allias, DIM * DIM, 124, 72);
    view_mat(mat_allias, DIM * DIM, DIM);
    reverse_mat(mat_allias, DIM * DIM);
    printf("\n\n");
    view_mat(mat_allias, DIM * DIM, DIM);

    return 0;
}

void init_mat(int *_pm, int _l, int _max, int _min)
{
    srand(time(NULL));
    for (int i = 0; i < _l; i++)
    {
        *(_pm + i) = rand() % (_max - _min + 1) + _min;
    }
}

void view_mat(int *_pm, int _l, int _r)
{
    for (int i = 0; i < _l; i++)
    {
        printf("%0.3d ", *(_pm + i));
        if ((i + 1) % _r == 0)
        {
            printf("\n");
        }
    }
}

void reverse_mat(int *_pm, int _l)
{
    int box = 0;
    for (int i = 0; i < _l / 2; i++)
    {
        box = *(_pm + i);
        *(_pm + i) = *(_pm + (_l - i - 1));
        *(_pm + (_l - i - 1)) = box;
    }
}
