/*
gioco dell'impiccatop utilizzando 8 cifre
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM_PC 8
#define DIM_USER 32

/*Funzione che inizializza una matrice tramite puntatore 
@param int* vettore 
@param int dimensione del vettore
@return void 
*/
void init_vet(int *, int);

void init_a_one(int *, int);

int main()
{
    int pc_guess[DIM_PC];
    int user_guess[DIM_USER];
    int i = 0, j = 0, k = 0;
    int peek_user_list = 0;
    int exit_flag = 0;
    int found_flag = 0, found_flag_2 = 0, found_flag_3 = 0;
    int error = 0;
    int input = 0;

    //inizializzo i numeri random del pc che noi dovremo indovinare
    init_vet(pc_guess, DIM_PC);
    init_a_one(user_guess, DIM_USER);

    //inizio del gioco
    while (exit_flag == 0)
    {
        //visualizza i numeri che sono stati indovinati e visualizza i errori
        printf("\n\n");
        found_flag = 0;
        for (i = 0; i < DIM_PC; i++)
        {
            for (j = 0; j < DIM_USER; j++)
            {
                // metto la condizione se nella lista dei numeri indovinati è uguale al numero della lista dove ci sono i numeri da indovinare li stampo
                if (pc_guess[i] == user_guess[j])
                {
                    printf("%d ", pc_guess[i]);
                    found_flag++;
                    break;
                }
            }
            if (found_flag == 0)
            {
                printf("_ ");
                continue;
            }
            else
                found_flag = 0;
        }

        //input
        printf("\n\nerrori attuali: %d", error);
        printf("\ninserire un numero tra 0 e 9: ");
        scanf("%d", &input);
        fflush(stdin);

        //vedere se è già presente, se già presenta stampa un messaggio di errore, se non presente aggiungi
        for (i = 0; i < DIM_USER; i++)
        {
            if (user_guess[i] == input)
            {
                found_flag_2++;
                break;
            }
        }

        // se l'ho già inserito faccio in modo che il giocatore veda il messaggio che lo ha già inserito
        if (found_flag_2 == 1)
        {
            printf("you already insert it");
            found_flag_2 = 0;

            //! questo codiceè da commentare per non dare errore
            error++;
        }

        // nel caso il giocatore abbia inserito un numero non inserito fa inmodo che venga aggiunto alla lista dei caratteri già trovati
        else
        {
            // aggiungo di uno la posizione e aggiungo il numero che ho inserito
            user_guess[peek_user_list] = input;
            peek_user_list++;

            //vedere se il numero è giusto o meno, se errore aggiungere un errore
            for (i = 0; i < DIM_PC; i++)
            {
                if (pc_guess[i] == input)
                {
                    found_flag_2++;
                    break;
                }
            }

            // trovato il numero nella lista dei numeri del pc = no errore
            if (found_flag_2 == 1)
                found_flag_2 = 0;
            else
                error += 1;
        }

        //exit
        if (error >= 10)
        {
            exit_flag++;
        }
        else
        {
            // se l'utente indovina tutti i numeri
            found_flag_3 = 0;
            for (i = 0; i < DIM_PC; i++)
            {
                for (j = 0; j < DIM_USER; j++)
                {
                    // metto la condizione se nella lista dei numeri indovinati è uguale al numero della lista dove ci sono i numeri da indovinare li stampo
                    if (pc_guess[i] == user_guess[j])
                    {
                        found_flag_3++;
                        break;
                    }
                }
                if (found_flag_3 == 8)
                {
                    printf("\n\nYou WIN!");
                    exit_flag++;
                    break;
                }
            }
        }
    }

    return 0;
}

void init_vet(int *_p, int _l)
{
    for (int _i = 0; _i < _l; _i++)
        *(_p + _i) = rand() % 10;
}

void init_a_one(int *_p, int _l)
{
    for (int _i = 0; _i < _l; _i++)
        *(_p + _i) = -1;
}