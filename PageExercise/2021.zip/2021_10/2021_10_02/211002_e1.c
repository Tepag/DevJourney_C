/*
programma c che esegue le seguenti funzioni
a. inizializza una matrice 5*5 con valori random compresi tra 1 e 20
b. stampa la matrice
c. inizializza un vettore di 5 elementi con valori random tra 1 e 20
d. stampa il vettore
e. per ogni riga della matrice determina se la somma dei suoi valori è maggiore o minore rispetto la somma dei
valor del vettore
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 5

/*Funzione che inizializza una matrice tramite puntatore 
@param int* allias della prima cella della matrice
@param int dimensione totale della matrice r*c
@return void 
*/
void init_mat(int *, int);

/*Funzione che visualizza una matrice tramite puntatore 
@param int* allias della prima cella della matrice
@param int dimensione totale della matrice r*c
@return void 
*/
void view_mat(int *, int, int);

/*Funzione che inizializza una matrice tramite puntatore 
@param int* vettore 
@param int dimensione del vettore
@return void 
*/
void init_vet(int *, int);

/*Funzione che visualizza una matrice tramite puntatore 
@param int* vettore 
@param int dimensione del vettore
@return void 
*/
void view_vet(int *, int);

/*Funzione che indica se la somma delle righe è maggiore, minore o uguale alla somma del vettore
@param int[][] matrice
@param int[] vettore
@param int dimensione vettore
@param int altezza della matrice
@param int larghezza della matrice
@return void 
*/
void mag_or_min(int[][DIM], int[], int, int, int);

/*Funzione che indica se la somma delle righe è maggiore, minore o uguale alla somma del vettore
@param int[][] matrice
@param int[] vettore
@param int dimensione vettore
@param int altezza della matrice
@param int larghezza della matrice
@return void 
*/
void mag_or_min_v2(int[][DIM], int[], int, int, int);

/*Funzione che riotrna la somma del vettore
@param int[] vettore
@param int dimensione del vettore
@return return somma dei valori del vettore
*/
return somma_vet(int[], int);

int main()
{
    srand(time(NULL));
    int vet[DIM];
    int mat[DIM][DIM];
    int *mat_allias = &mat[0][0];

    //! a. inizializza una matrice 5*5 con valori random compresi tra 1 e 20
    init_mat(mat_allias, DIM * DIM);

    //! b. stampa la matrice
    view_mat(mat_allias, DIM * DIM, DIM);

    //! c. inizializza un vettore di 5 elementi con valori random tra 1 e 20
    init_vet(vet, DIM);

    //! d. stampa il vettore
    view_vet(vet, DIM);

    //! e. per ogni raga della matrice determina se la somma dei suoi valori è maggiore o minore rispetto la somma dei valor del vettore
    mag_or_min(mat, vet, DIM, DIM, DIM);

    return 0;
}

void init_mat(int *p, int _l)
{
    int _i = 0;
    for (_i = 0; _i < _l; _i++)
        *(p + _i) = rand() % 19 + 1;
}

void view_mat(int *p, int _l, int _numxriga)
{
    printf("\nprint della matrice:\n");
    int _i = 0;
    for (_i = 0; _i < _l; _i++)
    {
        printf("%0.2d ", *(p + _i));
        if ((_i + 1) % _numxriga == 0)
            printf("\n");
    }
    printf("\n\n");
}

void init_vet(int *_p, int _l)
{
    for (int _i = 0; _i < _l; _i++)
        *(_p + _i) = rand() % 19 + 1;
}

void view_vet(int *_p, int _l)
{
    printf("\nprint del vettore:\n");
    for (int _i = 0; _i < _l; _i++)
        printf("%0.2d ", *(_p + _i));
    printf("\n\n");
}

void mag_or_min(int mat[][DIM], int vet[], int _l, int _h, int _w)
{
    int somma_mat = 0;
    int somma_vet = 0;

    //somma del vettore
    for (int i = 0; i < _l; i++)
        somma_vet += vet[i];

    for (int i = 0; i < _h; i++)
    {
        for (int j = 0; j < _w; j++)
        {
            somma_mat += mat[i][j];
            //somma_mat = somma_mat + mat[i][j];
        }
        if (somma_mat > somma_vet)
            printf("\nriga matrice %d maggiore della somma del vettore %d", somma_mat, somma_vet);

        else
        {
            if (somma_mat < somma_vet)
                printf("\nriga matrice %d minore della somma del vettore %d", somma_mat, somma_vet);

            else
                printf("\nriga matrice %d uguale alla somma del vettore %d", somma_mat, somma_vet);
        }
        somma_mat = 0;
    }
}

void mag_or_min_v2(int mat[][DIM], int vet[], int _l, int _h, int _w)
{
    int somma_mat = 0;
    int somma_vet = 0;

    //somma del vettore
    for (int i = 0; i < _l; i++)
        somma_vet += vet[i];

    for (int i = 0; i < _h; i++)
    {
        for (int j = 0; j < _w; j++)
        {
            somma_mat += mat[i][j];
            //somma_mat = somma_mat + mat[i][j];
        }
        if (somma_mat > somma_vet)
            printf("\nriga matrice %d maggiore della somma del vettore %d", somma_mat, somma_vet);

        else
        {
            if (somma_mat < somma_vet)
                printf("\nriga matrice %d minore della somma del vettore %d", somma_mat, somma_vet);

            else
                printf("\nriga matrice %d uguale alla somma del vettore %d", somma_mat, somma_vet);
        }
        somma_mat = 0;
    }
}

int somma_vet(int _v[], int _l)
{
    int somma = 0;
    for (int j = 0; j < _l; j++)
        somma += _v[j];

    return somma;
}
