/*creare un programma c che dato un carattere inserito definisce se maiuscolo o minuscolo*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char input;

    // input
    printf("\ninserisci carattere: ");
    scanf("%c", &input);

    // fflush(stdin);
    if (((int)input >= 65) && ((int)input <= 90))
        printf("\nmaiuscolo");
    else
    {
        // verifico se minuscolo
        if (((int)input >= 97) && ((int)input <= 122))
            printf("\nminuscolo");
        else
            // carattere non disponibile nel range
            printf("\ncarattere non disponibile nel range");
    }

    return 0;
}