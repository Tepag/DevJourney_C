/*
fai un esercizio c prende in entrata una frase da più stringhe e ritornare il più corto e il più lungo di stringa

*/

#include <stdio.h>
#include <stdlib.h>

/*Funzione che va stampare una stringa dato il suo puntatore
@param char* puntatore alla prima cella della parola
@return void
*/
void stampa_str(char *);

int main()
{
    char *heap_init = (char *)malloc(sizeof(char) * 200), *heap = heap_init;
    char testo[20];
    int i = 0;

    // printf("inserisci una frase");
    //*heap_init = getchar();

    printf("inserisci una stringa: ");
    scanf("%s", heap_init);
    fflush(stdin);

    printf("inserisci una stringa: ");
    scanf("%s", &testo[0]);
    fflush(stdin);

    for (int i = 0; i < 20; i++)
    {
        printf("%c", testo[i]);
    }

    stampa_str(heap_init);
    return 0;
}

void stampa_str(char *text_peek)
{
    if (*text_peek != '\0')
    {
        // printf("%c", *text_peek);
        putchar(*text_peek);
        stampa_str(text_peek + 1);
    }
}
