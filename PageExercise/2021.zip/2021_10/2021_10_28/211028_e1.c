/*
1. Realizzare un programma C che richieda una stringa da tastiera e determina se contiene delle doppie,
es tetto, lotto, zappa.
2. Realizzare un programma C che richiede tre stringhe e le concatena in un'unica stringa.
(Realizzare i programmi creando funzioni e sfruttando i puntatori)
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 20

/*Funzione che va a dire se ci sono caratteri doppi nella stringa inserita
@param char* puntatore alla prima cella della parola
@return int della lunghezza della stringa
*/
int det_doppie(char *);

int main()
{
    char str[DIM];
    char *start_testo = str;

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo);
    fflush(stdin);

    printf("\n\n%d", det_doppie(start_testo));

    return 0;
}

int det_doppie(char *text_peek)
{
    do
    {
        if (*(text_peek + 1) == *text_peek)
            return 1;
        text_peek++;
    } while (*(text_peek + 1) != '\0');
    return 0;
}
