/*
2. Realizzare un programma C che richiede tre stringhe e le concatena in un'unica stringa.
(Realizzare i programmi creando funzioni e sfruttando i puntatori)
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 20

/*Funzione che va a dire se ci sono caratteri doppi nella stringa inserita
@param char* puntatore alla prima cella della parola
@return int della lunghezza della stringa
*/
char *merge_three_str(char *, char *, char *);

/*Funzione che va a restituire la lunghezza di una stringa
@param char* puntatore alla prima cella della parola
@param int numero iniziale del accumulatore
@return int della lunghezza della stringa
*/
int len_str_tail(char *, int);

/*Funzione che va stampare una stringa dato il suo puntatore
@param char* puntatore alla prima cella della parola
@return void
*/
void stampa_str(char *);

char *copy_to(char *, char *);

int main()
{
    char str1[DIM], str2[DIM], str3[DIM];
    char *heap;

    printf("\ninserisci una parola: ");
    scanf("%s", &str1[0]);
    fflush(stdin);

    printf("\ninserisci una parola: ");
    scanf("%s", &str2[0]);
    fflush(stdin);

    printf("\ninserisci una parola: ");
    scanf("%s", &str3[0]);
    fflush(stdin);

    heap = merge_three_str(&str1[0], &str2[0], &str3[0]);
    stampa_str(heap);
    free(heap);

    return 0;
}

char *merge_three_str(char *_p1, char *_p2, char *_p3)
{
    int i = 0;
    char *heap = (char *)malloc(sizeof(char) * (len_str_tail(_p1, 0) + len_str_tail(_p2, 0) + len_str_tail(_p3, 0))), *heap_peek;
    heap_peek = copy_to(_p1, heap);
    heap_peek = copy_to(_p2, heap_peek);
    heap_peek = copy_to(_p3, heap_peek);
    return heap;
}

// TODO: puoi fare una funzione che faccia il numero di stringhe a scelta con malloc

char *copy_to(char *_s, char *_d)
{
    int i = 0; // importante che sia fuori dal
    for (i = 0; *(_s + i) != '\0'; i++)
        *(_d + i) = *(_s + i);
    return _d + i;
}

int len_str_tail(char *text_peek, int _acc)
{
    return *text_peek != '\0' ? len_str_tail(++text_peek, ++_acc) : _acc;
}

void stampa_str(char *text_peek)
{
    if (*text_peek != '\0')
    {
        printf("%c", *text_peek);
        stampa_str(text_peek + 1);
    }
}