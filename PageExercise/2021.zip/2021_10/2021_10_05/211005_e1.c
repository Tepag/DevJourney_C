/*
Realizzare un programma C che inizializzi una matrice 10 x 10 di numeri interi compresi tra 1 e 
100, ogni numero deve comparire una sola volta. Al termine dell'inizializzazione stampare la 
matrice quindi realizzare una funzione che ordina in modo crescente la matrice e ritorna il 
numero di scambi effettuati.
Inizializzazione, stampa, riordino devono essere svolti con funzioni, commentare il codice in 
modo opportuno.
*/

#include <time.h>
#include <stdio.h>
#include <stdlib.h>
// #include "function_lib.c"

#define R 10
#define C 10

/*funzione che inizilizza una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void init_mat_withouth_copy(int *_pm, int _r, int _c);

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice. 
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][C], int _r, int _c);

/*funzione che riordina una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice. 
@param int NUmero di colonne della matrice.
@return void
*/
int sortMat(int *, int, int);

int main()
{
    int mat[R][C];
    int *mat_allias = &mat[0][0];
    int cnt = 0;

    //inizializzo matrice
    init_mat_withouth_copy(mat_allias, R, C);

    //stampo la matrice
    stampaMat(mat, R, C);

    // conto le volte per riordinare la matrice
    cnt = sortMat(mat_allias, R, C);
    printf("\n\n");
    stampaMat(mat, R, C);
    printf("\n\nvolte: %d", cnt);
    return 0;
}

void init_mat_withouth_copy(int *_pm, int _r, int _c)
{
    int i = 0, j = 0;
    int generate_number = 0;
    int generate_another_number_flag = 0;

    //devo fa in modo che i numeri generati non si ripetino
    for (i = 0; i < _r * _c; i++)
    {
        generate_number = rand() % 99 + 1;
        for (j = 0; j < i; j++)
        {
            if ((generate_number) == *(_pm + j))
            {
                generate_number = rand() % 99 + 1;
                j = 0;
            }
        }
        *(_pm + i) = generate_number;
    }
}

void stampaMat(int _m[][C], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf(" %0.2d", _m[i][j]);
        }
        printf("\n");
    }
}

int sortMat(int *_pm, int _r, int _c)
{
    int cnt = 0;
    int box = 0;
    int i = 0, j = 0;

    for (i = 0; i < _r * _c; i++)
    {
        for (j = 0; j < i; j++)
        {
            if (*(_pm + i) < *(_pm + j))
            {
                box = *(_pm + i);
                *(_pm + i) = *(_pm + j);
                *(_pm + j) = box;
                cnt++;
            }
        }
    }
    return cnt;
}
