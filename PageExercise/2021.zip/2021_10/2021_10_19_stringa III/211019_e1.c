/*
4. Realizzare un programma C che richieda due stringhe da tastiera (max 20 char):
- determina se le due stringhe sono una l'anagramma dell'altra.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 21

/*Funzione che verifica se una stringa è sottostringa di un'altra stringa
@param char* puntatore alla prima cella della prima stringa
@param char* puntatore alla prima cella della prima stringa
return int 0==no|1==sì
*/
int str_in_str(char *, char *);

/*Funzione che verifica se una stringa è sottostringa di un'altra stringa
@param char* puntatore alla prima cella della prima stringa
@param char* puntatore alla prima cella della prima stringa
@param int contatore pk sia ricorsiva
return int 0==no|1==sì
*/
int str_in_str_tail(char *, char *, int);

/*Funzione che verifica se una stringa è sottostringa di un'altra stringa
@param char* puntatore alla prima cella della prima stringa
@param char* puntatore alla prima cella della prima stringa
return int 0==no|1==sì
*/
int fun_str_in_str_tail(char *, char *);

int main()
{
    char str[DIM], str2[DIM];
    char *start_testo = str, *start_testo2 = str2;

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo);
    fflush(stdin);

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo2);
    fflush(stdin);

    printf("\n%d", str_in_str(start_testo, start_testo2));
    printf("\n\n%d", fun_str_in_str_tail(start_testo, start_testo2));

    return 0;
}

int str_in_str(char *text_peek, char *text_peek2)
{
    int i = 0, j = 0;
    for (i = 0; *(text_peek + i) != '\0'; i++)
    {
        j = (*(text_peek + i) == *(text_peek2 + j)) ? (j + 1) : 0;
    }
    return *(text_peek2 + j) == '\0' ? 1 : 0;
}

int str_in_str_tail(char *text_peek, char *text_peek2, int j)
{
    if (*text_peek != '\0')
        *text_peek == *(text_peek2 + j) ? str_in_str_tail(++text_peek, text_peek2, ++j) : str_in_str_tail(++text_peek, text_peek2, 0);
    else
        return *(text_peek2 + j) == '\0' ? 1 : 0;
}

int fun_str_in_str_tail(char *text_peek, char *text_peek2)
{
    return str_in_str_tail(text_peek, text_peek2, 0);
}
