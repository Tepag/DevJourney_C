/*
2. Realizzare un programma C che richieda una stringa da tastiera (max 20 char):
- esegue un conteggio per ogni singola lettera dell'alfabeto, comunicando quante volte compare.
- Realizza una seconda stringa, come risultato leggendo la prima al contrario.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 20

/*Funzione che va stampare una stringa dato il suo puntatore
char* puntatore alla prima cella della parola
return void
*/
void stampa_str(char *);

/*Funzione che va a inizializzare un vettore
@param int[] vettore da inizializzare
@param int dimensione del vettore di cui si vuole inizializzare
*/
void init_array(int[], int);

/*Funzione che stampa quante volte viene visualizzato ogni lettera
char* puntatore alla prima cella della parola
return void
*/
int anagram_verification(char *, char *);

int main()
{
    char str[DIM], str2[DIM];
    char *start_testo = str, *start_testo2 = str2;
    int cnt = 0, verification = 0;

    //1.1 richieda due stringhe da tastiera (max 20 char)
    printf("\ninserisci una parola: ");
    scanf("%s", start_testo); //TODO: questo codice non accetta i spazi
    fflush(stdin);

    printf("\ninserisci una parola: ");
    scanf("%s", start_testo2); //TODO: questo codice non accetta i spazi
    fflush(stdin);

    //1.2 esegue un conteggio per ogni singola lettera dell'alfabeto, comunicando quante volte compare.
    printf("\n");
    anagram_verification(start_testo, start_testo2) == 0 ? printf("anagram") : printf("no anagram");

    return 0;
}

void stampa_str(char *text_peek)
{
    if (*text_peek != '\0')
    {
        printf("%c", *text_peek);
        stampa_str(text_peek + 1);
    }
}

/*
int anagram_verification(char *text_peek, char *text_peek2)
{
    int cnt[25], i = 0, flag_no_anagram = 0;
    char alphabet_min[25] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'x', 'y', 'z'};
    char alphabet_mai[25] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'X', 'Y', 'Z'};
    char *allias_alp_min = alphabet_min, *allias_alp_mai = allias_alp_mai;
    init_array(cnt, 25);

    while (*text_peek != '\0')
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek == alphabet_min[i] || *text_peek == alphabet_mai[i])
                cnt[i]++;
        }
        text_peek++;
    }

    while (*text_peek2 != '\0')
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek2 == alphabet_min[i] || *text_peek2 == alphabet_mai[i])
                cnt[i]--;
        }
        text_peek2++;
    }

    for (i = 0; i < 25; i++)
    {
        if (cnt[i] != 0)
            flag_no_anagram = 1;
    }
    return flag_no_anagram;
}//*/

int anagram_verification(char *text_peek, char *text_peek2)
{
    int cnt[25] = {0}, i = 0;

    for (; *text_peek != '\0'; text_peek++)
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek == 'a' + i || *text_peek == 'A' + i)
                cnt[i]++;
        }
    }

    for (; *text_peek2 != '\0'; text_peek2++)
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek2 == 'a' + i || *text_peek2 == 'A' + i)
                cnt[i]--;
        }
    }

    for (i = 0; i < 25; i++)
    {
        if (cnt[i] != 0)
            return 1;
    }

    return 0;
}
