/*
3. Realizzare un programma C che richieda una stringa da tastiera (max 20 char):
- determina se la parola è palindroma (è uguale anche se letta al contrario)
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 20

/*Funzione che va stamapre una stringa dato il suo puntatore
char* puntatore alla prima cella della parola
return void
*/
void stampa_str(char *);

/*Funzione che va a contare la lunghezza di una stringa data il suo puntatore iniziale
char* puntatore alla prima cella della parola
return int della lunghezza della stringa
*/
int len_str(char *);

/*Funzione che ritorna il numero di vocali contati
char* puntatore alla prima cella della parola
return int del numero dei vocali
*/
int palindrome_verification(char *, char *);

int main()
{
    char str[DIM];
    char *start_testo = str, *start_testo2 = str;
    int cnt = 0, verification = 0;

    //!1.1 richieda una stringa da tastiera (max 20 char)
    printf("\ninserisci una parola: ");
    scanf("%s", start_testo);
    fflush(stdin);

    //!1.2 verifica polindroma
    verification = palindrome_verification(start_testo, start_testo2);
    verification == 1 ? printf("\nis palindrome") : printf("\nno palindrome");

    return 0;
}

void stampa_str(char *text_start)
{
    if (*text_start != '\0')
    {
        printf("%c", *text_start);
        stampa_str(text_start + 1);
    }
}

int len_str(char *text_start)
{
    int cnt = 0;
    while (*text_start != '\0')
    {
        cnt++;
        text_start++;
    }
    return cnt;
}

/*
int palindrome_verification(char *text_peek, char *text_peek2)
{
    int len = 0, flag_no_polindrome = 0;
    len = len_str(text_peek);
    text_peek2 += (len - 1);

    while (*text_peek != '\0')
    {
        if (*text_peek2 != *text_peek)
            flag_no_polindrome++;
        text_peek++;
        text_peek2--;
    }
    return flag_no_polindrome;
}//*/

int palindrome_verification(char *text_peek, char *text_peek2)
{
    int len = 0;
    len = len_str(text_peek);
    text_peek2 += (len - 1);

    while (*text_peek != '\0')
    {
        if (*text_peek2 != *text_peek)
            return 0;
        text_peek++, text_peek2--;
    }
    return 1;
}