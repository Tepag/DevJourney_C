/*
4. Realizzare un programma C che richieda due stringhe da tastiera (max 20 char):
- determina se le due stringhe sono una l'anagramma dell'altra.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 21 //'\0'

/*Funzione che va stampare una stringa dato il suo puntatore
char* puntatore alla prima cella della parola
return void
*/
void stampa_str(char *);

/*Funzione che va stamapre una stringa dato il suo puntatore
char* puntatore alla prima cella della parola
return void
*/
void reverse_to_another_str(char *, char *);

/*Funzione che va stampare una stringa dato il suo puntatore
char* puntatore alla prima cella della parola
return void
*/
int len_str(char *);

/*Funzione che va a restituire la lunghezza di una stringa
@param char* puntatore alla prima cella della parola
@param int numero iniziale del accumulatore
return int della lunghezza della stringa
*/
int len_str_tail(char *, int);

/*incapsulamento della funzione che va a restituire la lunghezza di una stringa
@param char* puntatore alla prima cella della parola
return int della lunghezza della stringa
*/
int len_str_tail_fun(char *);

/*Funzione che stampa quante volte viene visualizzato ogni lettera
char* puntatore alla prima cella della parola
return void
*/
void cnt_alfabeto_str(char *);

/*Funzione che a ordinare un vettore
char* puntatore alla prima cella della parola
return void
*/
void order_str(char *);

int main()
{
    char str[DIM], str2[DIM];
    char *start_testo = str, *start_testo2 = str2;
    int cnt = 0, len = 0;

    //1.1 richieda una stringa da tastiera (max 20 char)
    printf("\ninserisci una parola: ");
    scanf("%s", start_testo); //? questo codice non accetta i spazi
    fflush(stdin);

    //1.2 esegue un conteggio per ogni singola lettera dell'alfabeto, comunicando quante volte compare.
    printf("\n");
    cnt_alfabeto_str(start_testo);

    //1.3 Realizza una seconda stringa, come risultato leggendo la prima al contrario.
    reverse_to_another_str(start_testo, start_testo2);
    stampa_str(start_testo2);

    return 0;
}

void stampa_str(char *text_peek)
{
    if (*text_peek != '\0')
    {
        printf("%c", *text_peek);
        stampa_str(text_peek + 1);
    }
}

/*
int len_str(char *text_peek)
{
    int cnt = 0;
    while (*text_peek != '\0')
    {
        cnt++;
        text_peek++;
    }
    return cnt;
}//*/

int len_str_tail_fun(char *text_peek)
{
    return len_str_tail(text_peek, 0);
}

int len_str_tail(char *text_peek, int _acc)
{
    return *text_peek != '\0' ? len_str_tail(++text_peek, ++_acc) : _acc;

    /*
    ! da prestare attenzione :
    // *text_peek != '\0' ? return (len_str_tail(++text_peek, ++_acc)) : return _acc;
    */
}

/*
int len_str_tail(char *text_peek, int _acc)
{
    if (*text_peek != '\0')
        return len_str_tail(++text_peek, ++_acc);
    else
        return _acc;
}*/

void reverse_to_another_str(char *text_peek, char *text_peek2)
{
    int len = 0;
    //len = len_str(text_peek);
    len = len_str_tail_fun(text_peek);
    text_peek2 += (len - 1);

    while (*text_peek != '\0')
    {
        *text_peek2 = *text_peek;
        text_peek++;
        text_peek2--;
    }
}

/*
void cnt_alfabeto_str(char *text_peek)
{
    int cnt[25] = {0}, i = 0;
    char alphabet_min[25] = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'x', 'y', 'z'};
    char alphabet_mai[25] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'X', 'Y', 'Z'};
    char *allias_alp_min = alphabet_min, *allias_alp_mai = allias_alp_mai;

    while (*text_peek != '\0')
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek == alphabet_min[i] || *text_peek == alphabet_mai[i])
                cnt[i]++;
        }
        text_peek++;
    }

    printf("hai inserito:\n");
    for (i = 0; i < 25; i++)
    {
        printf("%c/%c: %d   ", alphabet_mai[i], alphabet_min[i], cnt[i]);
        if ((i + 1) % 4 == 0)
            printf("\n");
    }
}//*/

/*
void cnt_alfabeto_str(char *text_peek)
{
    int cnt[25] = {0}, i = 0;

    while (*text_peek != '\0')
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek == ('a' + i) || *text_peek == ('A' + i))
                cnt[i]++;
        }
        text_peek++;
    }

    printf("hai inserito:\n");
    for (i = 0; i < 25; i++)
    {
        printf("%c/%c: %d   ", ('a' + i), ('A' + i), cnt[i]);
        if ((i + 1) % 4 == 0)
            printf("\n");
    }
}*/

void cnt_alfabeto_str(char *text_peek)
{
    int cnt[25] = {0}, i = 0;

    while (*text_peek != '\0')
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek == ('a' + i) || *text_peek == ('A' + i))
                cnt[i]++;
        }
        text_peek++;
    }

    printf("hai inserito:\n");
    for (i = 0; i < 25; i++)
    {
        printf("%c/%c: %d   ", ('a' + i), ('A' + i), cnt[i]);
        if ((i + 1) % 4 == 0)
            printf("\n");
    }
}

/*
void order_str(char *text_peek)
{
    int tmp = 0;
    int *text_peek_2 = text_peek;
    for (i = 0; i < _d; i++)
    {
        for (j = i; j < _d; j++)
        {
            if (_v[i] < _v[j])
            {
                tmp = _v[j];
                _v[j] = _v[i];
                _v[i] = tmp;
            }
        }
    }
    while (*text_peek != '\0')
    {
        for (i = 0; i < 25; i++)
        {
            if (*text_peek == ('a' + i) || *text_peek == ('A' + i))
                cnt[i]++;
        }
        text_peek++;
    }
}*/
