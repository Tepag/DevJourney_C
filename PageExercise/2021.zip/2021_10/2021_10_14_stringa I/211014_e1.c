/*
1. Realizzare un programma C che richieda una stringa da tastiera (max 20 char):
- determina la sua lunghezza e la comunica.
- la stampa al contrario char-by-char.
- esegue il conteggio delle vocali.
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 20

/*Funzione che va stamapre una stringa dato il suo puntatore
char* puntatore alla prima cella della parola
return void
*/
void stampa_str(char *);

/*Funzione che va stamapre una stringa dato il suo puntatore
char* puntatore alla prima cella della parola
return void
*/
void reverse_stmp_str(char *);

/*Funzione che va a contare la lunghezza di una stringa data il suo puntatore iniziale
char* puntatore alla prima cella della parola
return int della lunghezza della stringa
*/
int len_str(char *);

/*Funzione che ritorna il numero di vocali contati
char* puntatore alla prima cella della parola
return int del numero dei vocali
*/
int cnt_vocali_str(char *);

int main()
{
	char str[DIM];
	char *start_testo = str;
	int cnt = 0;

	//!1.1 richieda una stringa da tastiera (max 20 char)
	printf("\ninserisci una parola: ");
	scanf("%s", start_testo);
	fflush(stdin);

	//!1.2 determina la sua lunghezza e la comunica.
	printf("\nla dimensione della stringa equivale a %d", len_str(start_testo));

	//!1.3 la stampa al contrario char-by-char.
	printf("\n\nla stringa stampato al contrario: ");
	reverse_stmp_str(start_testo);

	//!1.4 esegue il conteggio delle vocali.
	printf("\n\nnumero di vocali: %d", cnt_vocali_str(start_testo));

	return 0;
}

void stampa_str(char *text_start)
{
	if (*text_start != '\0')
	{
		printf("%c", *text_start);
		stampa_str(text_start + 1);
	}
}

int len_str(char *text_start)
{
	int cnt = 0;
	while (*text_start != '\0')
	{
		cnt++;
		text_start++;
	}
	return cnt;
}

void reverse_stmp_str(char *text_start)
{
	if (*text_start != '\0')
	{
		reverse_stmp_str(text_start + 1);
		printf("%c", *text_start);
	}
}

int cnt_vocali_str(char *text_start)
{
	int cnt = 0;
	while (*text_start != '\0')
	{
		if (*text_start == 'a' || *text_start == 'e' || *text_start == 'i' || *text_start == 'o' || *text_start == 'u' || *text_start == 'A' || *text_start == 'E' || *text_start == 'I' || *text_start == 'O' || *text_start == 'U')
			cnt++;
		text_start++;
	}
	return cnt;
}
