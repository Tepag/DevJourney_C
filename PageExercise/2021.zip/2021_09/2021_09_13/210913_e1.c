/*
Progettare e codificare un programma in C che calcoli il quoziente della divisione tra interi. Svolgere 
l'esercizio nelle due versioni ricorsiva e tail ricorsiva. Suggerimento: x/y = (x - y + y)/y = 1 + (x - y)/y.

RECORD:
*/

#include <stdio.h>

int div(int x, int y);

int main()
{
    int x, y, ris;

    do
    {
        printf("Inserire dividendo: ");
        scanf("%d", &x);
    } while (x < 0);

    do
    {
        printf("Inserire divisore: ");
        scanf("%d", &y);
    } while (y < 1);

    ris = div(x, y);
    printf("%d/%d = %d", x, y, ris);
}

//Versione tail ricorsiva:
int div(int x, int y)
{

    /*
    finché il dividendo è maggiore o uguale al divisore:
    - passo alla prossima funzione  il dividendo - divisore -> quoziente +1
    */
    if (x >= y)
        return div(x - y, y) + 1;
    else
        return 0;
}

/*
int div_tail(int x, int y, int v, int k)
{
    if (k <= x)
    {
        v = v + 1;
        k = k + y;
        return div_tail(x, y, v, k);
    }
    else
        return v;
}

int div(int x, int y)
{
    return div_tail(x, y, 0, y);
}
*/