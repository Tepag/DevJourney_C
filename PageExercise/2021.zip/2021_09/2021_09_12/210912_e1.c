/*
scrivere una funzione ricorsiva che calcoli la somma degli elementi di un array [1..n] di n interi

RECORD: 23m 47s
*/

#include <stdio.h>
#include <stdlib.h>

#define N 10

void somma_ricorsiva(int *_arr, int _i, int _somma);

int main()
{
    int array[N];

    for (int i = 0; i < N; i++)
    {
        array[i] = 1;
    }

    somma_ricorsiva(array, 0, 0);

    //printf("somma tramite funzione ricorsiva da 0 a 9 = %d", somma_ricorsiva(array, 0, 0));
    return 0;
}

void somma_ricorsiva(int *_arr, int _i, int _somma)
{
    //esco solo se finisco tutti i numeri del vettore
    if (_i == N - 1)
    {
        printf("%d", _somma);
        //return _somma
    }
    else
    {
        _somma += *(_arr + _i);
        somma_ricorsiva(_arr, _i + 1, _somma);
    }
}
