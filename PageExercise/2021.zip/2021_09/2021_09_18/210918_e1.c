/*
! structure:
    librerie
    costanti
    prototipi
    main
    stesura delle funzioni
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 10

/*Funzione random vettore
@param int[] vettore da randomizzare
@param int lunghezza del vettore
@param int range minimo
@param int range massimo
@return void
*/
void rand_vet(int[], int, int, int);

/*Funzione che va a stampare il vettore
@param int[] vettore da visualizzare
@param int lunghezza del vettore
@return void
*/
void print_vet(int[], int);

/*Funzione che raddoppia il valore di una variablie tramite puntatore
@param int* indirizzo della variabile da passare
@return int del numero raddoppiato
*/
int double_var(int *);

int main()
{
    srand(time(NULL));
    int a = 0;
    int v[DIM];

    //input
    printf("\ninsert something here: ");
    scanf("%d", &a);
    fflush(stdin); // clean buffer

    //!NB: DEVI SEGUIRE LE ISTRUZIONE DELLA CONSEGNA SEMPRE!!

    // // inizializzo con valore random
    // for (int i = 0; i < DIM; i++)
    // {
    //     v[i] = (rand() % 100) - 50;
    // }
    // // printf del vet
    // for (int i = 0; i < DIM; i++)
    // {
    //     printf("\n%0.3d", v[i]);
    // }

    rand_vet(v, DIM, -50, 50);
    print_vet(v, DIM);

    //visualizzare solo i valori pari e multipli di a
    printf("\n\ni valori pari e multipli di a ");
    for (int i = 0; i < DIM; i++)
    {
        /*
        // filter pari
        if (v[i] % 2 == 0)
        {
            //filter multipli di a
            if (v[i] % a == 0)
            {
                printf("\n%0.2d", v[i]);
            }
        }
        */

        //or

        if ((v[i] % 2 == 0) && (v[i] % a == 0))
            printf("\n%0.2d", v[i]);
    }

    // raddoppio tramite indirizzo
    printf("\n\n%d", double_var(&a));

    return 0;
}

void rand_vet(int _v[], int _l, int _min, int _max)
{
    int _i = 0;
    for (_i = 0; _i < _l; _i++)
        _v[_i] = rand() % (_max - _min + 1) + _min;
}

void print_vet(int _v[], int _l)
{
    int _i = 0;
    for (_i = 0; _i < _l; _i++)
        printf("\n%0.2d", _v[_i]);
}

int double_var(int *_var)
{
    return *_var *= 2;
}