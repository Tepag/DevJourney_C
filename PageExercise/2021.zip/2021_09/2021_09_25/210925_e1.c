#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DIM_1 3
#define DIM_2 6
#define DIM_3 9

/*Funzione random vettore
@param int[] vettore da randomizzare
@param int lunghezza del vettore
@param int range minimo
@param int range massimo
@return void
*/
void rand_vet(int[], int, int, int);

/*Funzione che va a stampare il vettore
@param int[] vettore da visualizzare
@param int lunghezza del vettore
@return void
*/
void print_vet(int[], int);

/*Funzione che va a stampare la media del vettore
@param int[] vettore contenente i dati
@param int lunghezza del vettore
@return void
*/
void media_vet(int[], int);

int main()
{
    int arr1[DIM_1];
    int arr2[DIM_2];
    int arr3[DIM_3];

    rand_vet(arr1, DIM_1, 0, 10);
    rand_vet(arr2, DIM_2, 0, 10);
    rand_vet(arr3, DIM_3, 0, 10);

    print_vet(arr1, DIM_1);
    media_vet(arr1, DIM_1);
    printf("\n");
    print_vet(arr2, DIM_2);
    media_vet(arr2, DIM_2);
    printf("\n");
    print_vet(arr3, DIM_3);
    media_vet(arr3, DIM_3);

    return 0;
}

void rand_vet(int _v[], int _l, int _min, int _max)
{
    int _i = 0;
    for (_i = 0; _i < _l; _i++)
        _v[_i] = rand() % (_max - _min + 1) + _min;
}

void print_vet(int _v[], int _l)
{
    int _i = 0;
    for (_i = 0; _i < _l; _i++)
        printf("%0.2d\t", _v[_i]);
}

void media_vet(int _v[], int _l)
{
    int _i = 0;
    float somma = 0;
    for (_i = 0; _i < _l; _i++)
        somma += (float)_v[_i];

    printf("media: %.2f", somma / (float)_l);
}