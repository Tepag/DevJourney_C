/*
realizza un programma che inizializza con una funzione un vettore di 20 elementi con funzioni ricorsive tra 1 
e 10 e visualizza a video il vettore e la somma

RECORD: 40m 04s
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

/*Funzione che inizializza un vettore tramite ricorsiva
@param int vettore
@param int length
@param int i, che deve uguale a zero inizialmente
@return void
*/
void init_vet(int[], int, int);

/*Funzione che inizializza un vettore tramite ricorsiva
@param int vettore
@param int length
@param int i, che deve uguale a zero inizialmente
@return void
*/
void init_vet_v2(int[], int, int);

/*Funzione che visualizza un vettore
@param int vettore
@param int length
@return void
*/
void view_vet(int[], int, int);

/*Funzione che visualizza un vettore in contrario
@param int vettore
@param int length
@return void
*/
void revert_view_vet(int[], int);

// /*Funzione che visualizza un vettore in contrario
// @param int vettore
// @param int length
// @return void
// */
// void revert_view_vet_v2(int[], int, int);

/*Funzione che ritorna la somma 
@param int vettore
@param int length
@return void
*/
int somma_vet(int[], int);

#define DIM 5

int main()
{
    srand(time(NULL));
    int arr[DIM];

    //init_vet(arr, DIM, 0);
    init_vet_v2(arr, DIM, 0);
    view_vet(arr, DIM, 0);
    printf("\n\n");
    revert_view_vet(arr, DIM - 1);
    //printf("\n\n");
    //revert_view_vet_v2(arr, DIM, 0);
    printf("\n\nsomma: %d", somma_vet(arr, DIM - 1));
    return 0;
}

void init_vet(int _p[], int _l, int _i)
{
    if (_i != _l - 1)
    {
        init_vet(_p, _l, _i + 1);
        _p[_i] = rand() % 10 + 1;
    }
}

void init_vet_v2(int _p[], int _l, int _i)
{
    //simplest case: with i == _l-1
    if (_i == _l - 1)
        _p[_i] = rand() % 10 + 1;
    else
    {
        _p[_i] = rand() % 10 + 1;
        init_vet_v2(_p, _l, _i + 1);
    }
}

void view_vet(int _v[], int _l, int _i)
{
    if (_i != _l)
    {
        printf("%d ", _v[_i]);
        view_vet(_v, _l, _i + 1);
    }
}

void revert_view_vet(int _v[], int _i)
{
    if (_i >= 0)
    {
        printf("%d ", _v[_i]);
        revert_view_vet(_v, _i - 1);
    }
}

// void revert_view_vet_v2(int _v[], int _l, int _i)
// {
//     if (_i != _l)
//     {
//         view_vet(_v, _l, _i + 1);
//         printf("%d ", _v[_i]);
//     }
// }

int somma_vet(int _v[], int _l)
{
    if (_l == 0)
        return _v[_l];

    else
        return _v[_l] + somma_vet(_v, _l - 1);
}