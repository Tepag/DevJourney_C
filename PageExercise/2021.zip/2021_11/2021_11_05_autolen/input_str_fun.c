/*
Realizzare un programma che richiede una stringa composta da più parole, lunga massimo 100 char.
Scansionando la stringa deve comunicare:
- 1.lettera che compare più volte.
- 2.lettera che compare meno.
- 3.Numero di parole che compongono la stringa.
- 4.Parola più lunga.
- 5.Parola più corta.

*/

#include <stdio.h>
#include <stdlib.h>

char *input_str();

char *input_str_v2();

int main()
{
    char *str_start = NULL;

    printf("\ninserisci una frase:");
    str_start = input_str_v2();

    printf("\n");
    puts(str_start);

    free(str_start);
    system("pause");
    return 0;
}

char *input_str()
{
    char *str_access_point = (char *)malloc(sizeof(char));
    for (int i = 0; (1); i++)
    {
        *(str_access_point + i) = getchar();
        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            break;
        }
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
    }
    return str_access_point;
}

char *input_str_v2()
{
    char *str_access_point = (char *)malloc(sizeof(char));
    *str_access_point = 'a';
    int i = 0;
    do
    // for(int i = 0; *(str_access_point + i) != '\0'; i++)
    {
        *(str_access_point + i) = getchar();
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
        if (*(str_access_point + i) == '\n')
            *(str_access_point + i + 1) = '\0';
        i++;
    } while (*(str_access_point + i) != '\0');
    return str_access_point;
}
