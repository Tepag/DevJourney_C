/*
Realizzare un programma che richiede una stringa composta da più parole, lunga massimo 100 char.
Scansionando la stringa deve comunicare:
- 1.lettera che compare più volte.
- 2.lettera che compare meno.
- 3.Numero di parole che compongono la stringa.
- 4.Parola più lunga.
- 5.Parola più corta.

*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    char *str_access_point = (char *)malloc(sizeof(char));
    // faccio input della stringa con getchar

    printf("\ninserisci una frase:");
    for (int i = 0; (1); i++)
    {
        *(str_access_point + i) = getchar();
        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            break;
        }
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
    }
    printf("\n");
    puts(str_access_point);

    /*
    for (i = 0; *(str_access_point + i) != '\0'; i++)
    {
        *(str_access_point + i) = getchar();

        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            i--;
        }

        str_access_point = (char *)realloc(str_access_point, sizeof(char) * (i + 2));
    }//*/
    /*
    do
    {
        *(str_access_point + i) = getchar();
        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            break;
        }
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 1));
        i++;
    } while (*(str_access_point + i) != '\0');

    for (i = 0; *(str_access_point + i) != '\0'; i++)
        printf("%c", *(str_access_point + i));
    */
    /*
        for (i = 0; *(str_access_point + i - 1) != '\n'; i++)
        {
            *(str_access_point + i) = getchar();
            str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
        }
        puts(str_access_point);//*/

    free(str_access_point);
    system("pause");
    return 0;
}
