/**
 * @file 211123_e1.c
 * @author Tepag
 * @brief An simple exercize with record
 * @version 0.2
 * @date 2021-11-23
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define DIM 30

typedef struct record
{
    int a;
    float b;
    char c;
} Record;

typedef struct record2
{
    int variables_num;
} Record2;

int main()
{
    Record r1, r2;
    Record *pointer_r1 = &r1, *pointer_r2 = &r2;
    Record2 rr;
    Record2 *pointer_rr = &rr;

    pointer_r1->a = 3;
    pointer_r2->a = 6;
    pointer_r1->b = 3.4;
    pointer_r2->b = 6.2;
    pointer_r1->c = 'c';
    pointer_r2->c = 'b';

    pointer_rr->variables_num = 977;

    //---
    printf("\n%d", pointer_r1->a);
    printf("\n%.2f", pointer_r1->b);
    printf("\n%c", pointer_r1->c);
    r1 = r2;
    printf("\n%d", pointer_r2->a);
    printf("\n%.2f", pointer_r2->b);
    printf("\n%c", pointer_r2->c);
    //---conclusione: copia tutto

    //---
    // r1 = (Record)rr;
    //---conclusione: vale come nella variabili normalmente, non si possono mettere insieme strutture diverse
    return 0;
}
