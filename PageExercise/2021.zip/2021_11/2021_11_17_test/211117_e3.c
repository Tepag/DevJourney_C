// ? Question: Implementare la funzione "strcat" in modalità ricorsiva.

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DIM 100

void my_strcat(char *, char *);
void my_strcat_v2(char *, char *);

char *input_str();

int main()
{
    char *str1 = input_str();
    char *str2 = input_str();
    str1 = realloc(str1, sizeof(char) * (strlen(str1) + strlen(str2)));

    my_strcat(str1, str2);
    // my_strcat_v2(str1, str2);
    puts(str1);
    return 0;
}

char *input_str()
{
    char *str_access_point = (char *)malloc(sizeof(char));
    for (int i = 0; (1); i++)
    {
        *(str_access_point + i) = getchar();
        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            break;
        }
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
    }
    return str_access_point;
}

// My answer:
void my_strcat(char *destination, char *source)
{
    static int flag = 0;
    if (flag == 0)
    {
        destination = destination + strlen(destination);
        flag++;
    }
    if (*source != '\0')
    {
        *destination = '\0';
    }
    else
    {
        *destination = *source;
        my_strcat(++destination, ++source);
    }
}

// The right answer:
void my_strcat_v2(char *destination, char *source)
{
    if (*destination != '\0')
        my_strcat_v2(++destination, source);
    else
    {
        if (*source != '\0')
        {
            *destination = *source;
            *(destination + 1) = '\0';
            my_strcat_v2(++destination, ++source);
        }
    }
}
