// ? 1.Question: Quale funzione, tra quelle viste a lezione, mima la funzione seguente? Perché?
/** My answer:
 * va a mimare la strtok, dato che inizialmente la i viene messa a zero, che indica la posizione in
 * cui siamo arrivati a puntare, mettendo come condizione se la somma di i+size è minore di DIM,
 * in modo tale da ritornare un puntatore null in caso di "bucato memoria"
 */
/**The right answer:
 * va a mimare la malloc, dato che è l'unica funzione che abbiamo visto e che ritorna un void*, e in più tra i parametri, c'era la
 * int size
 */

// ? 2.Question: Cosa manca alla funzione precedente per essere completamente usabile come quella vista a lezione?
/** My answer:
 * il size deve essere la lunghezza della stringa che vogliamo tagliare, dove in questa mettiamo la stringa e il separatore,
 * e la funzione ritornerà la lunghezza della stringa fino a arrivare al separatore; così facendo si entra nella funzione funzioni
 * che calcolerà se la somma tra i e la grandezza della nuova stringa rientrano nei dimensioni massimi (se si ritorna l'indice
 * della nuova stringa), se no ritorna NULL
 */
/** The right answer:
 * l'errore sta nella mancanza dei limiti, dato che non dà il puntatore alla prima cella
 */

// ? 3.Question: Scrivere una breve funzione per calcolare il valore di DIM, della funzione dell'esercizio
/** My answer:
// questa funzione solo se presente alla fine il terminatore \0 nella stringa
int len_str(char *text_peek, int _acc)
{
    return *text_peek != '\0' ? len_str(++text_peek, ++_acc) : _acc;
}
 */
/** The right answer:
 * non punti completi potevo fare: printf("%d", DIM);
 * oppure più completamente, posso mettermi fare un i che incrementa finché non arriva a NULL;
 */

#include <stdio.h>
#include <stdlib.h>

#define DIM 100

void *function(unsigned int);

int main()
{
    printf("%d", calc_dim(DIM, 0));
    return 0;
}

// funzione data dalla verifica
void *function(unsigned int size)
{
    static char m[DIM];
    static unsigned int i = 0;
    if (i + size < DIM)
    {
        i += size;
        return m + i - size;
    }
    else
        return NULL;
}

// * 3.Right answer: o potevi semplicemente fare printf("%d", DIM);
int calc_dim()
{
    int i = 0;
    for (; function(1) != NULL; i++)
    {
    }
    return i;
}