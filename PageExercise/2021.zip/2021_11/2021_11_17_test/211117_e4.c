// ? Question: Usando solamente le funzioni della libreria "string.h", scrivere una funzione che ordini un array di stringhe come argv.
/** My answer:

 */
/** The right answer:
 *
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//
#define DIM 100

void my_strcat(char *, char *);
void my_strcat_v2(char *, char *);

char *input_str();

int main(int arg_counter, char **argv)
{
    // char *arr[DIM] = {"ciao", "amici", "miei"};
    char *tmp = malloc(sizeof(char) * DIM);
    int j = 0, i = 0;

    for (i = 1; i < arg_counter; i++)
    {
        for (j = i; j < arg_counter; j++)
        {
            if (strcmp(*(argv + i), *(argv + j)) < 0)
            {
                strcpy(tmp, *(argv + j));
                strcpy(*(argv + j), *(argv + i));
                strcpy(*(argv + i), tmp);
            }
        }
    }
    free(tmp);

    for (i = 1; i < arg_counter; i++)
        puts(*(argv + i));

    return 0;
}

char *input_str()
{
    char *str_access_point = (char *)malloc(sizeof(char));
    for (int i = 0; (1); i++)
    {
        *(str_access_point + i) = getchar();
        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            break;
        }
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
    }
    return str_access_point;
}

// My answer:
/**
void order_strings(int arg_counter, char **argv)
{
    int tmp = 0, j = 0, i = 0, flag = 0;
    for (i = 0; i < arg_counter; i++)
    {
        for (j = i; j < arg_counter; j++)
        {
            if (*(*argv + i) < *(*argv + j))
            {
                tmp = *(argv + j);
                *(argv + j) = *(argv + i);
                *(argv + i) = tmp;
            }
        }
    }
}*/

// The right answer:
/**
void order_strings_v2(int arg_counter, char **argv)
{
    char *tmp = malloc(sizeof(char) * DIM);
    int j = 0, i = 0, flag = 0;
    for (i = 0; i < arg_counter; i++)
    {
        for (j = i; j < arg_counter; j++)
        {
            if (strcmp(*(*argv + i), *(*argv + j)) < 0)
            {
                strcpy(tmp, (*argv + j));
                strcpy((*argv + j), (*argv + i));
                strcpy((*argv + i), tmp);
            }
        }
    }
    free(tmp);
}*/
