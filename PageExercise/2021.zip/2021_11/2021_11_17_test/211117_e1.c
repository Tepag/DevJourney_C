// ? Riscrivere la funzione in modalità iterativa
// 老铁，因果想循，你这次没拿好分数因为没有过此类经验，you could compile and run。

#include <stdio.h>
#include <stdlib.h>

void xy(char *);
void xy_v2(char *);

int main()
{
    xy("ciao");
    printf("\n");
    xy_v2("ciao");
    return 0;
}

void xy(char *x)
{
    if (*x == '\0')
        return;

    putchar(*x);
    xy(x + 1);
    putchar(*x);
}

// My answer in the test
/*
void xy(char *x)
{
    int cnt = 0;
    for (; *x != '\0'; x++)
    {
        putchar(*x);
        cnt++;
    }
    for (; cnt = 0; cnt--, x--)     //i missed '<'
    {
        putchar(*x);
    }
}
*/

// the right answer
void xy_v2(char *x)
{
    int cnt = 0;
    for (; *x != '\0'; x++)
    {
        putchar(*x);
        cnt++;
    }

    for (; cnt >= 0; cnt--, x--)
        putchar(*x);
}
