#include <stdio.h>
#include <stdlib.h>

int main(int arg_counter, char **argv)
{
    int i;

    // per non fare printare il path si parte da 1
    for (i = 1; i < arg_counter; i++)
        printf("\n%s", *(argv + i));
    return 0;
}
