/**
 * @file 211120_e1.c
 * @author Tepag
 * @brief An simple exercize for introduce record
 * @version 0.1
 * @date 2021-11-20
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>

#define DIM 30

typedef struct People
{
    char first_name[DIM];
    char surname[DIM];
    int age;
    float grade;
} struct_people;

struct Address
{
    int numero;
    float via[DIM];
};

typedef struct
{
    int x;
    int y;
} Point;

int main()
{
    struct People *pointer = NULL;
    // sono record ma in c vengono chiamate strutture => struct
    struct_people p1;
    struct_people p2;

    // typedef struct.People People;
    p1.age = 23;

    // i can use the pointer;
    pointer = &p1;
    pointer->age = 66;

        printf("%d", p1.age);
    return 0;
}