/*
fai un esercizio c prende in entrata una frase da più stringhe e ritornare il più corto e il più lungo di stringa

*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 100

/** Funzione che va stampare una stringa dato il suo puntatore
@param char* puntatore alla prima cella della parola
@return void
*/
void stampa_str(char *, char);

/** Funzione che data una stringa in entrata mi ridia indietro una zona di memoria contenente tutti indirizzi iniziali delle varie stringhe
@param char* puntatore alla prima cella della parola
@return void
*/
char **split_str(char *, char);

/** Funzione che va a restituire la lunghezza di una stringa
@param char* puntatore alla prima cella della parola
@param char condizione di stop
@param int numero iniziale del accumulatore
@return int della lunghezza della stringa
*/
int len_str(char *, char);

/** Funzione conta quante volte appare un carattere in una stringa
@param char* puntatore alla prima cella della parola
@param char carattere da contare
@return int delle volte apperse
*/
int str_cnt_condition_true(char *, char);

int main()
{
    //  TODO: qua si può migliorare mna non so come mettendo praticamente la malloc su misaura
    // 0. creazione variabili
    char *sentence_access_pointer = (char *)malloc(sizeof(char) * DIM);
    char **split_access_pointer = NULL; // ho messo char** dato che sono puntatori che puntano alla cella del heap dove a sua volta punterà le zone di un altro heap
    int max_len_index = 0, min_len_index = 0;

    // 1. input
    printf("insert sentence: ->");
    fgets(sentence_access_pointer, DIM, stdin);
    fflush(stdin);

    // 2. ridimensiono la memoria heap
    // realloc(sentence_access_pointer, (sizeof(char) * (len_str(sentence_access_pointer, '\0'))));

    // 3. prendo l'indirizzo per accedere alla memoria heap dove contiene i vari indirizzi iniziali
    split_access_pointer = split_str(sentence_access_pointer, ' ');

    // 4. stampo tutti i pezzi della frase e stampo le corrisporndenti dimensioni
    for (int i = 0; i <= str_cnt_condition_true(sentence_access_pointer, ' '); i++)
    {
        printf("\n%d ->", len_str(*(split_access_pointer + i), ' '));
        stampa_str(*(split_access_pointer + i), ' ');
    }

    // 5. ricerca dei indici maggiori
    for (int i = 0; i <= str_cnt_condition_true(sentence_access_pointer, ' '); i++)
    {
        if (len_str(*(split_access_pointer + i), ' ') > len_str(*(split_access_pointer + max_len_index), ' '))
            max_len_index = i;
        else
        {
            if (len_str(*(split_access_pointer + i), ' ') < len_str(*(split_access_pointer + min_len_index), ' '))
                min_len_index = i;
        }
    }

    // 6. stampa del più lungo e il più corto
    printf("\n\nlongest: ");
    stampa_str(*(split_access_pointer + max_len_index), ' ');
    printf("\n\nshortest: ");
    stampa_str(*(split_access_pointer + min_len_index), ' ');

    // 7. libero le memorie utilizzate
    free(sentence_access_pointer);
    free(split_access_pointer);

    return 0;
}

void stampa_str(char *text_peek, char condition)
{
    // ! non capisco per quale motivo nn riesco a utilizzare or per lke due condizioni
    if (*text_peek != condition)
    {
        if (*text_peek != '\0')
        {
            printf("%c", *text_peek);
            stampa_str(text_peek + 1, condition);
        }
    }
}

int len_str(char *text_peek, char stop_condition)
{
    int _acc = 0;
    while (*text_peek != stop_condition)
    {
        if (*text_peek == '\0')
            break;
        ++text_peek, ++_acc;
    }
    return _acc;
}

char **split_str(char *original_str_peek, char condition)
{
    char *str_peek = original_str_peek;                             // backup della prima cella
    char **original_split_pointers = NULL, **split_pointers = NULL; // puntatori per il secondo heap
    int cnt_condition_true = str_cnt_condition_true(str_peek, ' ');

    // 1. malloc di una seconda zona di memoria che contiene i vari indirizzi iniziali, perciò la dimensione uguale alla dimensione del tipo * il numero di spazi + 1
    original_split_pointers = (char **)malloc(sizeof(char) * (cnt_condition_true + 1));
    split_pointers = original_split_pointers;

    // 2. ciclo per registrare i vari indirizzi iniziali della prima zona di memoria
    str_peek = original_str_peek;
    *split_pointers = str_peek;
    split_pointers++;
    for (; *str_peek != '\0'; str_peek++)
    {
        if (*str_peek == ' ')
        {
            // alla cella puntata del secodo heap dò l'indirizzo della lettera iniziale contenente nel puntatore del primo heap
            *split_pointers = (str_peek + 1);
            split_pointers++;
        }
    }
    return original_split_pointers;
}

int str_cnt_condition_true(char *str_peek, char condition)
{
    int cnt = 0;
    for (; *str_peek != '\0'; str_peek++)
    {
        if (*str_peek == condition)
            cnt++;
    }
    return cnt;
}
