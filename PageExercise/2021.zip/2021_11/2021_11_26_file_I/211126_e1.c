/**
 * @file 211126_e1.c
 * @author tepag
 * @brief i file
 * @version 0.1
 * @date 2021-11-27
 *
 * @copyright Copyright (c) 2021
 *
 */

/*
il file è insieme di blocchi, dove in una zona di memoria vengono memorizzari i puntatori e nome
del file e altre proprietà

per evitare la frammentazione, si va a suddividere in blocchi molto piccoli (512bytes)

nella realtà quello che succede, il file system, va a leggerlo tutto e lo pusha nella memoria RAM
evitando il problema dei vari pezzi spezzati nella memoria secodaria

byte speciale end of file EOF

per evitareil fatoo che venga aperto tutto il file nella ram, si carica poco alla volta, e per
questo abbiamo un cursore che sisegna dove siamo arrivati col programma

agli occhi del programma, peraprire il file, si deve puntatore ad una struttura che contiene tutti i
dati

le quattro funzioni principali: open, close, read, write;
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{

    return 0;
}