#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define DIM 100

char *input_str();

int my_str_len(char *);

int main()
{
    char *pointer = NULL;
    pointer = input_str();
    puts(pointer);

    // funzione che faccia il calcolo della lunghezza di una stringa
    printf("\n%d", my_str_len(pointer));
    return 0;
}

char *input_str()
{
    char *str_access_pointer = malloc(sizeof(char));
    int flag = 0, i = 0;
    for (; flag == 0; i++)
    {
        str_access_pointer = realloc(str_access_pointer, sizeof(char) * (i + 1));
        *(str_access_pointer + i) = getchar();
        if (*(str_access_pointer + i) == '\n')
        {
            *(str_access_pointer + i) = '\0';
            flag++;
        }
    }
    return str_access_pointer;
}

int my_str_len(char *pointer)
{
    int cnt = 0;
    for (; *pointer != '\0'; pointer++)
        cnt++;
    return cnt;
}
