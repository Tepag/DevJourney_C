// funzione che trasforma una stringa di caratteri contente un numeor che lo trasformi un un numero
// intero

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

char *input_str();

int main()
{
    char *str1 = input_str();
    int number = 0, j = strlen_ i = 0, result = 0;

    for (; *(str1 + i) != '\0'; i++, j--)
    {
        number = ((int)(*(str1 + j)) - 48) * pow(10, i - 1);
        result += number;
    }

    printf("%d", number);

    return 0;
}

char *input_str()
{
    char *str_access_point = (char *)malloc(sizeof(char));
    for (int i = 0; (1); i++)
    {
        *(str_faccess_point + i) = getchar();
        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            break;
        }
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
    }
    return str_access_point;
}