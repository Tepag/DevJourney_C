/**
 * @file 211123_e1.c
 * @author Tepag
 * @brief An simple exercize with record
 * @version 0.2
 * @date 2021-11-23
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#define DIM 30

typedef struct people
{
    char name[DIM];
    char surname[DIM];
    int age;
    float grade;
} People;

People *create_addressbook(int);

void order_surname_rubrica(People *, int);

int main()
{
    int dim = 2;
    People p1, *rubrica = NULL;

    // lunghezza della struttura
    printf("\nlunghezza: %d", (int)sizeof(People));
    system("clear");

    printf("\n\n");
    rubrica = create_addressbook(dim);

    order_surname_rubrica(rubrica, dim);

    printf("print created structures:\n\n-----\n");
    for (int i = 0; i < dim; i++)
    {
        printf("\n%d.name: %s", i, (rubrica + i)->name);
        printf("\n%d.surname: %s", i, (rubrica + i)->surname);
        printf("\n%d.age: %d", i, (rubrica + i)->age);
        printf("\n\n-----\n");
    }

    free(rubrica);

    // con lo scanf puoi prendere in entrata più cose
    /*
    int c, d, e;
    printf("\n\ninserisci tre numeri:\n");
    scanf("%d %d %d", &c, &d, &e);
    printf("\n%d %d %d", c, d, e);*/

    return 0;
}

// Function
People *create_addressbook(int n)
{
    People *pointer = (People *)malloc(n * sizeof(People));

    for (int i = 0; i < n; i++)
    {
        printf("%d.name: ", i);
        scanf("%s", (*(pointer + i)).name);
        fflush(stdin);
        printf("%d.surname: ", i);
        scanf("%s", (pointer + i)->surname);
        fflush(stdin);
        printf("%d.age: ", i);
        scanf("%d", &(pointer + i)->age);
        fflush(stdin);
        system("clear");
        // scanf("%s %s %d", (*(pointer + i)).name, (pointer + i)->surname, &(pointer + i)->age);
    }

    return pointer;
}

// si copia tutto o si copia campo per campo?????
// my answer: tutto date che copia direttamente la rubrica
void order_surname_rubrica(People *rubrica, int dim)
{
    People tmp;
    for (int i = 0; i < dim; i++)
    {
        for (int j = i + 1; j < dim; j++)
        {
            if (strcmp((rubrica + i)->surname, (rubrica + j)->surname) > 0)
            {
                tmp = *(rubrica + i);
                *(rubrica + i) = *(rubrica + j);
                *(rubrica + j) = tmp;
            }
        }
    }
}
