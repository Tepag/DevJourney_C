/**
 * @file 211122_e1.c
 * @author Tepag
 * @brief programma che vada a simulare la maggior parte delle funzioni della string.h
 * @version 0.1
 * @date 2021-11-22
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char *input_str();
char *my_strcat(char *, char *);
char *my_strchr(char *, char);
int my_strcmp(char *, char *);
void my_strcpy(char *, char *);
int my_strlen(char *);
char *my_strrchr(char *, char);
char *my_strstr(char *, char *);
char *my_strtok(char *, char *);
char *my_strtok_v2(char *, char *);
char *my_strtok_v3(char *str, char *sep);

int main()
{
    char *pointer_str1 = NULL, *pointer_str2 = NULL;

    // 1. funzione che mi prende in entrata una stringa a avvalore a piacere
    pointer_str1 = input_str();
    pointer_str2 = input_str();

    // 2. my_strcat: Appends the string pointed to, by src to the end of the string pointed to by dest. TESTED
    // pointer_str1 = my_strcat(pointer_str1, pointer_str2);
    // printf("\ntest strcat: %s", pointer_str1);

    // 3. my_strncat: Appends the string pointed to, by src to the end of the string pointed to, by dest up to n characters long.

    // 4. my_strchr: Searches for the first occurrence of the character c (an unsigned char) in the string pointed to, by the argument str.
    // printf("%s", my_strchr(pointer_str1, ' '));

    // 5. my_strcmp: Compares the string pointed to, by str1 to the string pointed to by str2.
    // printf("\ntest strcmp: %d %d", my_strcmp(pointer_str1, pointer_str2), strcmp(pointer_str1, pointer_str2));

    // 6. my_strncmp: Compares at most the first n bytes of str1 and str2.

    // 7. my_strcoll: Compares string str1 to str2. The result is dependent on the LC_COLLATE setting of the location.

    // 8. my_strcpy: Copies the string pointed to, by src to dest. TESTED
    // my_strcpy(pointer_str1, pointer_str2);

    // 9. my_strncpy: Copies up to n characters from the string pointed to, by src to dest.

    // 10. my_strcspn: Calculates the length of the initial segment of str1 which consists entirely of characters not in str2.

    // 11. my_strerror: Searches an internal array for the error number errnum and returns a pointer to an error message string.

    // 12. my_strlen: Computes the length of the string str up to but not including the terminating null character. TESTED
    // printf("\nstrlen test: %d %d", my_strlen(pointer_str1), strlen(pointer_str1));

    // 13. my_strpbrk: Finds the first character in the string str1 that matches any character specified in str2.

    // 14. my_strrchr: Searches for the last occurrence of the character c (an unsigned char) in the string pointed to by the argument str.
    // printf("%s", my_strrchr(pointer_str1, ' '));

    // 15. my_strspn: Calculates the length of the initial segment of str1 which consists entirely of characters in str2.

    // 16. my_strstr: Finds the first occurrence of the entire string needle (not including the terminating null character) which appears in the string haystack.
    // puts(my_strstr(pointer_str1, pointer_str2) + strlen(pointer_str2));

    // 17. my_strtok: Breaks string str into a series of tokens separated by delim.
    puts(strtok(pointer_str1, "  "));
    puts(strtok(NULL, "  "));
    puts(pointer_str1);

    // 18. my_strxfrm: Transforms the first n characters of the string src into current locale and places them in the string dest.

    return 0;
}

// 1
char *input_str()
{
    char *str = (char *)malloc(sizeof(char));
    int i = 0, flag = 0;
    for (; flag == 0; i++)
    {
        str = (char *)realloc(str, (sizeof(char) * (i + 2)));
        *(str + i) = getchar();
        if (*(str + i) == '\n')
        {
            *(str + i) = '\0';
            flag++;
        }
    }
    return str;
}

// 2
char *my_strcat(char *des, char *src)
{
    des = (char *)realloc(des, (sizeof(char) * (my_strlen(des) + my_strlen(src) + 2)));
    printf("\n%d", my_strlen(des));
    my_strcpy((des + my_strlen(des)), src);
    printf("\n%d", my_strlen(des));
    return des;
}

// 4
char *my_strchr(char *pointer, char sep)
{
    for (; *pointer != '\0'; pointer++)
    {
        if (*pointer == sep)
            return pointer;
    }
    return NULL;
}

// 5
int my_strcmp(char *p1, char *p2)
{
    // compare all letter
    for (int i = 0; *(p1 + i) != '\0'; i++)
    {
        if (*(p1 + i) != *(p2 + i))
        {
            // if greater return 1
            if (*(p1 + i) > *(p2 + i))
                return 1;
            else // else return -1
                return -1;
        }
    }
    // if str1 is finished, the another one is longer
    return -1;
}

// 8
void my_strcpy(char *des, char *src)
{
    for (; *src != '\0'; des++, src++)
        *des = *src;
    *des = '\0';
}

// 12
int my_strlen(char *p)
{
    int cnt = 0;
    for (; *p != '\0'; p++)
        cnt++;
    return cnt;
}

// 14 da completare
char *my_strrchr(char *pointer, char sep)
{
    while (my_strchr(pointer, sep) != NULL)
    {
        pointer = my_strchr(pointer, sep) + 1;
    }
    return pointer - 1;
}

// 16
char *my_strstr(char *big, char *small)
{
    int j = 0;
    for (; *big != '\0'; big++)
    {
        if (*big == *(small + j))
        {
            j++;
            if (j == my_strlen(small))
                return (big - my_strlen(small) + 1);
        }
        else
            j = 0;
    }
    return NULL;
}

// 17
char *my_strtok(char *str, char *sep)
{
    static char *current = NULL;
    static int flag = 0;
    int j = 0;
    // utente mi pasa una stringa?
    if (str == NULL) // no: gli passo l'indirizzo del prossimo e gli mando il puntatore
    {
        // cerco e sostituisco
        current = current + my_strlen(current) + my_strlen(sep);
        for (int i = 0; *(current + i) != '\0'; i++)
        {
            if (*(current + i) == *(sep + j))
            {
                j++;
                if (j == my_strlen(sep))
                {
                    *(current + i - my_strlen(sep) + 1) = '\0';
                    return current;
                }
            }
            else
                j = 0;
        }
        if (flag == 0)
        {
            return current;
            flag = 1;
        }
        else
            return NULL;
    }
    else // sì: lo memorizzo nella corrente e gli ripasso il punatore alla prima cella
    {
        flag = 0;
        current = str;
        // sostituisco separatore con il terminatore;
        for (int i = 0; *(current + i) != '\0'; i++)
        {
            if (*(current + i) == *(sep + j))
            {
                j++;
                if (j == my_strlen(sep))
                {
                    *(current + i - my_strlen(sep) + 1) = '\0';
                    return str;
                }
            }
            else
                j = 0;
        }
        return NULL;
    }
}

char *my_strtok_v2(char *str, char *sep)
{
    static char *current = NULL;
    static int flag = 0;
    int j = 0;

    char *pointer = NULL;
    // utente mi pasa una stringa?
    if (str == NULL) // no: gli passo l'indirizzo del prossimo e gli mando il puntatore
    {
        // cerco e sostituisco
        current = current + my_strlen(current) + my_strlen(sep);
        if (my_strstr(current, sep) != NULL)
        {
            *(my_strstr(current, sep)) = '\0';
            return current;
        }

        if (flag == 0)
        {
            flag = 1;
            return current;
        }
        else
            return NULL;
    }
    else // sì: lo memorizzo nella corrente e gli ripasso il punatore alla prima cella
    {
        flag = 0, current = str;

        // sostituisco separatore con il terminatore;
        *(my_strstr(current, sep)) = '\0';
        return str;
    }
}

char *my_strtok_v3(char *str, char *sep)
{
    static char *current = NULL;
    static int flag = 0;
    int j = 0;
    char *pointer = NULL;
    if (str == NULL)
    {
        current = current + my_strlen(current) + my_strlen(sep);
        if (my_strstr(current, sep) != NULL)
        {
            *(my_strstr(current, sep)) = '\0';
            return current;
        }
        if (flag == 0)
        {
            flag = 1;
            return current;
        }
        else
            return NULL;
    }
    else
    {
        flag = 0, current = str;
        *(my_strstr(current, sep)) = '\0';
        return str;
    }
}