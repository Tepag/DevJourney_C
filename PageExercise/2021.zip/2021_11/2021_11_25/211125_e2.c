/**
 * @file 211125_e2.c
 * @author Tepag
 * @brief string exercize
 * @version 0.1
 * @date 2021-11-25
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>

char *input_str();
void reverse_str(char *);
void remove_exept_alphabet(char *);
int str_char_frequency(char *, char);
void conver_to_lowercase(char *);

int main()
{
    // 1. Write a program in C to input a string and print it
    char *pointer = input_str();
    puts(pointer);

    // 4. Write a program in C to print individual characters of string in reverse order
    reverse_str(pointer);

    // 17. Write a program in C to remove characters in String Except Alphabets
    remove_exept_alphabet(pointer);

    // 18. Write a program in C to Find the Frequency of Characters
    printf("frequency: %d", str_char_frequency(pointer, 'd'));

    // 23. Write a program in C to convert a string to lowercase
    conver_to_lowercase(pointer);

    free(pointer);
    return 0;
}

char *input_str()
{
    char *str = (char *)malloc(sizeof(char));
    int i = 0, flag = 0;
    for (; flag == 0; i++)
    {
        str = (char *)realloc(str, (sizeof(char) * (i + 2)));
        *(str + i) = getchar();
        if (*(str + i) == '\n')
        {
            *(str + i) = '\0';
            flag++;
        }
    }
    return str;
}

void reverse_str(char *p)
{
    char tmp;
    int i = 0;
    for (i = 0; i < strlen(p) / 2; i++)
    {
        tmp = *(p + i);
        *(p + i) = *(p + strlen(p) - 1 - i);
        *(p + strlen(p) - 1 - i) = tmp;
    }
}

void remove_exept_alphabet(char *p)
{
    for (; *p != 0; p++)
    {
        if (*p > 'z' || *p < 'Z')
            strcpy(p, p + 1);
    }
}

int str_char_frequency(char *p, char sep)
{
    int cnt = 0;
    for (; *p != 0; p++)
    {
        if (*p == sep)
            cnt++;
    }
    return cnt;
}

void conver_to_lowercase(char *pointer)
{
    for (; *pointer != 0; pointer++)
    {
        if (*(pointer) >= 'A' && *(pointer) <= 'Z')
            *(pointer) = *(pointer) + ('a' - 'A');
    }
}