char *stk(char *s, char *sep) // stringa e separatore
{
    static char *c = NULL;
    if (s == NULL) // se ci da NULL
    {
        // c = s; questo nel if non ci va il resto è tutto ugule al else
        int i = substring(c, sep);                      // la funzione che mi dice dove è un carattere passo la striga e il separatore
        char *r = (char *)malloc(sizeof(char) * i + 1); // per i perchè la i mi dice la posizione del primo separatore  e quindi la dim della str +1 è per il terminatore
        for (int j = 0; j < i; j++)
            r[j] = c[i];
        c = c + i + 1;
        return r;
    }
    else // stringa nuova
    {
        c = s;
        int i = substring(c, sep);                      // la funzione che mi dice dove è un carattere passo la striga e il separatore
        char *r = (char *)malloc(sizeof(char) * i + 1); // per i perchè la i mi dice la posizione del primo separatore  e quindi la dim della str +1 è per il terminatore
        for (int j = 0; j < i; j++)
            r[j] = c[i];
        c = c + i + 1; // ovviamente devo spostare il puntatore sul indrizzo dello spazio+1 per andare oltre
        // se il separatore non è lo spazio ovviamente non posso fare +1 ma c=c+i+strlen(set); così vado avanti della lung
        return r; // ritorno la nuova stringa che è il primo pezzo
    }
}