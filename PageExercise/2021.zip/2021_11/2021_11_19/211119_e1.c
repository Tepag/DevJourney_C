/*
funzione che indica se una stringa è anagramma di un'altro



*/

#include <stdio.h>
#include <stdlib.h>

char *autolen_str_input();

int my_str_len(char *);

int check_anagram(char *, char *);

char *order_str(char *);

int change_all(char *, char, char);

void reverse_print(char *pointer);

int main(int argc, char **argv)
{
    char *str1 = NULL, *str2 = NULL;

    for (int i = 1; i < argc; i++)
        puts(*(argv + i));

    /*
    printf("inserisci una stringa: ");
    str1 = autolen_str_input();
    fflush(stdin);

    printf("inserisci una stringa: ");
    str1 = autolen_str_input();
    fflush(stdin);*/

    // printf("%d", my_str_len(str1));

    /*
    if (check_anagram(*(argv + 1), *(argv + 2)) == 1)
        printf("\nanagram");
    else
        printf("\nno anagram");*/

    reverse_print(*(argv + 1));

    return 0;
}

char *autolen_str_input()
{
    char *str_access_pointer = malloc(sizeof(char));
    for (int i = 0, flag = 0; flag == 0; i++)
    {
        *(str_access_pointer + i) = getchar();
        if (*(str_access_pointer + i) == '\n')
        {
            *(str_access_pointer + i) = '\0';
            flag++;
        }
    }

    return str_access_pointer;
}

int my_str_len(char *pointer)
{
    int cnt = 0;
    for (; *pointer != '\0'; pointer++)
        cnt++;
    return cnt;
}

int check_anagram(char *str1, char *str2)
{
    // check if two ahve the same lenght
    if (my_str_len(str1) != my_str_len(str2))
        return -1;

    char *ordered_str1 = NULL, *ordered_str2 = NULL;
    // order two string
    ordered_str1 = order_str(str1);
    ordered_str2 = order_str(str2);

    // check if they have the same character
    for (int i = 0; i < my_str_len(str1); i++)
    {
        if (*(ordered_str1 + i) != *(ordered_str2 + i))
        {
            free(ordered_str1);
            free(ordered_str2);
            return -1;
        }
    }

    free(ordered_str1);
    free(ordered_str2);

    return 1;
}

char *order_str(char *pointer)
{
    char *ordered_str_pointer = malloc(sizeof(char) * my_str_len(pointer));
    char tmp;

    for (int i = 0; i < (my_str_len(pointer) + 1); i++)
        *(ordered_str_pointer + i) = *(pointer + i);

    for (int i = 0; i < my_str_len(pointer); i++)
    {
        for (int j = i; j < my_str_len(pointer); j++)
        {
            if (*(ordered_str_pointer + i) > *(ordered_str_pointer + j))
            {
                tmp = *(ordered_str_pointer + i);
                *(ordered_str_pointer + i) = *(ordered_str_pointer + j);
                *(ordered_str_pointer + j) = tmp;
            }
        }
    }

    return ordered_str_pointer;
}

int change_all(char *pointer, char find_char, char changed_char)
{
    int cnt = 0;
    for (; *pointer != '\0'; pointer++)
    {
        if (*pointer == find_char)
        {
            *pointer = changed_char;
            cnt++;
        }
    }
    return cnt;
}

void reverse_print(char *pointer)
{
    if (*pointer != '\0')
    {
        reverse_print(pointer++);
        putchar(*pointer);
    }
}