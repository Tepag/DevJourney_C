/**
 * @file 211130_e1.c
 * @author tepag
 * @brief
 * @version 0.1
 * @date 2021-11-30
 *
 * @copyright Copyright (c) 2021
 *
 */

// stream: flusso di dati infinito che finisce con un terminatore
// ./ corrente
// ../ cartella padre

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int num;
    FILE *fptr = fopen("./211130_e1.txt", "w");

    if (fptr == NULL)
    {
        printf("Error!");
        exit(1);
    }

    printf("Enter num: ");
    scanf("%d", &num);
    fflush(stdin);

    printf("\n\nsi sono riscontrati dei errori nel file (1==True)? %d", feof(fptr));
    printf("\n\nraggiungo la fine del file correttamente (EOF) (1==True)? %d", feof(fptr));

    fprintf(fptr, "%d", num);
    fclose(fptr);

    return 0;
}

/*
size_t fread(void *ptr, size_t size_of_elements, size_t number_of_elements, FILE *a_file);

size_t fwrite(const void *ptr, size_t size_of_elements, size_t number_of_elements, FILE *a_file);
*/

/*
vedi queste funzioni:
void fflush(FILE*file)
int feof(FILE*file)
*/