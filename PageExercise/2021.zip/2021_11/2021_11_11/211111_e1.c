/*
DUE FUNZIONI CHE FANNO:
- 1. INCOLLA: RICEVE DUE STRINGHE: e incolla la seconda stringa con la stringa nella stringa 1; il primo senza return;
- 2. incolla2: riceve due stringhe e restituisce l'indirizzo ad una terza stringa contenente le prime due separate da spazio e aggiunta di due caratteri alla fine lo spazio e lo \0
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DIM 100

void incolla(char *, char *);
char *incolla_v2(char *, char *);
void copy_to(char *, char *);

int main()
{
	char *p_str1 = (char *)malloc(sizeof(char) * DIM), *p_str2 = (char *)malloc(sizeof(char) * DIM);

	printf("inserisci stringa: ");
	gets(p_str1);
	fflush(stdin);

	printf("inserisci stringa: ");
	gets(p_str2);
	fflush(stdin);

	/*
	puts(p_str1);
	puts(p_str2);*/

	printf("\n%s", incolla_v2(p_str1, p_str2));

	incolla(p_str1, p_str2);
	printf("\n%s", p_str1);

	return 0;
}

void copy_to(char *source, char *destination)
{
	for (; *source != '\0'; destination++)
	{
		*destination = *source;
		source++;
	}
	*destination = '\0';
}

void incolla(char *p_str1, char *p_str2)
{
	int i = 0;
	p_str1 = (char *)realloc(p_str1, sizeof(char) * (strlen(p_str1) + strlen(p_str2)));
	*(p_str1 + strlen(p_str1)) = ' ';
	copy_to(p_str2, (p_str1 + strlen(p_str1)));
}

char *incolla_v2(char *p_str1, char *p_str2)
{
	char *p_str3 = (char *)malloc(sizeof(char) * (strlen(p_str1) + strlen(p_str2)));
	copy_to(p_str1, p_str3);
	*(p_str3 + strlen(p_str1)) = ' ';
	copy_to(p_str2, (p_str3 + strlen(p_str1) + 1));
	return p_str3;
}