/*
Realizzazione di un programma che faccia le stesse funzioni della strtok
*/

/*
Realizzare un programma che richiede una stringa composta da più parole, lunga massimo 100 char.
Scansionando la stringa deve comunicare:
- 1.lettera che compare più volte.
- 2.lettera che compare meno.
- 3.Numero di parole che compongono la stringa.
- 4.Parola più lunga.
- 5.Parola più corta.

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Funzione che verifica se una stringa è sottostringa di un'altra stringa
@param char* puntatore alla prima cella della prima stringa
@param char* puntatore alla prima cella della prima stringa
return int 0==no|1==sì
*/
int src_in_str(char *, char *);

void exchange_all(char *, char *);

char *input_str();

char *strtok_fun(char *, char *);

int main()
{
	char *str_start = NULL;

	printf("\ninserisci una frase:");
	str_start = input_str();

	puts(str_start);

	puts(strtok(str_start, " "));
	puts(strtok(NULL, "o"));
	puts(strtok(NULL, "o"));
	puts(strtok(NULL, "o"));
	//*/

	/*
	puts(strtok_fun(str_start, " "));
	puts(strtok_fun(NULL, "o"));
	puts(strtok_fun(NULL, "o"));
	puts(strtok_fun(NULL, "o")); //*/

	printf("\n");
	puts(str_start);

	free(str_start);
	return 0;
}

/*
char *strtok_fun(char *str, char *condition)
{
	// creo una variabile al primo giro a null che mi durerà per le altre volte che chiamerà questa funzione
	static char *current = NULL, *r = NULL;

	// nel caso il mio utente mi inserisce un str = NULL mi basta passargli l'indirizzo della parola successiva dalla parola corrente, quando trovi \0 +1
	if (str == NULL)
	{
		exchange_all(current, condition);
		// sarà dato dalla cella corrente +lunghezza della stringa attuale più la lunghezza della condizione
		current = current + strlen(current) + strlen(condition);
		return current;
	}
	// in caso contrario dobbiamo registrare la stringa e comunicare la prima stringa
	else
	{
		current = str;
		// inoltre al primo giro devo anche sostituire tutte le condizione date con il valore '\0'
		exchange_all(current, condition);

		r = (char *)malloc(sizeof(char) * i);
		for (int j = 0; j < i; j++)
			*(r + j) = *(current + j);
return current;
}
} //*/

char *strtok_fun(char *str, char *condition)
{
	static char *current = NULL;

	if (str == NULL)
	{
		if (src_in_str(current, condition) != 0)
		{
			current = current + src_in_str(current, condition) + strlen(condition) + 1;
			*(current + src_in_str(current, condition)) = '\0';
			return current;
		}
		else
		{
			current = current + strlen(current) + 1;
			return current;
		}
	}
	else
	{
		current = str;
		*(current + src_in_str(current, condition)) = '\0';
		return current;
	}
}

void exchange_all(char *str, char *condition)
{
	for (int i = 0; *(str + i) != '\0'; i++)
	{
		if (*(str + i) == *condition)
			*(str + i) = '\0';
	}
}

int src_in_str(char *str, char *condition)
{
	int i = 0, j = 0, index = 0;
	for (i = 0; *(str + i) != '\0'; i++)
	{
		j = (*(str + i) == *(condition + j)) ? (j + 1) : 0;
		if (*(condition + j) == '\0')
			return i;
	}
	return 0;
}

char *input_str()
{
	char *str_access_point = (char *)malloc(sizeof(char));
	for (int i = 0; (1); i++)
	{
		*(str_access_point + i) = getchar();
		if (*(str_access_point + i) == '\n')
		{
			*(str_access_point + i) = '\0';
			break;
		}
		str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
	}
	return str_access_point;
}