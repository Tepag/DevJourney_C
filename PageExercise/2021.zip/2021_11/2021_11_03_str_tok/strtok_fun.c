/*
Realizzazione di un programma che faccia le stesse funzioni della strtok
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*Funzione che ritorna il valore da aggiungere al puntatore iniziale per trovare la prima condizione
@param char* puntatore alla prima cella della prima stringa
@param char* puntatore alla prima cella della prima stringa
return int del numero da aggiungere alla prima cella della parola
*/
int src_in_str(char *, char *);

char *input_str();

char *strtok_fun(char *, char *);

int main()
{
    char *str_start = NULL;

    printf("\ninserisci una frase:");
    str_start = input_str();

    /*
    puts(str_start + src_in_str(str_start, " "));
    printf("\n\nlunghezza fino alla cella scelta: %d\n\n", src_in_str(str_start, " "));
    */

    puts(strtok_fun(str_start, " "));
    puts(strtok_fun(NULL, " "));
    puts(strtok_fun(NULL, " "));
    puts(strtok_fun(NULL, " ")); //*/

    free(str_start);
    return 0;
}

char *strtok_fun(char *str, char *condition)
{
    static char *current = NULL;
    if (str == NULL)
    {
        puts(current);
        printf("\nlen: %d\n", src_in_str(current + 4, condition));
        if (src_in_str(current, condition) != 0)
        {
            current = current + src_in_str(current, condition) + strlen(condition);
            *(current + src_in_str(current, condition)) = '\0';
            return current;
        }
        else
        {
            current = current + strlen(current) + 1;
            return current;
        }
    }
    else
    {
        current = str;
        printf("\nlungh: %d\n", src_in_str(current, " "));
        *(current + src_in_str(current, condition)) = '\0';
        return current;
    }
}

int src_in_str(char *str, char *condition)
{
    int i = 0, j = 0, index = 0;
    for (i = 0; *(str + i) != '\0'; i++)
    {
        j = (*(str + i) == *(condition + j)) ? (j + 1) : 0;
        if (*(condition + j) == '\0')
            return i;
    }
    return 0;
}

char *input_str()
{
    char *str_access_point = (char *)malloc(sizeof(char));
    for (int i = 0; (1); i++)
    {
        *(str_access_point + i) = getchar();
        if (*(str_access_point + i) == '\n')
        {
            *(str_access_point + i) = '\0';
            break;
        }
        str_access_point = realloc(str_access_point, sizeof(char) * (i + 2));
    }
    return str_access_point;
}