/**
 * @file 211209_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief
 * @version 0.1
 * @date 2021-12-09
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LIMIT 10

typedef struct contact
{
    char name[20];
    char surname[20];
    char cell[20];
    char mail[255];
} Contact;

Contact *add_contact();
void show_contact(Contact*);
int* src_contact(Contact **, char*, int, int*);

//funzione che salci sul file
//funzione che legga dal file

enum turn
{
    On = 1,
    Off = 0,
};

int main()
{
    int occupied_slot = 0, choose = 0, i = 0, *found_index, found_index_len=0;
    enum turn button = On;
    Contact* rubrica[LIMIT];
    char src_word[20];

    for(i=0;i<LIMIT;i++)
        rubrica[i]=NULL;

    while (button)
    {
        // menu di scelta di cosa fare
        printf("\n\nper continuare permere invio\n");
        getchar();
        system("clear");
        printf("Menu:\n1. Add\n2. Show\n3. Src\n4. Edit\n5. Del\n0. Exit\n\nchoose: ");
        scanf("%d", &choose);
        fflush(stdin);

        switch (choose)
        {
            // add contact
            case 1:{
                if (occupied_slot < LIMIT ){
                    rubrica[occupied_slot]=add_contact();
                    occupied_slot++;
                }
                else
                    printf("\nSpazio pieno\n");
                break; 
            }
            
            // show contact
            case 2:{
                for(i=0; i<LIMIT; i++){
                    if(rubrica[i]!=NULL){
                        printf("\n");
                        show_contact(rubrica[i]);
                    }
                }
                break;
            }
                
            // src contact
            case 3:{
                printf("\ninserire il nome da ricercare: ");
                scanf("%s", src_word);
                fflush(stdin);

                found_index=src_contact(rubrica, &src_word[0], LIMIT, &found_index_len);
                printf("\n\n%d", found_index_len);
                free(found_index);
                break;
            }

            // edit contact
            case 4: 

                break;

            // del contact
            case 5: 

                break;

            // exit
            case 0: 
                button = Off;
                break;

            default:{
                printf("\nPlease insert a valid option\n");
                break;
            }
        }
    }
    return 0;
}

Contact *add_contact(){
    Contact *contact=(Contact*)malloc(sizeof(Contact));
    printf("inserire corrispettivamente nome cognome cellulare mail:\n");
    scanf("%s %s %s %s", contact->name, contact->surname, contact->cell, contact->mail);
    fflush(stdin);
    return contact;
}

void show_contact(Contact* pointer){
    printf("\nnome: %s\ncognome: %s\ncellulare: %s\nmail: %s", pointer->name, pointer->surname, pointer->cell, pointer->mail);
}

int* src_contact(Contact **p_contact, char* p_sep, int _l, int *found_len){
    int* p_found=(int*)malloc(sizeof(int)*1), flag=0, cnt=0;
    char* pointer_to_struct=NULL;
    
    for(int i=0;i<_l;i++){
        pointer_to_struct=((*(p_contact+i))->name);
        flag=strcmp(pointer_to_struct, p_sep);
        if(flag==0){
            p_found=(int*)realloc(p_found,(sizeof(int)*(cnt+2)));
            *(p_found + cnt)=i;
            cnt++;
        }
    }

    *found_len=cnt+1;
    return p_found;
}



/*
Contact edit_contact()
{
}*/