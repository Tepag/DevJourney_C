/**
 * @file 211201_e1.c
 * @author your name (you@domain.com)
 * @brief Realizzare un programma che basandosi sulla struttura Persona
   formata dai campi {cognome[20], nome[20], int eta} permetta di:
   1- Acquisire due strutture come singole variabili (non un array).
   2- Visualizzare le due diverse strutture.
   3- Determinare quale delle due persone è più giovane.
   Realizzando un funzione per ogni richiesta.
 * @version 0.1
 * @date 2021-12-02
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct people
{
    char cognome[20];
    char nome[20];
    int age;
} People;

void input_people(People *);
void view_people(People *);
People *people_younger(People *, People *);

int main()
{
    People p1, p2;
    input_people(&p1);
    input_people(&p2);

    printf("\np1\n");
    view_people(&p1);

    printf("\np2\n");
    view_people(&p2);

    printf("\n%s is younger", people_younger(&p1, &p2)->nome);

    return 0;
}

void input_people(People *pointer)
{
    printf("inserire rispettivamente cognome nome e età: \n");
    scanf("%s %s %d", pointer->cognome, pointer->nome, &(pointer->age));
    fflush(stdin);
}

void view_people(People *pointer)
{
    printf("cognome: %s;\nnome: %s;\neta\': %d.\n", pointer->cognome, pointer->nome, pointer->age);
}

People *people_younger(People *p1, People *p2)
{
    if (p1->age > p2->age)
        return p2;
    else
        return p1;
}
