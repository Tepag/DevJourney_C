/**
 * @file 211203_e1.c
 * @author your name (you@domain.com)
 * @brief realizzare un programma che richiede 3 strutture frazione costituite da {int numeratore; int denominatore}.
   realizzare e funzioni per:
   - inizializzare le 3 frazioni.
   - stampare le tre frazioni.
   - calcolare il valore decimale di una frazione.
   - sommare due frazioni tra loro.
 * @version 0.1
 * @date 2021-12-03
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct frazione
{
    int numeratore;
    int denominatore;
} Frazione;

void frazione_init(Frazione *);
void frazione_view(Frazione *);
float frazione_to_float(Frazione *);
float frazione_sum(Frazione *, Frazione *);
Frazione *frazione_sum_v2(Frazione *, Frazione *);

int main()
{
    Frazione f1, f2, f3, *pointer;
    frazione_init(&f1);
    frazione_init(&f2);
    frazione_init(&f3);

    frazione_view(&f1);
    frazione_view(&f2);
    frazione_view(&f3);

    printf("\n\n%.2f", frazione_to_float(&f1));

    printf("\n\n%.2f", frazione_sum(&f1, &f2));

    printf("\n\n");
    pointer = frazione_sum_v2(&f1, &f2);
    frazione_view(pointer);

    return 0;
}

void frazione_init(Frazione *pointer)
{
    printf("inserisci rispettivamente numeratore e denominatore:\n");
    scanf("%d %d", &pointer->numeratore, &pointer->denominatore);
    fflush(stdin);
}

void frazione_view(Frazione *pointer)
{
    printf("%d/%d\n", pointer->numeratore, pointer->denominatore);
}

float frazione_to_float(Frazione *pointer)
{
    return ((float)(pointer->numeratore) / (float)(pointer->denominatore));
}

float frazione_sum(Frazione *pointer1, Frazione *pointer2)
{
    return frazione_to_float(pointer1) + frazione_to_float(pointer2);
}

Frazione *frazione_sum_v2(Frazione *p1, Frazione *p2)
{
    int cnt = p1->denominatore > p2->denominatore ? p1->denominatore : p2->denominatore;
    Frazione *p3 = (Frazione *)malloc(sizeof(Frazione *));

    // cerco il minimo comune divisore
    for (;; cnt++)
    {
        if ((cnt % p1->denominatore == 0) && (cnt % p2->denominatore == 0))
            break;
    }

    // calcolo per contenere, dove al denominatore trovo il cnt
    p3->numeratore = (p1->numeratore * cnt / p1->denominatore) + (p2->numeratore * cnt / p2->denominatore);
    p3->denominatore = cnt;

    return p3;
}
