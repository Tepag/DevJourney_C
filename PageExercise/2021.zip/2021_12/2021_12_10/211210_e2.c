/**
 * @file 211209_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief
 * @version 0.1
 * @date 2021-12-09
 *
 * @copyright Copyright (c) 2021
 *
 */


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LIMIT 3
#define DIM_CHAR 20

typedef struct contact
{
    char name[DIM_CHAR];
    char surname[DIM_CHAR];
    char cell[DIM_CHAR];
    char mail[255];
} Contact;

Contact *add_contact();
void show_contact(Contact*);
int* src_contact(Contact **, char*, int, int*);
//funzione che salci sul file
//funzione che legga dal file

enum turn
{
    On = 1,
    Off = 0,
};

int main()
{
    int occupied_slot = 0, choose = 0, i = 0, found_index_len;
    char src_word[20], *p_word;
    enum turn button = On;
    Contact* rubrica[LIMIT], *p_contact_tmp;
    
    // vado a inizializzare tutti i indirizzi a NULL
    for(i=0;i<LIMIT;i++)
        rubrica[i]=NULL;

    //giro finché in il mio bottone è sullo stato ON
    while (button){

        // menu di scelta di cosa fare:
        printf("\n\nper continuare permere invio\n");
        getchar();
        system("clear");
        printf("Menu:\n1. Add\n2. Show\n3. Src\n4. Edit\n5. Del\n0. Exit\n\nchoose: ");
        scanf("%d", &choose);
        fflush(stdin);

        switch (choose)
        {
            // add contact
            case 1:{
                // il massimo dei slot sono 10
                printf("\n\nMemory: %d / %d\n", occupied_slot, LIMIT);
                if (occupied_slot < LIMIT ){
                    rubrica[occupied_slot]=add_contact();
                    occupied_slot++;
                }
                else
                    printf("\nSpazio pieno\n");
                break; 
            }
            
            // show contact
            case 2:{
                for(i=0; i<LIMIT; i++){
                    if(rubrica[i]!=NULL){
                        printf("\n");
                        show_contact(rubrica[i]);
                    }
                }
                break;
            }
                
            // src contact
            case 3:{
                printf("\ninserire il nome da ricercare: ");
                scanf("%s", src_word);
                fflush(stdin);
                
                // ! NON RIESCO A FARLA CON I PUNTATORI 
                // src_contact(rubrica, src_word, LIMIT, &found_index_len);

                for(i=0;i<LIMIT&&(rubrica[i]!=NULL);i++){
                    if(strcmp(src_word, rubrica[i]->name)==0){
                        printf("\nposition: %d -> %s", i, src_word);
                    }
                }
                
                break;
            }

            // edit contact
            case 4:{
                printf("\ninserire il nome da editare: ");
                scanf("%s", src_word);
                fflush(stdin);

                for(i=0;i<LIMIT&&(rubrica[i]!=NULL);i++){
                    if(strcmp(src_word, rubrica[i]->name)==0){
                        printf("\nOld: \n");
                        show_contact(rubrica[i]);
                        printf("\n\ninserire corrispettivamente nome cognome cellulare mail da immettere:\n");
                        scanf("%s %s %s %s", rubrica[i]->name, rubrica[i]->surname, rubrica[i]->cell, rubrica[i]->mail);
                        fflush(stdin);
                        printf("\nNew: \n");
                        show_contact(rubrica[i]);
                    }
                }
                break;
            }

            // del contact
            case 5:{
                printf("\ninserire il nome da cancellare: ");
                scanf("%s", src_word);
                fflush(stdin);

                // cancello
                for(i=0;i<LIMIT&&(rubrica[i]!=NULL);i++){
                    if(strcmp(src_word, rubrica[i]->name)==0){
                        free(rubrica[i]);
                        rubrica[i]=NULL;
                        printf("\ndelete complete");
                    }
                }

                // riordino
                for(i=0;i<LIMIT&&(rubrica[i]!=NULL);i++){
                    for(int j=0;j<LIMIT&&(rubrica[j]!=NULL);j++){
                        if(strcmp(src_word, rubrica[i]->name)<0){
                            p_contact_tmp=rubrica[i];
                            rubrica[i]=rubrica[j];
                            rubrica[j]=p_contact_tmp;
                        }
                    }
                }
                break;
            }

            // exit
            case 0: {
                button = Off;
                break;
            }

            default:{
                printf("\nPlease insert a valid option\n");
                break;
            }
        }
    }
    return 0;
}

Contact *add_contact(){
    Contact *contact=(Contact*)malloc(sizeof(Contact));
    printf("inserire corrispettivamente nome cognome cellulare mail:\n");
    scanf("%s %s %s %s", contact->name, contact->surname, contact->cell, contact->mail);
    fflush(stdin);
    return contact;
}

void show_contact(Contact* pointer){
    printf("\nnome: %s\ncognome: %s\ncellulare: %s\nmail: %s", pointer->name, pointer->surname, pointer->cell, pointer->mail);
}

/**
int* src_contact(Contact **p_contact, char* p_sep, int _l, int *found_len, char src_word){
    int* p_found=(int*)malloc(sizeof(int)*1), flag=0, cnt=0;
    char* pointer_to_struct=NULL;

    for(int i=0;i<LIMIT&&(p_contact[i]!=NULL);i++){
        pointer_to_struct=((*(p_contact+i))->name);
        if(strcmp(src_word, p_contact[i]->name)==0){
            printf("\nposition: %d -> %s", i, src_word);
            p_found=(int*)realloc(p_found,(sizeof(int)*(cnt+2)));
            *(p_found + cnt)=i;
            cnt++;
        }
    }

    *found_len=cnt+1;
    return p_found;
}*/
