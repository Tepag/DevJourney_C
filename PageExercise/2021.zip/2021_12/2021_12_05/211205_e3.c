/**
 * @file 211205_e3.c
 * @author tepag
 * @brief 4 azioni sui file
 * @version 0.1
 * @date 2021-12-05
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char *input_str();

int main()
{
    char *text = input_str(), character;

    // apertura di un file
    FILE *file_access_pointer = fopen("211205_e3.txt", "w+");

    // scrittura fwrite(puntatore_al_testo_da_scrivere, grandezza_di_un_carattere, lunghezza_stringa, file)
    fwrite(text, sizeof(char), strlen(text), file_access_pointer);

    // sposto il cursore nel file
    fseek(file_access_pointer, 0, SEEK_SET);

    // lettura
    while (1)
    {
        fread(&character, sizeof(char), 1, file_access_pointer);
        if (feof(file_access_pointer) == 1)
            break;
        putchar(character);
    }

    // chiusura
    fclose(file_access_pointer);

    return 0;
}

char *input_str()
{
    char *str = (char *)malloc(sizeof(char));
    int i = 0, flag = 0;
    for (; flag == 0; i++)
    {
        str = (char *)realloc(str, (sizeof(char) * (i + 2)));
        *(str + i) = getchar();
        if (*(str + i) == '\n')
        {
            *(str + i) = '\0';
            flag++;
        }
    }
    return str;
}