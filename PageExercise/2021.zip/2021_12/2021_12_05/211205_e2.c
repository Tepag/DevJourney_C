// An example program to demonstrate working
// of enum in C
#include <stdio.h>

enum week
{
    Mon,
    Tue,
    Wed = 8,
    Thur,
    Fri,
    Sat,
    Sun
};

// creo praticamente una sorta di strutture;
enum turn
{
    On = 1,
    False = 0
};

enum OpenMode
{
    read = 1,
    write = 2,
    binary = 4,
    text = 8,
    append = 16
};

int main()
{
    int day, x;

    day = Wed;
    printf("%d", day);

    x = On;

    // x contiene sia text che binary
    x = binary | text;
    printf("\n\n%d", x);

    // check se binary è all'interno di x
    if ((x & binary) == binary)
        printf("\nyep: %d", x & binary); // risposta sì

    if ((x & text) == text)
        printf("\nyep %d", x & text);

    return 0;
}