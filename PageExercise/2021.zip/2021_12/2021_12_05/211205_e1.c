/**
 * @file 211205_e1.c
 * @author tepag
 * @brief testare il funzionamento di alcuni operatori
 * @version 0.1
 * @date 2021-12-05
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 6;
    x >>= 1;
    printf("%d", x);
    return 0;
}