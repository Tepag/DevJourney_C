/**
 * @file 211210_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief 
 * @version 0.1
 * @date 2021-12-11
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LIMIT 3
#define DIM_CHAR 20

typedef struct contact
{
    char name[DIM_CHAR];
    char surname[DIM_CHAR];
    char cell[DIM_CHAR];
    char mail[255];
} Contact;

Contact *add_contact();
void show_contact(Contact*);
int* src_contact(Contact **, char*, int, int*);
//funzione che salci sul file
//funzione che legga dal file

int main()
{
    char src_word[20], *p_word;
    FILE* fp_in_out=fopen("rubrica","w+");
    Contact* rubrica[LIMIT];
    
    for(int i=0;i<LIMIT;i++){
        rubrica[i]=add_contact();
    }
    
    for(int i=0;i<LIMIT;i++){
        fwrite(rubrica[i], sizeof(Contact),1,fp_in_out);
    }

    fclose(fp_in_out);

    return 0;
}

Contact *add_contact(){
    Contact *contact=(Contact*)malloc(sizeof(Contact));
    printf("inserire corrispettivamente nome cognome cellulare mail:\n");
    scanf("%s %s %s %s", contact->name, contact->surname, contact->cell, contact->mail);
    fflush(stdin);
    return contact;
}
