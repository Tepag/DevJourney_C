/**
 * @file 211210_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief 
 * @version 0.1
 * @date 2021-12-11
 * 
 * @copyright Copyright (c) 2021
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LIMIT 3
#define DIM_CHAR 20

typedef struct contact
{
    char name[DIM_CHAR];
    char surname[DIM_CHAR];
    char cell[DIM_CHAR];
    char mail[255];
} Contact;

Contact *add_contact();
void show_contact(Contact*);
int* src_contact(Contact **, char*, int, int*);
//funzione che salci sul file
//funzione che legga dal file

int main()
{
    FILE* fp_in_out=fopen("rubrica","r");
    Contact* rubrica[LIMIT], *readed_contact;
    
    // lettura dai file
    for(int i=0;i<LIMIT;i++){
        readed_contact=(Contact*)malloc(sizeof(Contact));
        fread(readed_contact,sizeof(Contact),1,fp_in_out);
        rubrica[i]=readed_contact;
    }

    // stampa
    for(int i=0;i<LIMIT;i++){
        show_contact(rubrica[i]);
    }

    fclose(fp_in_out);

    return 0;
}

void show_contact(Contact* pointer){
    printf("\nnome: %s\ncognome: %s\ncellulare: %s\nmail: %s", pointer->name, pointer->surname, pointer->cell, pointer->mail);
}