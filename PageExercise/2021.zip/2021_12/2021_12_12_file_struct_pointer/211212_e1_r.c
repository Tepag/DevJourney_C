/**
 * @file 211210_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief
 * @version 0.1
 * @date 2021-12-11
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LIMIT 3
#define DIM_CHAR 20

typedef struct contact
{
    char *name;
    char *surname;
    char cell[DIM_CHAR];
    char mail[255];
} Contact;

Contact *add_contact();
void show_contact(Contact *);
int *src_contact(Contact **, char *, int, int *);
char *input_str_from_file(FILE *);

int main()
{
    FILE *fp_in = fopen("rubrica", "r");
    Contact *rubrica[LIMIT], *readed_contact;

    // lettura dal file
    for (int i = 0; i < LIMIT; i++)
    {
        // leggo il contatto ricordandomi di creare uno spazio per la struttura col record
        readed_contact = (Contact *)malloc(sizeof(Contact));
        fread(readed_contact, sizeof(Contact), 1, fp_in);

        // leggo il record; NB: i puntatori sono inutili al momento, non ancora aggiornati
        rubrica[i] = readed_contact;
        rubrica[i]->name = input_str_from_file(fp_in); // aggiorno il puntatore tramite funzione, vedi funzione riga 66
        rubrica[i]->surname = input_str_from_file(fp_in);
    }

    // stampa
    for (int i = 0; i < LIMIT; i++)
    {
        show_contact(rubrica[i]);
    }

    fclose(fp_in);

    return 0;
}

void show_contact(Contact *pointer)
{
    printf("\nnome: %s\ncognome: %s\ncellulare: %s\nmail: %s", pointer->name, pointer->surname, pointer->cell, pointer->mail);
}

char *input_str_from_file(FILE *fp)
{
    int len = 0;
    char *readed_text = NULL;

    // Secondo le regole applicate: [len_str][str]; per prima cosa leggerò la dimensione della stringa
    fread(&len, sizeof(int), 1, fp);

    // alloco uno spazio su misura per la nostra stringa
    readed_text = (char *)malloc((len) * sizeof(char));

    // leggo a uno a uno fino alla fine della stringa
    for (int i = 0; i < len; i++)
        fread(readed_text + i, sizeof(char), 1, fp);

    // ritrno il nuovo puntatore abilitando nome/cognome
    return readed_text;
}