/**
 * @file 211210_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief
 * @version 0.1
 * @date 2021-12-11
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LIMIT 3
#define DIM_CHAR 20

typedef struct contact
{
    char *name;
    char *surname;
    char cell[DIM_CHAR];
    char mail[255];
} Contact;

Contact *add_contact();
void show_contact(Contact *);
int *src_contact(Contact **, char *, int, int *);
char *input_str();

int main()
{
    char src_word[20], *p_word;
    FILE *fp_in_out = fopen("rubrica", "w+");
    Contact *rubrica[LIMIT];
    int lenght = 0;

    // riempio la rubrica di contatti
    for (int i = 0; i < LIMIT; i++)
    {
        rubrica[i] = add_contact();
    }

    // la mia soluzione sbagliata
    /**
    for(int i=0;i<LIMIT;i++){
        fwrite(rubrica[i], sizeof(Contact),1,fp_in_out);

        // subito seguito aggiungo il nome e il cognome, che avranno lunghezza variabile: ricorda di scrive il \0
        fwrite(rubrica[i]->name, strlen(rubrica[i]->name)+1,1,fp_in_out);
        fwrite(rubrica[i]->surname, strlen(rubrica[i]->surname)+1,1,fp_in_out);
    }*/

    // Soluzione: dato che non si sa la lunghezza si può mettere alla prima cella un intero con la lunghezza
    for (int i = 0; i < LIMIT; i++)
    {
        // scrivo per prima cosa la mia struttura; ricordando che name e surname hanno perso il loro valore di puntatore
        fwrite(rubrica[i], sizeof(Contact), 1, fp_in_out);

        // scrivo la lunghezza della mia stringa nome e subito seguito ci scrivo la stringa da inserire
        lenght = ((int)strlen(rubrica[i]->name)) + 1;
        fwrite(&lenght, sizeof(int), 1, fp_in_out);
        fwrite(rubrica[i]->name, strlen(rubrica[i]->name) + 1, 1, fp_in_out);

        lenght = ((int)strlen(rubrica[i]->surname)) + 1;
        fwrite(&lenght, sizeof(int), 1, fp_in_out);
        fwrite(rubrica[i]->surname, strlen(rubrica[i]->surname) + 1, 1, fp_in_out);
    }
    // immaginabile come -> [struttura1][lunghezza_stringa1][stringa1][lunghezza_stringa2][stringa2]

    fclose(fp_in_out);

    return 0;
}

Contact *add_contact()
{
    Contact *contact = (Contact *)malloc(sizeof(Contact));
    printf("inserire corrispettivamente nome cognome cellulare mail:\n");
    contact->name = input_str();
    contact->surname = input_str();
    scanf("%s %s", contact->cell, contact->mail);
    fflush(stdin);
    return contact;
}

char *input_str()
{
    char *str = (char *)malloc(sizeof(char));
    int i = 0, flag = 0;
    for (; flag == 0; i++)
    {
        str = (char *)realloc(str, (sizeof(char) * (i + 2)));
        *(str + i) = getchar();
        if (*(str + i) == '\n')
        {
            *(str + i) = '\0';
            flag++;
        }
    }
    return str;
}
