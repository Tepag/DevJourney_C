/**
 * @file 211215_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief funzionamento dell'
 * @version 0.1
 * @date 2021-12-15
 * 
 * @copyright Copyright (c) 2021
 * 
 */