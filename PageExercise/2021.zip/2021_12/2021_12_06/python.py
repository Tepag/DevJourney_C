# vi faccio veder un po di pyhon ok
print("hello world")
