/**
 * @file 211206_e1.c
 * @author Tepag (z190tpg@gmail.com)
 * @brief programma che mi vada a semplificare una frazione
 * @version 0.1
 * @date 2021-12-06
 *
 * @copyright Copyright (c) 2021
 *
 */

#include <stdio.h>
#include <stdlib.h>

typedef struct frazione
{
    int numeratore;
    int denominatore;
} Frazione;

void frazione_init(Frazione *);
void frazione_view(Frazione *);
void frazione_semplificazione(Frazione *);

int main()
{
    Frazione f1;
    frazione_init(&f1);
    frazione_semplificazione(&f1);
    frazione_view(&f1);
    return 0;
}

void frazione_init(Frazione *pointer)
{
    printf("inserisci rispettivamente numeratore e denominatore:\n");
    scanf("%d %d", &pointer->numeratore, &pointer->denominatore);
    fflush(stdin);
}

void frazione_view(Frazione *pointer)
{
    printf("%d/%d\n", pointer->numeratore, pointer->denominatore);
}

void frazione_semplificazione(Frazione *p)
{
    Frazione *fr_s = (Frazione *)malloc(sizeof(Frazione *));
    int limit = p->numeratore < p->denominatore ? p->numeratore : p->denominatore;

    // semplifico per numeri che siano minori del numero stesso
    for (int cnt = 2; cnt <= limit; cnt++)
    {
        if ((p->numeratore % cnt == 0) && (p->denominatore % cnt == 0))
        {
            p->numeratore /= cnt, p->denominatore /= cnt;
            cnt = 2;
        }
    }
}
