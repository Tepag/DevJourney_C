/*
modificare i programmi di conversione e somma binaria/ottale/esadecimale in un unico programma che richieda all'utente i due numeri da somma e 
la BASE da utilizzare.
Permettere all'utente di ripetere l'esecuzione del programma a suo piacimento.
TIP:
do-while e scelta != 0.
*/

#include<conio.h>
#include<stdio.h>
#include<stdlib.h>

#define DIM_BIN 32
#define DIM_OCT 16
#define DIM_HEX 8

int main(){
    int scelta=0;
    int v1=0;
    int v2=0;
    int i=0;
    int bin1[DIM_BIN];
    int bin2[DIM_BIN];
    int bin3[DIM_BIN];
    int oct1[DIM_OCT];
    int oct2[DIM_OCT];
    int oct3[DIM_OCT];
    int hex1[DIM_HEX];
    int hex2[DIM_HEX];
    int hex3[DIM_HEX];
    
    
    
    do{
        
        //inizializzo il display
        system("CLS");

        //instruzioni
        printf("\ninseriti due numeri e scelta base disponibili fa la somma\n\n");

        //input 1
        printf("\ninserire valore 1:");
        scanf("%d",&v1);
        fflush(stdin);

        //input 2
        printf("\ninserire valore 2:");
        scanf("%d",&v2);
        fflush(stdin);

        //menu start
        printf("\noption:\n");
        printf("1 -> SUM_BIN\n");
        printf("2 -> SUM_OCT\n");
        printf("3 -> SUM_HEX\n");
        printf("0 -> EXIT\n");

        //cattura scelta
        printf("scelta(numero):");
        scanf("%d",&scelta);
        fflush(stdin);

        //switch per le varie scelte
        switch(scelta){
            //scelta DEC a BIN e somma
            case 1:{
                //inizializzo
                for(i=0;i<DIM_BIN;i++){
                    bin1[i]=0;
                    bin2[i]=0;
                    bin3[i]=0;
                }

                //conversione da DEC a BIN del valore 1
                for(i=0; i<DIM_BIN; i++){
                    bin1[i]=v1%2;
                    v1/=2;
                }

                printf("\nvalore 1 in BIN: ");
                for(i=DIM_BIN-1; i>=0; i--){
                    printf("%d",bin1[i]);
                    if(i%4==0){
                        printf(" ");
                    }
                }

                printf("\n");

                //conversione da DEC a BIN del valore 2
                for(i=0; i<DIM_BIN; i++){
                    bin2[i]=v2%2;
                    v2/=2;
                }

                printf("\nvalore 2 in BIN: ");
                for(i=DIM_BIN-1; i>=0; i--){
                    printf("%d",bin2[i]);
                    if(i%4==0){
                        printf(" ");
                    }
                }

                printf("\n");

                //somma tra i due numeri
                for(i=0; i<DIM_BIN; i++){
                    bin3[i]=bin1[i]+bin2[i]+bin3[i];
                    bin3[i+1]=bin3[i]/2;
                    bin3[i]=bin3[i]%2;
                }

                printf("somma: ");
                //stampo la somma
                for(i=DIM_BIN-1;i>=0; i--){
                    printf("%d",bin3[i]);
                    if(i%4==0){
                        printf(" ");
                    }
                }

                break;
            }

            //scelta DEC a OCT e somma
            case 2:{
                //inizializzo le tre celle
                for(i=0;i<DIM_OCT;i++){
                    oct1[i]=0;
                    oct2[i]=0;
                    oct3[i]=0;
                }

                //trasformo il v1 da DEC a OCT
                for(i=0; i<DIM_OCT;i++){
                    oct1[i]=v1%8;
                    v1/=8;
                }

                //trasformo il v2 da DEC a OCT
                for(i=0;i<DIM_OCT;i++){
                    oct2[i]=v2%8;
                    v2/=8;
                }

                //stampo valore 1 e 2 in ottale
                printf("valore 1 in OCT: ");
                for(i=DIM_OCT-1;i>=0;i--){
                    printf("%d",oct1[i]);
                    if(i%4==0){
                        printf(" ");
                    }
                }

                printf("valore 2 in OCT: ");
                printf("\n");
                for(i=DIM_OCT-1;i>=0;i--){
                    printf("%d",oct2[i]);
                    if(i%4==0){
                        printf(" ");
                    }
                }
                printf("\n");

                //faccio la somma
                for(i=0;i<DIM_OCT;i++){
                    oct3[i]=oct1[i]+oct2[i]+oct3[i];
                    oct3[i+1]=oct3[i]/8;
                    oct3[i]=oct3[i]%8;
                }

                //stampo
                printf("somma: ");
                for(i=DIM_OCT-1; i>=0; i--){
                    printf("%d",oct3[i]);
                    if(i%4==0){
                        printf(" ");
                    }
                }

                break;
            }

            //scelta DEC a HEX e somma
            case 3:{
                //inizializzo tutto
                for(i=0;i<DIM_HEX;i++){
                    hex1[i]=0;
                    hex2[i]=0;
                    hex3[i]=0;
                }

                //da DEC a HEX
                for(i=0;i<DIM_HEX;i++){
                    hex1[i]=v1%16;
                    v1/=16;

                    hex2[i]=v2%16;
                    v2/=16;
                }

                //stampo
                printf("valore 1 in HEX: ");
                for(i=DIM_HEX-1;i>=0;i--){
                    if(hex1[i]<10){
                        printf("%d",hex1[i]);
                    }
                    else{
                        printf("%c",('A'+hex1[i]-10));
                    }
                    if(i%4==0){
                        printf(" ");
                    }
                }

                printf("\n");

                //stampo
                printf("valore 2 in HEX: ");
                for(i=DIM_HEX-1;i>=0;i--){
                    if(hex2[i]>9){
                        printf("%c",('A'+hex2[i]-10));
                    }
                    else{
                        printf("%d",hex2[i]);
                    }
                    if(i%4==0){
                        printf(" ");
                    }
                }

                printf("\n");

                //faccio la somma
                for(i=0;i<DIM_OCT;i++){
                    hex3[i]=hex1[i]+hex2[i]+hex3[i];
                    hex3[i+1]=hex3[i]/16;
                    hex3[i]%=16;
                }

                //stampo
                printf("somma: ");
                for(i=DIM_HEX-1; i>=0;i--){
                    if(hex3[i]<=9){
                        printf("%d",hex3[i]);
                    }
                    else{
                        printf("%c",('A'+hex3[i]-10));
                    }
                    if(i%4==0){
                        printf(" ");
                    }
                }


                break;
            }

            //scelta EXIT
            case 0:{
                printf("\nil programma e\'terminato");
                break;
            }

            //scelta non disponibile
            default:{
                printf("\nscelta non disponibile");
                break;
            }
        }
        printf("\n\n");
        if(scelta!=0){
            system("PAUSE");
        }
    }

    while(scelta!=0);
    
    return(0);
}