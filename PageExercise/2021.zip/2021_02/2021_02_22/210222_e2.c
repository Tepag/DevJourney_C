/*
    inseriti numeri decimali da tastiera trasformarli in esadecimale e facciamo la somma
*/
#include <conio.h>
#include <stdio.h>

#define DIM 4


int main(){
    int n1, n2;     //variabili per i numeri in base 10
    int hex1[DIM], hex2[DIM], hex3[DIM+1];
    int i;

    // I STEP: richiedo i due valori in base 10 da condificare e sommare.
    printf("Numero 1: ");
    scanf("%d", &n1);
    fflush(stdin);
    printf("Numero 2: ");
    scanf("%d", &n2);
    fflush(stdin);

    // II STEP: converto i due numeri decimali in forma esadecimale
    for(i=0; i<DIM; i++){   // conversione primo numero
        hex1[i] = n1%16;
        n1 = n1 / 16;
    }
    

    for(i=0; i<DIM; i++){   // conversione secondo numero
        hex2[i] = n2%16;
        n2 = n2 / 16;
    }
    

    // III STEP: visualizzo i vettori binari, al CONTRARIO

    printf("Hex 1: ");
    for(i=DIM-1; i>=0; i--){
        if(hex1[i] <= 9)
            printf("%d", hex1[i]);
        else
            printf("%c", 'A'+(hex1[i]-10) );
    }
    printf("\n");

    printf("Hex 2: ");
    for(i=DIM-1; i>=0; i--){
        if(hex2[i] <= 9)
            printf("%d", hex2[i]);
        else
            printf("%c", 'A'+(hex2[i]-10) );
    }
    printf("\n");

    // IV STEP: eseguo la somma binaria tra bin1 e bin2 con risultato in bin3
    for(i=0; i<DIM+1; i++)  // azzero il vettore bin3 per prepararlo alla somma.
        hex3[i] = 0;

    for(i=0; i<DIM; i++){
        hex3[i] = hex1[i] + hex2[i] + hex3[i];
        hex3[i+1] = hex3[i] / 16;
        hex3[i] = hex3[i] % 16;
    }
   
    printf("Hex 3: ");
    if(hex3[DIM] != 0)
        printf("OVERFLOW!");
    else{
        for(i=DIM-1; i>=0; i--){
            if(hex3[i] <= 9)
                printf("%d", hex3[i]);
            else
                printf("%c", 'A'+(hex3[i]-10) );
        }

    }
}