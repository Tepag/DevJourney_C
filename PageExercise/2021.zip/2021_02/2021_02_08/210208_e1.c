/*
programma che stam,pa a video un quadrato di asterischi, il tringolo inferiore alla diagonale e superiore alla diagonale

*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#define DIM 10
int main(){
    int x=0;
    int y=0;
    int casi=0;

    //quadrato
    for(y=0; y<DIM; y++){
        for(x=0; x<DIM; x++){
            printf("* ");
        }

        printf("\n");
    }
     
    printf("\n\n");
    //tringolo inferiore
    for(y=0; y<DIM; y++){
        for(x=0; x<DIM; x++){
            if(x<=y){
                printf("* ");
            }
            
        }

        printf("\n");
    }

    printf("\n\n");

    //triangolo superiore
    for(y=0; y<DIM; y++){
        for(x=DIM-1; x>=0; x--){
            if(x<=y){
                printf("* ");
            }
            else{
                printf("  ");
            }
        }

        printf("\n");
    }

    printf("\n\n");

    //trangolo/_|
    for(y=0;y<DIM;y++){
        for(x=0;x<DIM;x++){

        }
    }

    //cornice quadrato
    for(y=0; y<DIM; y++){
        for(x=0; x<DIM; x++){
            if(y==0||y==DIM-1){
                printf("* ");
            }
            else{
                printf("* ");
                for(x=1; x<DIM-1; x++){
                    printf("  ");
                }
                printf("* ");
            }
        }

        printf("\n");
    }

    printf("\n\n");

    //trangolo vertice centrale
    for(y=0; y<DIM; y++){
        for(x=DIM-1; x>=0; x--){
            if(x<=y){
                printf("* ");
            }
            else{
                printf(" ");
            }
                    
        }

        printf("\n");
    }

    printf("\n\n");

    return(0);
    
}