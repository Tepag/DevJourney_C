/*
Realizare un programma che inizializza una matrice 5x5 con valori random (range a piacere)
    - stampa la matrice.
    - ordina la matrice in ordine crescente.
    - stampa nuovamente la matrice.
*/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <time.h>

#define DIM 5

int main(){
    int i=0;
    int j=0;
    int x=0;
    int y=0;
    int yi=0;
    int tmp;

    srand(time(NULL));

    int mat[DIM][DIM];

    //inizializzo a valori random
    for(i=0; i<DIM; i++){
        for(j=0; j<DIM; j++){
            mat[i][j]=(rand()%25)+25;       //da 25 a 50
        }
    }

    //stampo matrice generato
    for(i=0; i<DIM; i++){
        for(j=0; j<DIM; j++){
            printf("%d  ",mat[i][j]);
        }
        printf("\n");
    }

    //comparo i numeri con i altri numeri per riordinare
    for(i=0; i<DIM; i++){
        for(j=0; j<DIM; j++){
                for(x=i; x<DIM; x++){               //nota bene che è =i enon 0
                    if(x == 1){
                        yi = j;
                    }
                    else{
                        yi=0;
                    }
                    
                for(y=yi; y<DIM; y++){
                    if(mat[i][j] > mat[x][y]){
                        tmp=mat[i][j];
                        mat[i][j]=mat[x][y];
                        mat[x][y]=tmp;
                    }
                }
            }
        }
    }

    printf("\n");

    for(i=0; i<DIM; i++){
        for(j=0; j<DIM; j++){
            printf("%d  ",mat[i][j]);
        }
        printf("\n");
    }



    return(0);
}