/*
Realizzare un programma C che inizializza una matrice 5x5 con valori casuali, la stampa video quindi determina il valore maggiore e minore, 
e comunica anche in quali celle compaiono questi valori. (coordinarte)
Secondo step: se il valore nella cella [0][0] è pari ordinare in modo crescente la matrice per righe; se è dispari ordinare la matrice in modo 
crescente per colonne.
Quindi stampare la matrice.
*/

#include<stdio.h>
#include<Stdlib.h>
#include<conio.h>
#include<time.h>

#define DIM 5

int main(){
    int mat[DIM][DIM];
    int i=0;
    int j=0;
    int m=0;
    int tmp=0;

    srand(time(NULL));

    //inzizializzo a valori random
    for(i=0; i<DIM; i++){
        for(j=0;j<DIM;j++){
            mat[i][j]=(rand()%900)+100;
        }
    }

    //stampo la matrice
    for(i=0; i<DIM; i++){
        for(j=0;j<DIM;j++){
            printf("%d ",mat[i][j]);
        }
        printf("\n");
    }

    //cerco il numero maggiore
    m=mat[0][0];
    for(i=0;i<DIM;i++){
        for(j=0;j<DIM;j++){
            if(m<mat[i][j]){
                m=mat[i][j];
            }
        }
    }
    for(i=0;i<DIM;i++){
        for(j=0;j<DIM;j++){
            if(m==mat[i][j]){
                printf("\n\nnumero maggiore localizzato nella cella mat[%d][%d] contenente valore %d\n",i,j,mat[i][j]);
            }
        }
    }


    //cerco numero minore
    for(i=0;i<DIM;i++){
        for(j=0;j<DIM;j++){
            if(m>mat[i][j]){
                m=mat[i][j];
            }
        }
    }
    for(i=0;i<DIM;i++){
        for(j=0;j<DIM;j++){
            if(m==mat[i][j]){
                printf("\n\nnumero minore localizzato nella cella mat[%d][%d] contenente valore %d\n\n",i,j,mat[i][j]);
            }
        }
    }
    return(0);
}