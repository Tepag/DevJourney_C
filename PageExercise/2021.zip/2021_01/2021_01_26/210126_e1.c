/*
Realizzare un programma C che inizializzi un vettore di 10 elementi interi con valori random tra 1 e 50. Esegue poi le seguenti operazioni:
- Visualizza il vettore.
- Calcola la media e visualizza per ogni valore di quanto si discosta (in positivo o in negativo).
- Richiede due indici e scambia il contenuto delle relative celle.
- Richiede un valore da tastiera e lo ricerca nel vettore, dove lo trova lo azzera.
*/

#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include<time.h>

#define DIM 10

int main(){
    int vet[DIM];
    int i=0;
    int somma=0;
    int media=0;
    int dif=0;
    
    for(i=0; i<DIM; i++){
        vet[i] = rand()%50 + 1;     //+1 che fa diventare da (0 a 49) a (1 a 50)

    }

    for(i=0; i<DIM; i++){
        printf("\nvalore vettore %d: %d", i+1, vet[i]);
        
    }

    //cercare distanza tra i vettori
    for(i=1; i<DIM; i++){
        dif=vet[i]-vet[i-1];
        printf("\ndistacco di: %d",dif);
    }

    for(i=0; i<DIM; i++){
        somma+=vet[i];
    }

    printf("\nvalore medio vettore: %d", somma/DIM);



    getchar();
    return(0);
}
