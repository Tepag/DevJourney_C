/*
    Algoritmo che condifica un numero decimale compreso tra 0 e 255  in formato binario.
*/
#include <conio.h>
#include <stdio.h>

#define DIM 32       // numero di bit della codifica binaria.

int main(){
    int num;        // variabile contenente il valore decimale intero.
    int bin[DIM];   // vettore per la codifica binaria di num.
    int i;

    // Step 1: richiedere il numero decimale intero da convertire.
    printf("Numero: ");
    scanf("%d", &num);
    fflush(stdin);

    // Step 2: converto il numero decimale in cifre binaria, con divisioni successive.
    /*for(i=0; i<DIM; i++){
        bin[i] = num%2;
        num = num / 2;
    } // */

    // togliere il commento a questo ciclo per vedere tutti i singoli valori interessati dalla scomposizione.
    printf("\n");
    for(i=0; i<DIM; i++){
        printf("Num: %d -> R[%d]: %d -> (num/2):%d\n",num, i, (num%2), (num/2));
        bin[i] = num%2;
        num = num / 2;
    } // */


    // Step 3: Visualizzo il vettore binario, attenzione IN ORDINE INVERSO!
    printf("\nBinario: ");
    for(i=DIM-1; i>=0; i--){
        printf("%d", bin[i]);
        if(i%4 == 0) printf(" ");
    }
    return(0);
}