/*
programma che fa conversione da base dieci a qualsiasi base
*/

#include<stdio.h>
#include<stdlib.h>
#include<conio.h>

#define DIM 32

int main(){
    int i=0;
    int base=0;         //la bese che si vuole andare
    int num=0;          //dumero da trasformare in base diversa
    int ris[DIM];

    //istruzione utente
    printf("\nquesto programma trasforma qualsiasi numero nella base scelta\n");

    //inserimento numero da trasformare
    printf("\ninserire il numero decimale:");
    scanf("%d", &num);
    fflush(stdin);

    //utente inserimento base
    printf("\ninserire la base:");
    scanf("%d", &base);
    fflush(stdin);

    //inizializzo
    for(i=0; i<DIM; i++){
        ris[i]=0;
    }

    //trasformare da decimale a base
    for(i=0; i<DIM; i++){
        ris[i]=num%base;
        num/=base;
    }

    //nel caso si ha una base maggiore di 10 si usano le lettere
    if(base>10){
        //li visualizzo al contrario con le lettere
        for(i=DIM-1;i>=0;i--){
            if(ris[i]>=10){
                printf("%c",('A'+ris[i]-10));
            }
            else{
                printf("%d",ris[i]);
            }
            if(i%4==0){
                printf(" ");
            }
        }
    }
    else{
        //li visualizzo al contrario
        for(i=DIM-1; i>=0; i--){
            printf("%d", ris[i]);
            if(i%4 == 0){
                printf(" ");
            }
        }
    }




    getchar();
    return(0);
}