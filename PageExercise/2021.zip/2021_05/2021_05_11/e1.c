/*programma che richiede in entrata base e altezza e quindi disegna il rettangolo con asterischi 
e calcola e comunica area e perimetro
*/
#include<stdio.h>

int main(){
    int base=0;
    int altezza=0;
    int i=0;
    int j=0;

    printf("\ninserisci altezza:");
    scanf("%d",&altezza);
    fflush(stdin);
    printf("\ninserisci base:");
    scanf("%d",&base);
    fflush(stdin);
    for(j=0;j<altezza;j++){
        //disegno rettangolo
        for(i=0;i<base;i++){
            printf("* ");
        }
        printf("\n");
    }
    printf("\n\n\n");
    //area
    printf("area: %d", altezza*base);

    //perimetro
    printf("\n\nperimetro: %d", (altezza*base)*2);
}
