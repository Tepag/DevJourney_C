//linguaggio molto simile al C, integra il html
//con dollaro variabile (dei tipi variant)
//senza dollaro => costanti

<html>
    <body>

    <?php
    echo "Hello World!";
    ?>

    </body>
</html> 
