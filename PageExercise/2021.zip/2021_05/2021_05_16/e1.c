#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define DIM 10
#define R 5
#define C 7

void initvet (int *v, int _d);

void stmpvet( int *v, int _d);

void initmat (int *mat, int _c, int _r);

void stmpmat (int *mat, int _c, int _r);

int main(){
    int vet[DIM];
    int mat[C][R];
    initvet(vet, DIM);
    printf("\n\n");
    initmat((int*)mat, C, R);
    stmpvet(vet,DIM);
    printf("\n\n");
    stmpmat((int*)mat, C, R);
    return 0;
}

void initvet (int *v, int _d){
    int i=0;
    for(i=0;i<_d;i++){
        *(v+i)=0;
    }
}

void initmat (int *mat, int _c, int _r){
    srand(time(NULL));
    int i=0;
    for(i=0;i<_c*_r;i++){
        *(mat+i)=rand()%10;
    }
}

void stmpvet( int *v, int _d){
        int i=0;
    for(i=0;i<_d;i++){
        printf("%4d", *(v+i));
    }
}

void stmpmat (int *mat, int _c, int _r){
    int i=0;
    for(i=0;i<_c*_r;i++){
        printf("%4d",*(mat+i));
        if((i+1)%_c==0){
            printf("\n");
        }
    }
}