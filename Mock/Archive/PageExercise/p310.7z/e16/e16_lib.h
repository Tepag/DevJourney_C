/*funzione che inizializza a zero un vettore
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void*/
void init_a_zero(int _v[], int _d);

/*funzione che randomizza i valori in un vettore dato il range
@param int[] vettore da randomizzare
@param int dimensione del vettore
@param int range minimo
@param int range massimo
@return void*/
void random_array(int _v[], int _d, int _start, int _end);

/*funzione che stampa un vettore
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void*/
void stampaVettore(int _v[], int _d);