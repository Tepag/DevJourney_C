/*
In un array vengono memorizzati i numeri di gara dei piloti che hanno portato a termine la prima prova
in un secondo array vengono invece messi i numeri di gara dei piloti hanno portato a termine la seconda prova
crea tre array con il numeri di gara dei piloti che: 
hanno portato a termine entrambi, solo la prima e solo la seconda

RECORD: 22m 34s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e16_lib.c"

#define NUMERO_PILOTI 5

int main(){
    int prv1[NUMERO_PILOTI];
    int prv2[NUMERO_PILOTI];

    int succ_all[NUMERO_PILOTI];
    int succ_first[NUMERO_PILOTI];
    int succ_second[NUMERO_PILOTI];

    random_array(prv1, NUMERO_PILOTI, 0, 9);
    random_array(prv2, NUMERO_PILOTI, 0, 9);

    printf("il numero della prima prova superata per pilota:\n");
    stampaVettore(prv1, NUMERO_PILOTI);
    printf("\n");
    printf("il numero della seconda prova superata per pilota:\n");
    stampaVettore(prv2, NUMERO_PILOTI);

    init_a_zero(succ_all, NUMERO_PILOTI);
    init_a_zero(succ_first, NUMERO_PILOTI);
    init_a_zero(succ_second, NUMERO_PILOTI);

    for(int i=0;i<NUMERO_PILOTI; i++){
        if(prv1[i] == prv2[i]){
            succ_all[i] = prv1[i];
        }
        else{
            if(prv1[i] > prv2[i]){
                succ_first[i] = (prv1[i] - prv2[i]);
            }
            else{
                succ_second[i] = ((prv1[i] - prv2[i])*(-1));
            }
        }
    }

    printf("\nentrambe: \n");
    stampaVettore(succ_all, NUMERO_PILOTI);

    printf("\nprimo: \n");
    stampaVettore(succ_first, NUMERO_PILOTI);

    printf("\nsecondo: \n");
    stampaVettore(succ_second, NUMERO_PILOTI);
}