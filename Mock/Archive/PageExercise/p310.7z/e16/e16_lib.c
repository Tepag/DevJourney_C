#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#include "e16_lib.h"

void init_a_zero(int _v[], int _d){                               
    int i = 0;
    for (i = 0; i < _d; i++){
        _v[i] = 0;
    }
}

void random_array(int _v[], int _d, int _start, int _end){         
    int i;
    for (i = 0; i < _d; i++){
        _v[i] = rand() % (_end - _start + 1) + _start;
    }
}

void stampaVettore(int _v[], int _d){                       
    int i = 0;
    for (i = 0; i < _d; i++){
        printf("%d ", _v[i]);
    }
}