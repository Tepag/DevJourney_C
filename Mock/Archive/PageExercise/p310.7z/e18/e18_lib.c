#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#include "e18_lib.h"

void random_array(int _v[], int _d, int _start, int _end){         
    int i;
    for (i = 0; i < _d; i++){
        _v[i] = rand() % (_end - _start + 1) + _start;
    }
}

int src_max(int _v[], int _d){
    int max=0;
    int i=0;

    for(i=0;i<_d;i++){
        if(_v[i]>max){
            max=i;
        }
    }

    return(max);
}

void print_if(int _v[], int _d, int _m){
    int i=0;

    for(i=0;i<_d;i++){
        if (_v[i]==0){
            printf("\nil giorno %d non ha aperto il libro", i+1);
        }
        else{
            if(i==_m){
                printf("\nil giorno %d e\' stato registrto con giorno con piu\' ore di studio", i+1);
            }
        }
    }
}

void stampaVettore(int _v[], int _d){                       
    int i = 0;
    for (i = 0; i < _d; i++){
        printf("%d ", _v[i]);
    }
}