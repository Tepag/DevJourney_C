
in un array Ore_studio vengono generate le ore studiate (0-4)
calcola e visualizza il numero totale di ore passate a studiare in un me