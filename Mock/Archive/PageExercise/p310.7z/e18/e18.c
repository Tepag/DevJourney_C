/*
in un array Ore_studio vengono generate le ore studiate (0-4)
calcola e visualizza il numero totale di ore passate a studiare in un mese
e i giorni/o che ha studiato per il numero di ore maggiore e i giorni in cui non
ha studiato

RECORD: 21m 06s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e18_lib.c"

#define GIORNI 30
int main(){
    int ore_studio[GIORNI];
    int max=0;

    //randomizzo array con i numeri da 0 a 4
    random_array(ore_studio, GIORNI, 0, 4);
    printf("\n");

    //stampa del vettore
    stampaVettore(ore_studio, GIORNI);
    printf("\n");

    //la ricerca della posizione col numero maggiore
    max = src_max(ore_studio, GIORNI);
    printf("\n");

    //la stampa delle giornate con il massimo e il minimo
    print_if(ore_studio, GIORNI, max);
    printf("\n");
}

