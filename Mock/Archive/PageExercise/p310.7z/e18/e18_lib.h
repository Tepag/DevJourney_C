/*funzione che randomizza i valori in un vettore dato il range
@param int[] vettore da randomizzare
@param int dimensione del vettore
@param int range minimo
@param int range massimo
@return void*/
void random_array(int _v[], int _d, int _start, int _end);

/*funzione che ricerca la posizione del numero maggiore nel vettore
@param int[] vettore
@param int dimensione del vettore
@return int della posizione del primo numero maggiore
*/
int src_max(int _v[], int _d);

/*funzione che stampa solo se c'è zero o se c'è la corrispondenza con il paramtero inserito
@param int[] vettore
@param int dimensione del vettore
@param int condizione per stampare secpondaria
@return void
*/
void print_if(int _v[], int _d, int _m);

/*funzione che stampa un vettore
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void*/
void stampaVettore(int _v[], int _d);