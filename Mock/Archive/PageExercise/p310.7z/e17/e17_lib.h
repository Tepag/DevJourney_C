/*funzione che stampa un vettore
@param int[] vettore da inizializzare a 0
@param int dimensione vettore
@return void*/
void stampaVettore(int _v[], int _d);