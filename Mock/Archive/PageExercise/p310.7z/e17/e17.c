/*
posizione 1, 2, 3 = 1, e posizione con i >= 4 è uguale alla somma 
di posizione i-1 e i-3, la dimensione è decisa da un numero casuale

RECORD: 11m 20s
*/

#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include "e17_lib.c"

int main(){
    srand(time(NULL));
    int limite = 0;
    limite = rand()%30;
    int cnt=0;
    int i=0;
    int vet[limite];

    for(i=1; i<4; i++){
        vet[i]=1;
    }
    for(i=4; i<limite; i++){
        vet[i] = (vet[i-1] + vet[i-3]);
    }

    stampaVettore(vet, limite);
    
    return 0;
}


