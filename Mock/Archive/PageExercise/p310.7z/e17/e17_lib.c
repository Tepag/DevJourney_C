#include <time.h>
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#include "e17_lib.h"

void stampaVettore(int _v[], int _d){                       
    int i = 0;
    for (i = 0; i < _d; i++){
        printf("%d ", _v[i]);
    }
}