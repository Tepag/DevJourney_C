#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"e19_lib.h"

void gen_prt_vet (int _v[], int _d){
    srand(time(NULL));
    for(int i=0; i<_d; i++){
        _v[i]= rand()%10+1;
        printf("%d ",_v[i]);
    }
}

int mediavet (int _v[], int _d){
    int somma =0;
    for(int i=0; i<_d; i++){
        somma+=_v[i];
    }
    return(somma/_d);
}

int totvet (int _v[], int _d){
    int somma =0;
    for(int i=0; i<_d; i++){
        if ((i==6) || (i==7) || (i==8)){
            somma+=_v[i];
        }
    }
    return(somma);
}

int SrcMaxPos (int _v[], int _d){
    int pmax = _v[0];
    for(int i=0; i<_d; i++){
        if (_v[pmax]<_v[i]){
            pmax=i;
        }
    }
    return(pmax);
}

int SrcMInPos (int _v[], int _d){
    int pmin = _v[0];
    for(int i=0; i<_d; i++){
        if (_v[pmin]>_v[i]){
            pmin=i;
        }
    }
    return(pmin);
}

int mediavetFiltered (int _v[], int _d){
    int somma =0;
    for(int i=0; i<_d; i++){
        if ((i!=6) || (i!=7) || (i!=8)){
            somma+=_v[i];
        }
    }
    return(somma/(_d-3));
}
