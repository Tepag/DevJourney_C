/*Funzione che inizializza un vettore dando numeri casuali
@param int[] vettore
@param int dimensione del vettore
@return void*/
void gen_prt_vet (int [], int);

/*Funzione che inizializza un vettore dando numeri casuali
@param int[] vettore
@param int dimensione del vettore
@return int della media di tutto il vettore*/
int mediavet (int [], int);

/*Funzione che inizializza un vettore dando numeri casuali
@param int[] vettore
@param int dimensione del vettore
@return int del totale delle posizioni 6, 7, 8*/
int totvet (int [], int);

/*Funzione che inizializza un vettore dando numeri casuali
@param int[] vettore
@param int dimensione del vettore
@return int posizione del vettore con il numero maggiore*/
int SrcMaxPos (int [], int);

/*Funzione che inizializza un vettore dando numeri casuali
@param int[] vettore
@param int dimensione del vettore
@return int posizione del vettore con il numero minore*/
int SrcMInPos (int [], int);

/*Funzione che inizializza un vettore dando numeri casuali
@param int[] vettore
@param int dimensione del vettore
@int media dei numeri (esclusi 6, 7, 8*/
int mediavetFiltered (int [], int);