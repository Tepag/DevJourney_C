/*
array di 12 elementi sono memorizzati le presenze mensili in un mese, calcola:
- la media delle presenze in un anno
- il numero tot delle presenze durante l'estate
- il mese in cui si è registrato il massimo di presenze
- il mese con il numero di presenze minime
- la media delle presenze escludendo i mesi estivi

RECORD: 35m 45s
*/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"e19_lib.c"

#define DIM 12

int main(){
    int mesi[DIM];
    
    gen_prt_vet(mesi, DIM);
    printf("\nmedia: %d", mediavet(mesi, DIM));
    printf("\ntotale presenze estive: %d", totvet(mesi, DIM));
    printf("\nil mese in cui c\'e\' stato il picco: %d", SrcMaxPos(mesi, DIM));
    printf("\nil mese in cui ha il minimo numero di presenze: %d", SrcMInPos(mesi, DIM));
    printf("\nmedia(escludendo i mesi estivi): %d", mediavet(mesi, DIM));
    return 0;

}