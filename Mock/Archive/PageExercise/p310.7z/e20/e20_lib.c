#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "e20_lib.h"

void random_array(int _v[], int _d, int _start, int _end){         
    srand(time(NULL));
    int i;
    for (i = 0; i < _d; i++){
        _v[i] = rand() % (_end - _start + 1) + _start;
    }
}

void reverseVettore(int _v[], int _d){
    int tmp;
    int i;
    for(i=0; i<_d/2; i++){
        tmp = _v[i];
        _v[i] = _v[_d - i - 1];
        _v[_d - i - 1] = tmp;
    }
}

void from_vet_to_polynomial(int _v[], int _d){
    int i =0;
    //lo stampo sottoforma di polinomio
    for(i=_d-1; i>=0; i--){
        //verifico se il numero equivale a zero per decidere se mettere x^numero e mettere direttamente +0
        if(_v[i]==0){
            printf("+0 ");
        }
        else{
            //verifico se l'esponente è equivalente a zero così da evitare di mettere x^numero
            if(i==0){
                //verifico se il numero è positivo o negativo per aggiungere + nel caso in cui il numero risulta positiva
                if(_v[i]>=0){
                    printf("+%d ", _v[i]);
                }
                else{
                printf("%d ", _v[i]); 
                }
            }
            else{
                if(_v[i]>=0){
                    printf("+%dx^%d ", _v[i], i);
                }
                else{
                printf("%dx^%d ", _v[i], i); 
                }
            }
        }
    }
}

void from_vet_to_polynomial_with_m(int _v[], int _d, int _m){
    int i=0;

    for(i=_d-1; i>=0; i--){
        if(i-_m<0){
            printf("");
            i--;
        }
        else{
            if(_v[i]==0){
                printf("+0 ");
            }
            else{
                //verifico se l'esponente è equivalente a zero così da evitare di mettere x^numero
                if((i-_m)==0){
                    //verifico se il numero è positivo o negativo per aggiungere + nel caso in cui il numero risulta positiva
                    if(_v[i]>=0){
                        printf("+%d ", _v[i]);
                    }
                    else{
                    printf("%d ", _v[i]); 
                    }
                }
                else{
                    if(_v[i]>=0){
                        printf("+%dx^%d ", (_v[i]*i), i-_m);
                    }
                    else{
                    printf("%dx^%d ", (_v[i]*i), i-_m); 
                    }
                }
            }
        }
    }
        
}
