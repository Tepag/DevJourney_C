/*
un polinomio di ordine n e il grado di derivazione m, stampa il polinomio risultante

RECORD: 1h 29m
*/
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include "e20_lib.c"

#define DIM 10

int main(){
    int vet[DIM];
    int m=0;

    //inizializzo vettore
    random_array(vet, DIM, -9, 9);

    //stampa di prova
    for(int i=0; i<DIM; i++){
        printf("%dx^%d ", vet[i], i);
    }

    printf("\n\n");
    reverseVettore(vet, DIM);

    from_vet_to_polynomial(vet, DIM);

    printf("\n");
    printf("inserire la m per la sua derivata: ");
    scanf("%d",&m);
    fflush(stdin);

    from_vet_to_polynomial_with_m(vet, DIM, m);

    return 0;
}