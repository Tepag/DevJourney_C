/*funzione che randomizza i valori in un vettore dato il range
@param int[] vettore da randomizzare
@param int dimensione del vettore
@param int range minimo
@param int range massimo
@return void*/
void random_array(int _v[], int _d, int _start, int _end);


/*funzione che esegue il reverse di un vettore
@param int[] Vettore di cui fare il reverse
@param int Dimensione del vettore
@return void */
void reverseVettore(int _v[], int _d);

/*funzione che segue la trasformazione da vettore e polinomio
@param int[] Vettore 
@param int Dimensione del vettore
@return void */
void from_vet_to_polynomial(int _v[], int _d);

/*funzione che segue la trasformazione da vettore e polinomio derivato con la m scelta
@param int[] Vettore 
@param int Dimensione del vettore
@param int valore di m
@return void */
void from_vet_to_polynomial_with_m(int _v[], int _d, int _m);