/*
visualizzazione di una tavola pitagorica dall'8 al 15

RECORD: 5m 09s
*/

#include <stdio.h>
#include <stdlib.h>

#define START 8
#define DIM 15

int main()
{
    int i = 0, j = 0;
    for (i = START; i < DIM; i++)
    {
        for (j = START; j < DIM; j++)
        {
            printf("%0.4d ", i * j);
        }
        printf("\n");
    }
    return 0;
}