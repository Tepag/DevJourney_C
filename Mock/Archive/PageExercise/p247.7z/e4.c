/*
prodotto di due numeri utilizzando il metodo delle somme successive dopo aver controllato input accettando solo valori positivi

RECORD: 10m 45s
*/

#include <stdio.h>
#include <stdlib.h>

int input_positivo();
int prodotto_trm_ric(int, int);

int main()
{
    int i = 0;
    int n1 = 0;
    int n2 = 0;

    n1 = input_positivo();
    n2 = input_positivo();

    printf("\n\nil prodotto equivale a: %d", prodotto_trm_ric(n1, n2));
}

int input_positivo()
{
    int _n = 0;
    do
    {
        printf("\ninserire il numero: ");
        scanf("%d", &_n);
        fflush(stdin);
    } while (_n < 0);
    return _n;
}

int prodotto_trm_ric(int _n1, int _n2)
{
    int somma = 0;
    int i = 0;
    for (i = _n2; i > 0; i--)
    {
        somma += _n1;
    }
    return somma;
}