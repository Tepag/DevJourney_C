/*
scrivi un programma che, dati in input n numeri interi e un numero x, determini:
quanti sono maggiori/minori/ uguali a x

RECORD: 7m 35s
*/

#include <stdio.h>
#include <stdlib.h>
#define DIM 10

int main()
{
    int vet[DIM];
    int x = 0;
    int cnt_minori = 0, cnt_maggiori = 0, cnt_uguali = 0;

    printf("\ninserisci il numero con cui comparare i numeri successivi: ");
    scanf("%d", &x);
    fflush(stdin);

    for (int i = 0; i < DIM; i++)
    {
        printf("\ninserisci numero: ");
        scanf("%d", &vet[i]);
        fflush(stdin);

        //insieme di contatori
        if (vet[i] < x)
        {
            cnt_minori++;
        }
        else
        {
            if (vet[i] == x)
            {
                cnt_uguali++;
            }
            else
            {
                cnt_maggiori++;
            }
        }
    }

    printf("\n\nuguali: %d\n\nmaggiori: %d\n\nminori: %d", cnt_uguali, cnt_maggiori, cnt_minori);
    return 0;
}