/*
programma che visualizzi i primi 12 multipli di un numero n inserito da tastiera utilizzando il ciclo for

RECORD: 5m 52s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n = 0;
    int cnt = 0;
    printf("\n inserisci il numero di cui vedere i primi 12 multipli: ");
    scanf("%d", &n);
    fflush(stdin);
    for (int i = 0; i < 12; i++)
    {
        printf("%d ", n * i);
    }
    return 0;
}