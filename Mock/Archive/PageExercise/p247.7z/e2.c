/*
dato un input e tre caratteri; visualizza il numero di volte * i numeri inseriti successivamente

RECORD: 6m 37s
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 3

int main()
{
    int num = 0;
    int vet[DIM];
    int i = 0;

    printf("\ninserire il numero di volte da ripetere: ");
    scanf("%d", &num);
    fflush(stdin);

    for (i = 0; i < DIM; i++)
    {
        printf("\ninserire il numero: ");
        scanf("%d", &vet[i]);
        fflush(stdin);
    }

    for (i = 0; i < num; i++)
    {
        for (int j = 0; j < DIM; j++)
        {
            printf("%d ", vet[j]);
        }
    }
}