/*
programma che visualizza i primi 100 numeri dispari a gruppi di 5

RECORD: 3m 56s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int cnt = 1;
    int cnt_stmp = 0;

    //incremento di voltain volta il cnt
    for (cnt = 1; cnt <= 100; cnt++)
    {

        //verifico se il cnt è un numero pari e se lo è lo stampo
        if (cnt % 2 != 0)
        {
            printf("%0.3d ", cnt);
            cnt_stmp++;
        }
        if (cnt_stmp % 5 == 0)
        {
            printf("\n");
        }
    }

    return 0;
}