/*
programma che conta quanti numeri sono positivi tra n numeri inseriti da tastiera

RECORD: 4m 12s
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 10

int main()
{
    int cnt = 0;
    int input = 0;
    for (int i = 0; i < DIM; i++)
    {
        printf("\ninserisci il numero: ");
        scanf("%d", &input);
        fflush(stdin);
        if (input >= 0)
        {
            cnt++;
        }
    }
    printf("\n\nsono stati inseriti %d numeriu positivi su %d numeri;", cnt, DIM);
    return 0;
}
