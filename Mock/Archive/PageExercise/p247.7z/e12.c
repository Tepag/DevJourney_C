/*
scrivi un programma che visualizzi la somma dei primi 12 naturali successivi a 8

RECORD: 2m 56s
*/

#include <stdio.h>
#include <stdlib.h>

#define START 8

int main()
{
    int num = START;
    int cnt = 0;
    int somma = 0;

    for (int i = 0; i < 12; i++)
    {
        somma += num;
        num++;
    }

    printf("\nla somma dei 12 numeri naturali successivi a 8 e\' pari a: %d", somma);
    return 0;
}