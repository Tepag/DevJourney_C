/*
un programma che dato un numero inserito visualizzi la media deisuoi divisori

RECORD: 5m 42s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 0;
    int cnt = 0;
    int input = 0;
    int somma = 0;

    printf("\ninserisci il numero di cui vedere la media dei suoi divisori: ");
    scanf("%d", &input);
    fflush(stdin);

    /*faccio un ciclo per trovare i divisori,se li trovo incremento di uno il cnt dei divisori e 
    stampo il divisore, inoltro lo aggiungo ad una somma che poi faro dividere per il cnt*/
    for (int i = 0; i <= input; i++)
    {
        if (input % i == 0)
        {
            printf("%d ", i);
            cnt++;
            somma += i;
        }
    }
    printf("\n\nla media dei divisori = %d ", somma / cnt);
    return 0;
}