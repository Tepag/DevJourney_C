/*
scrivi un programma che visualizzi i primi 100 numer pari

RECORD: 5m 28s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int cnt = 1;

    //incremento di voltain volta il cnt
    for (cnt = 1; cnt <= 100; cnt++)
    {
        //verifico se il cnt è un numero pari e se lo è lo stampo
        if (cnt % 2 == 0)
        {
            printf("\n%0.3d ", cnt);
        }
    }

    return 0;
}