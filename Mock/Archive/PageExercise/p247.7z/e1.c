/*
leggi un numero num indicato dall'utente e calocola e stampa la somma di tutti i numeri compresi da 0 e num

RECORD: 14m 02s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    float input = 0;
    float somma = 0;

    printf("\nserisci il numero con cui terminare la serie di somma tra 0 e il numero: ");
    scanf("%f", &input);
    fflush(stdin);

    for (int i = 1; i < input; i++)
    {
        somma += i;
    }

    printf("\nla somma risulta di: %.2f", somma);

    return 0;
}