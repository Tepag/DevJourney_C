/*
dato un input n, stampare i n decimali dopo la virgola del pi greco

RECORD: 23m 54s + 14m 32s (per capire come funziona) + 4m 56s (complete)
*/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main()
{
    float pi_greco = 4;
    int input = 0;
    int cnt = 0;
    float div = 3;

    printf("\ninserisci il numer dei termini per formare il tuo pi greco: ");
    scanf("%d", &input);
    fflush(stdin);

    for (cnt = 0; cnt < input; cnt++)
    {
        if (cnt % 2 == 0)
        {
            pi_greco -= 4 / div;
        }
        else
        {
            pi_greco += 4 / div;
        }
        div += 2;
    }

    printf("\n\nil tuo pi greco e\' %f", pi_greco);

    return 0;
}