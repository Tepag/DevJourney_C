/*
fare tre cornici quadrate concentrice di dimensioni di 12 8 4

RECORD: 39m 08s + 32m 05s
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 12

int main()
{
    int i = 0, j = 0;

    /*
    //cornice più esterna
    for (i = 0; i < DIM; i++)
    {
        for (j = 0; j < DIM; j++)
        {
            //solo per la prima riga e l'ultima riga faccio tutta la riga e per gli altri invece solo la prima e ultima posizione
            if (i == 0 || i == DIM - 1)
            {
                printf("* ");
            }
            else
            {
                if (j == 0 || j == DIM - 1)
                {
                    printf("* ");
                }
                else
                {
                    printf("  ");
                }
            }
        }
        //finisco una riga e vado alla suucessiva
        printf("\n");
    }
    */

    /*
    //cornice più esterna
    for (i = 0; i < DIM; i++)
    {
        for (j = 0; j < DIM; j++)
        {
            //solo per la prima riga e l'ultima riga faccio tutta la riga e per gli altri invece solo la prima e ultima posizione
            if ((i == 0 || i == DIM - 1) || ((i == 2 && j != 1 && j != DIM - 2) || (i == DIM - 3 && j != 1 && j != DIM - 2)) || ((i == 4 && j != 3 && j != 1 && j != DIM - 4 && j != DIM - 2) || (i == DIM - 5 && j != 3 && j != 1 && j != DIM - 4 && j != DIM - 2)))
            {
                printf("* ");
            }
            else
            {
                if ((j == 0 || j == DIM - 1) || ((j == 2 || j == DIM - 3) && ((i != 1 && i != DIM - 2)) || ((j == 4 || j == DIM - 5) && ((i != 1 && i != 3 && i != DIM - 2 && i != DIM - 4)))))
                {
                    printf("* ");
                }
                else
                {
                    printf("  ");
                }
            }
        }
        //finisco una riga e vado alla suucessiva
        printf("\n");
    }
    */

    //cornice più esterna
    for (i = 0; i < DIM; i++)
    {
        for (j = 0; j < DIM; j++)
        {
            //condizione della cornice più esterna
            if ((i == 0 || i == DIM - 1) || (j == 0 || j == DIM - 1))
            {
                printf("* ");
            }
            else
            {
                //condizione delle cornice interna 1
                if ((i == 2 || i == DIM - 3) || (j == 2 || j == DIM - 3))
                {
                    //condizioni che mi permettono di eleiminare i bordi in eccesso
                    if ((i == 1 || i == DIM - 2) || (j == 1 || j == DIM - 2))
                    {
                        printf("  ");
                    }
                    else
                    {
                        printf("* ");
                    }
                }
                else
                {
                    //condizione delle cornice interna 2
                    if ((i == 4 || i == DIM - 5) || (j == 4 || j == DIM - 5))
                    {
                        //condizioni che mi permettono di eleiminare i bordi in eccesso
                        if ((i == 1 || i == DIM - 2 || i == 3 || i == DIM - 4) || (j == 1 || j == DIM - 2 || j == 3 || j == DIM - 4))
                        {
                            printf("  ");
                        }
                        else
                        {
                            printf("* ");
                        }
                    }
                    else
                    {
                        printf("  ");
                    }
                }
            }
        }
        //finisco una riga e vado alla successiva
        printf("\n");
    }

    return 0;
}
