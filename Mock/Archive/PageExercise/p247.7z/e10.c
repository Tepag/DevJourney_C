/*
programma che legge n numeri minori di 100 e calcoli la somma di soli numeri dispari

RECORD: 5m 25s
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 100

int main()
{
    int cnt = 1;
    int cnt_stmp = 0;
    int vet[DIM];
    int somma = 0;

    for (int i = 0; i < DIM; i++)
    {
        printf("\ninsert the number: ");
        scanf("%d", &vet[i]);
        fflush(stdin);
    }

    for (int i = 0; i < DIM; i++)
    {
        if (vet[i] % 2 != 0)
        {
            somma += vet[i];
        }
    }
    printf("\n\nla somma di numeri dispari e\' %d", somma);

    return 0;
}