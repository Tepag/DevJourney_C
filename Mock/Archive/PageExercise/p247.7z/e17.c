/*
un programma che dato n numeri in ingreso , calcoli la somma di quelli di posto dispari e la somma
di quelli pari, infine calola la differenza fra le due somme

RECORD: 10m 22s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 0;
    int somma_pari = 0, somma_dispari = 0;
    int input = 0;

    // faccio un ciclo che mi determina l'uscita del utente
    do
    {
        printf("\ninserisci il numero (0 per uscire): ");
        scanf("%d", &input);
        fflush(stdin);

        //sef
        if (input % 2 == 0)
        {
            somma_pari += input;
        }
        else
        {
            somma_dispari += input;
        }

    } while (input != 0);

    printf("\nla somma dei numeri pari e\' %d", somma_pari);
    printf("\nla somma dei numeri dispari e\' %d", somma_dispari);
    printf("\nla differenza tra le due somme e\' %d", somma_pari - somma_dispari);

    return 0;
}