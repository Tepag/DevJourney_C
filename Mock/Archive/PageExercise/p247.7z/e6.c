/*
visualizzazione di un trangolo di tartaglia

RECORD: 20m 51s
*/

#include <stdio.h>
#include <stdlib.h>

#define DIM 10

int main()
{
    int i = 0, j = 0;
    int out = 1;

    for (i = 0; i < DIM; i++)
    {
        for (j = DIM - 1; j > i; j--)
        {
            printf("  ");
        }
        for (j = 0; j < i; j++)
        {
            if (j == 0)
            {
                out = 1;
            }
            else
            {
                out = out * (i - j + 1) / j;
            }
            printf("%4d", out);
        }
        printf("\n");
    }
    //out=out*(i-j+1)/j

    return 0;
}