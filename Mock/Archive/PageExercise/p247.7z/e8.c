/*
generalizza lesercizio fatto precedentemente  facendolo oparare su n numeri

RECORD: 2m 58s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int cnt = 1;
    int n = 0;

    printf("inserire il range di cui si vuole la lista di numeri pari:");
    scanf("%d", &n);
    fflush(stdin);

    //incremento di voltain volta il cnt
    for (cnt = 1; cnt <= n; cnt++)
    {
        //verifico se il cnt è un numero pari e se lo è lo stampo
        if (cnt % 2 == 0)
        {
            printf("\n%0.3d ", cnt);
        }
    }

    return 0;
}