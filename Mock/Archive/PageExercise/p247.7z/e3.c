/*
conta il numero di volte in cui appare il numero 7 tra i numeri compresi da 1 e 100

RECORD: 6m 59s
*/

#include <stdio.h>
#include <stdlib.h>

int main()
{
    int i = 1;
    int cnt = 0;

    for (i = 1; i <= 100; i++)
    {
        if (i == 7)
        {
            cnt++;
            printf("%d ", i);
        }
        else
        {
            if (i % 10 == 7)
            {
                cnt++;
                printf("%d ", i);
            }
            else
            {
                if (i / 10 == 7)
                {
                    cnt++;
                    printf("%d ", i);
                }
            }
        }
    }
    printf("\nil numero di volte in cui e\' tstato trovato un sette e\' %d", cnt);

    return 0;
}