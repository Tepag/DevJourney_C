/*
realizza un programma che, partendo da un array che contiene i dati personali dei calciatori di una squadra
di calcio, permetta di calcolare:
- il totale dei goal segnati dalla squadra, specificando:
    - i goal segnati dagli attaccanti (numero maglia 7 a 11)
    - i goal segnati dai centrocampisti (numero da 4 a 6)
    - i goal segnati dai difensori (numero di maglia 1 a 3)
- il totale dei goal segnati dalla squadra. 
il programma inoltre deve visualizzare i dati personali di tutti i giocatori e per ognuno di essi memorizza:
- il numero di maglia
- il numero di goal segnati(se è il portiere)

RECORD: 52m 58s
*/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 11
#define R 2

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

void from_to_mat_per_riga(int mat[][DIM], int _riga, int _start, int _end);

void input_mat_per_riga(int mat[][DIM], int _riga);

int somma_per_range(int mat[][DIM], int _riga, int _start, int _end);

int main()
{
    int mat[R][DIM];
    int i = 0, j = 0;

    // 1. numero la riga 0 da 1 a 11 per segnare il numero del giocatore
    from_to_mat_per_riga(mat, 0, 1, 11);

    // 2. possibilità di inserire i goal segnati e subiti per ogni giocatore
    input_mat_per_riga(mat, 1);

    // 3. la visualizzazione del numero di maglia e i goal segnati o subiti in caso del portiere (n.1)
    //faccio scorrere le colonne
    for (i = 0; i < DIM; i++)
    {
        if (i == 0)
        {
            printf("\nil portiere (n.1) ha subito %d goal", mat[1][i]);
        }
        else
        {
            printf("\nil giocatore %d ha segnato %d goal", mat[0][i], mat[1][i]);
        }
    }

    // 4. visualizzazione dei goal per le varie parti. attaccanti, centrocampisti, difensori, portiere e totale
    printf("\nil numero di goal segnati dagli attaccanti: %d", somma_per_range(mat, 1, 7, 11));
    printf("\nil numero di goal segnati dai centrocampisti: %d", somma_per_range(mat, 1, 4, 6));
    printf("\nil numero di goal segnati dai difensori: %d", somma_per_range(mat, 1, 2, 3));
    printf("\nil numero di goal subiti: %d", somma_per_range(mat, 1, 1, 1));
    printf("\nil numero di goal segnati dalla squadra: %d", somma_per_range(mat, 1, 1, 11));

    return 0;
}

void from_to_mat_per_riga(int mat[][DIM], int _riga, int _start, int _end)
{
    int i = 0;
    int increase = (_end / DIM);
    for (i = 0; i < DIM; i++)
    {
        mat[_riga][i] = _start;
        _start += increase;
    }
}

void input_mat_per_riga(int mat[][DIM], int _riga)
{
    int i = 0;
    for (i = 0; i < DIM; i++)
    {
        if (i == 0)
        {
            printf("\ninserire i goal subiti: ");
            scanf("%d", &mat[_riga][i]);
            fflush(stdin);
        }
        else
        {
            printf("\ninserire i goal segnati dal giocatore %d: ", i + 1);
            scanf("%d", &mat[_riga][i]);
            fflush(stdin);
        }
    }
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.2d ", _m[i][j]);
        }
        printf("\n");
    }
}

int somma_per_range(int mat[][DIM], int _riga, int _start, int _end)
{
    int i = 0;
    int somma = 0;
    for (i = 0; i < DIM; i++)
    {
        if (i + 1 >= _start && i + 1 <= _end)
        {
            somma += mat[_riga][i];
        }
    }
    return somma;
}