/*
utente inserisce un due numeri per decidere la dimensione della matrice entro il raggio possibile di 10 x 20
il programma scambierà i valori delle righe pari con i valori delle righe dispari

RECORD: 32m 32s
*/

#include<stdlib.h>
#include<stdio.h>
#include<time.h>
#include"e1_lib.c"

#define N 10
#define M 20

int main(){
    srand(time(NULL));
    int mat[N][M];
    int y =0;
    int x=0;
    int i =0;
    int j=0;
    int tmp=0;

    printf("\ninserire il numero delle righe: ");
    scanf("%d", &y);
    fflush(stdin);

    printf("\ninserire il numero delle colonne: ");
    scanf("%d", &x);
    fflush(stdin);

    for (i=0; i<N; i++){
        for (j=0; j<M; j++){
            mat[i][j]=rand()%10;
        }
    }

    for (i=0; i<y; i++){
        for (j=0; j<x; j++){
            printf("%d ",mat[i][j]);
        }
        printf("\n");
    }

    for (i=0; i<y; i++){

        //faccio lo scambio tra la riga pari e quella successiva (dispari)
        if(y%2==0){
            for (j=0; j<x; j++){
                tmp=mat[i][j];
                mat[i+1][j]=mat[i][j];
                mat[i+1][j]=tmp;
            }
        }
    }

    for (i=0; i<y; i++){
        for (j=0; j<x; j++){
            printf("%d ",mat[i][j]);
        }
        printf("\n");
    }


    return 0;
}