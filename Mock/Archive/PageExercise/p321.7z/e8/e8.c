/*
dato il quadrato magico seguente, in cui la somma di righe,colonne e diagonali è uguale a 15, 
trovane uno diverso
4   9   2
3   5   7
8   1   6

RECORD: 29m 21s
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 3

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

int somma_a_tre(int *_p, int _d, int _choose1, int _choose2, int _choose3);

int main()
{
    int mat[DIM][DIM] = {4, 9, 2, 3, 5, 7, 8, 1, 6};
    int *p = &mat[0][0];
    stampaMat(mat, DIM, DIM);

    if (somma_a_tre(p, DIM, 0, 1, 2) != 15)
    {
        printf("la somma della prima riga non fa 15");
    }
    else
    {
        if (somma_a_tre(p, DIM, 3, 4, 5) != 15)
        {
            printf("la somma della seconda riga non fa 15");
        }
        else
        {
            if (somma_a_tre(p, DIM, 6, 7, 8) != 15)
            {
                printf("la somma della terza riga non fa 15");
            }
            else
            {
                if (somma_a_tre(p, DIM, 0, 4, 8) != 15)
                {
                    printf("la somma della diagonale che parte in alto a sinistra non fa 15");
                }
                else
                {
                    if (somma_a_tre(p, DIM, 2, 4, 6) != 15)
                    {
                        printf("la somma della diagonale che parte in alto a destra non fa 15");
                    }
                    else
                    {
                        printf("tutte le somme fanno 15");
                    }
                }
            }
        }
    }

    return 0;
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%0.2d ", _m[i][j]);
        }
        printf("\n");
    }
}

int somma_a_tre(int *_p, int _d, int _choose1, int _choose2, int _choose3)
{
    int somma = 0;
    for (int i = 0; i < _d * _d; i++)
    {
        if ((i == _choose1) || (i == _choose2) || (i == _choose3))
        {
            somma += *(_p + i);
        }
    }
    return somma;
}