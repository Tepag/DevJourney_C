/*
Data una matrice quadrata di ordine N, verifica se la matrice è diagonale, ricordando che una matrice si
dice diagonale se A[i][j] = 0 quando i <> j

RECORD: 30m 02s
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 3

/*funzione che riempie le celle della matrice con numeri da tastiera/utente
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void inputMat(int _m[][DIM], int _r, int _c);

/*funzione che stampa una matrice di interi
@param int[][] Matrice da inizializzare
@param int Numero di righe della matrice.
@param int NUmero di colonne della matrice.
@return void
*/
void stampaMat(int _m[][DIM], int _r, int _c);

/*funzione che data in entrata una matrice e le sue dimensione ritorna 0 o 1 verificando se è diagonale o meno
@param int[][] matrice in entrata
@param int la lunghezza della matrice
@param int altezza della matrice
@return int 0-->falso 1-->vero
*/
int verifica_matrice_diagonale(int[][DIM], int, int);

int main()
{
    int mat[DIM][DIM] /*= {1, 0, 0, 0, 1, 0, 0, 0, 1}*/;

    inputMat(mat, DIM, DIM);

    stampaMat(mat, DIM, DIM);

    if (verifica_matrice_diagonale(mat, DIM, DIM) == 1)
    {
        printf("la matrice risulta diagonale");
    }
    else
    {
        printf("la matrice non risulta diagonale");
    }

    return 0;
}

void inputMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("\ninserisci il numero per la cella %d %d: ", i, j);
            scanf("%d", &_m[i][j]);
            fflush(stdin);
        }
    }
}

void stampaMat(int _m[][DIM], int _r, int _c)
{
    int i, j;
    for (i = 0; i < _r; i++)
    {
        for (j = 0; j < _c; j++)
        {
            printf("%3d", _m[i][j]);
        }
        printf("\n");
    }
}

int verifica_matrice_diagonale(int _m[][DIM], int _l, int _h)
{
    int i = 0, j = 0;
    int flag_if_not = 0;
    for (i = 0; i < _l; i++)
    {
        for (j = 0; j < _h; j++)
        {
            //se i diverso da j e questi non fanno zero attivo un flag
            if ((i != j) && (_m[i][j] != 0))
            {
                flag_if_not++;
            }
        }
    }
    if (flag_if_not == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}