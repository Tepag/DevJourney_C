/*
supponi di avere in memoria una matrice rettangolare M x N di numeri interi indicati l'altezza di alcune
persone. qual'è  la persona più alta: la più bassa tra le più alte di ogni riga, oppure la più bassa tra le più
basse di ogni colonna


RECORD:
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define M 5
#define N 10

int main()
{
    srand(time(NULL));
    int mat[M][N];
    int i = 0, j = 0;
    int *p = &mat[0][0];
    int max = 0;

    for (i = 0; i < M * N; i++)
    {
        *(p + i) = rand() % 99;
    }

    for (i = 0; i < M * N; i++)
    {
        if (max < *(p + i))
        {
            max = *(p + i);
        }
    }
    printf("all: %d", max);

    //cerco il massimo tra le righe
    for (i = 0; i < M; i++)
    {
        max = 0;
        for (j = 0; j < N; j++)
        {
            if (max < mat[i][j])
            {
                max = mat[i][j];
            }
        }
        printf("il massimo della riga %d e\': %d\n", i, max);
    }

    //cerco il massimo tra le colonne
    for (i = 0; i < N; i++)
    {
        max = 0;
        for (j = 0; j < M; j++)
        {
            if (max < mat[j][i])
            {
                max = mat[j][i];
            }
        }
        printf("il massimo della colonna %d e\': %d\n", i, max);
    }
}