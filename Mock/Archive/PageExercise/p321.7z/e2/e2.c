/*
scrivi un programma che egge da tastiera due matrici A e B di N x N e calcola la somma C = A + B
e il prodotto D = A * B visualizzando le matrici ottenute

RECORD: 22m 53s
*/

#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define N 5

void stampamat(int _m[][N], int, int);

int main(){
    srand(time(NULL));
    int i =0;
    int j= 0;
    int A[N][N];
    int B[N][N];
    int C[N][N];
    int D[N][N];

    for (i=0;i<N;i++){
        for(j=0;j<N;j++){
            A[i][j]=rand()%10+1;
            B[i][j]=rand()%10+1;
        }
    }

    for (i=0;i<N;i++){
        for(j=0;j<N;j++){
            C[i][j]=A[i][j]+B[i][j];
            D[i][j]=A[i][j]*B[i][j];
        }
    }
    printf("\n\nA:\n");
    stampamat(A, N, N);
    printf("\n\nB:\n");

    stampamat(B, N, N);
    printf("\n\nle somme:\n");

    stampamat(C, N, N);
    printf("\n\ni prodotti:\n");

    stampamat(D, N, N);

    return 0;
}

void stampamat(int _m[][N], int _h, int _w){
    int i=0;
    int j=0;
    for (i=0;i<_h;i++){
        for(j=0;j<_w;j++){
            printf("%0.2d ",_m[i][j]);
        }
        printf("\n");
    }
}