/*
Data una matrice N*M interi (Nrighe, M colonne):
int mat [N,M] = {3,5,7,9,0,7,2,2,8,9,3,2,8,2,2,2,4,5};
scrivi un programma che acquisisca da input due interi, RIGA e COLONNA, e calcoli la somma di tutti gli elementi
della sotto matrice ottenuta da mat eliminando la riga e la colonna indicata da RIGA e COLONNA
rispettivamente (cioè la somma di tutti dli elementi di mat a eccezione di quelli appartenentu alla riga 
oppure alla colonna)

RECORD: 17m 52s
*/
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"e5_lib.c"

#define N 3
#define M 6

int main(){
    int mat[N][M] = {3,5,7,9,0,7,2,2,8,9,3,2,8,2,2,2,4,5};
    int i=0,j=0;
    int riga=0, colonna=0;
    int somma=0;
    int* p= &mat[0][0];

    printf("inserire il numero della riga da escludere nel calcolo della somma:");
    scanf("%d", &riga);
    fflush(stdin);

    printf("inserire il numero della colonna da escludere nel calcolo della somma:");
    scanf("%d", &colonna);
    fflush(stdin);

    //sistema di filtro per la somma
    for(i=0;i<N;i++){
        //escludo la riga scelta
        if(i!=riga){
            for(j=0;j<M;j++){
                //escludo la colonna scelta
                if(j!=colonna){
                    somma+=mat[i][j];
                }
            }
        }
    }

    //visualizzazione del vettore tramite puntatore
    for(i=0;i<N*M;i++){
        printf("%2d ", *(p+i));
        if((i+1)%M==0){
            printf("\n");
        }
    }

    printf("la somma viene di: %d", somma);
    return 0;
}
