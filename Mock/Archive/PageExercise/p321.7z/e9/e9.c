/*
leggi i tempi di 30 concorrenti per due manche di una gara di sci. Dopo la prima manche i concorrenti
scendono in ordine inverso rispetto ai tempi ottenuti: leggi i tempi della seconda manche e calcola
il tempo totale, quindi visualizza il podio finale (posizione, nome e tempo totale in formato MM SS)

RECORD:
*/

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define DIM 30
#define RIGHE 4
/* matrice organizzata in modo tale che ci sia per colonna i minuti e i secondi delle due manche
12m |   ...
04s |   ...
14m |   ...
56s |   ...
*/

void inserimento_per_colonna_min_sec(int[][DIM], int);

void somma_due_tempi(int, int, int, int);

int main()
{
    int mat[RIGHE][DIM];
    inserimento_per_colonna(mat, DIM);

    return 0;
}

void inserimento_per_colonna_min_sec(int _mat[][DIM], int _lenght)
{
    int _height = 2;
    int i = 0, j = 0;
    for (i = 0; i < _lenght; i++)
    {
        for (j = 0; j < _height; j++)
        {
            if (((j + 1) % 2) != 0)
            {
                printf("\ninserire i minuti del partecipante n.%d: ", i);
                scanf("%d", &_mat[i][j]);
                fflush(stdin);
            }
            else
            {
                printf("\ninserire i secondi del partecipante n.%d: ", i);
                scanf("%d", &_mat[i][j]);
                fflush(stdin);
            }
        }
    }
}

void somma_due_tempi(int _m1, int _s1, int _m2, int _s2)
{
    int riporto = (_s1 += _s2) / 60;
    printf("%dm %ds ", (_m1 + _m2 + (1 * riporto)), (_s1 + _s2 - (60 * riporto)));
}