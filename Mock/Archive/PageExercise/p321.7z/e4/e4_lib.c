#include<stdio.h>
#include<stdlib.h>
//#include<conio.h>
#include<time.h>
#include"e4_lib.h"

void input_mat(int *_m, int _d, int _start, int _end){
    srand(time(NULL));
    int i=0;
    for(i=0;i<_d;i++){
        printf("\ninserisci il numero nel posto n.%d:", i+1);
        scanf("%d",&*(_m+i));
        fflush(stdin);
    }
    /*
    for(i=0;i<_d;i++){
        *(_m+i)=rand()%(_end - _start + 1)+_start;
    }
    */
}

void stmpmat(int *_m, int _d, int _l){
    int i=0;
    for(i=0;i<_d;i++){
        printf("%0.2d ",*(_m+i));
        
        if((i+1)%_l==0){
            printf("\n");
        }
        
    }
}