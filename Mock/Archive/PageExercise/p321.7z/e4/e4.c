/*
data una matrice con N coppie di numeri interi, individua se sono punti di una funzione:
pari: diagramma simmetrica rispetto alle asse delle ordinate f(-x) = f(x)
dispari: diagramma simmetrica rispetto all


RECORD: 1h 04m 52s
*/
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include"e4_lib.c"

#define DIM 5
#define COUPLE 2

int main(){
    int mat[DIM][COUPLE];
    int i=0;
    int j=0;
    int* p= &mat[0][0];
    input_mat(p, COUPLE*DIM, -9, 9);
    //stmpmat(p,COUPLE*DIM, COUPLE);

    for(i=0;i<DIM;i++){
        //se pari
        if(mat[i][0]%2==0){
            if(-mat[i][0] == mat[i][1]){
                printf("%3d %3d -> coppia adattata alla funzione f(-x) = f(x)\n", mat[i][0],mat[i][1]);
            }
            else{
                printf("%3d %3d -> coppia non adattata alla funzione f(-x) = f(x)\n", mat[i][0], mat[i][1]);
            }
        }

        //se dispari
        else{
            if(-mat[i][0] == (mat[i][1]*(-1))){
                printf("%3d %3d -> coppia adattata alla funzione f(-x) = -f(x)\n",mat[i][0], mat[i][1]);
            }
            else{
                printf("%3d %3d -> coppia non adattata alla funzione f(-x) = -f(x)\n", mat[i][0], mat[i][1]);
            } 
        }
    }
    return 0;
}