/*Funzione che serve per dare i input iniziali
@param int* puntatore che punta alla cella 0,0 della matrice
@param int la dimensione ottenuta dal prodotto delle due dimensione della matrice
@param int inizio range random (disattivato)
@param int fine range random (disattivato)
@return void
*/
void input_mat(int *_m, int _d, int _start, int _end){

/*Funzione che serve per dare i input iniziali
@param int* puntatore che punta alla cella 0,0 della matrice
@param int la dimensione ottenuta dal prodotto delle due dimensione della matrice
@param int il numero delle celle per riga (es. se si inserisce 3 si stamperà 3 numeri a riga)
@return void
*/
void stmpmat(int *_m, int _d, int _l);
