/*
scrivi un programma che legge una matrice A (MxP) e una matrice B (PxN) e calcolare la matrice C prodotto 
dalle due matrici:
La matrice C è delle dimensione M x N

RECORD: 31m 12s
*/

#include<stdio.h>
#include<stdlib.h>
//#include<conio.h>
#include<time.h>
#include"e3_lib.c"

#define M 2
#define P 3
#define N 4

int main(){
    int a[M][P];
    int b[P][N];
    int c[M][N];

    int i=0;
    int j=0;

    int *p;

    p = &a[0][0];
    randmat(p, M*P, 1, 9);
    stmpmat(p, M*P, P);

    printf("\n\n");

    p = &b[0][0];
    randmat(p, P*N, 1, 9);
    stmpmat(p, P*N, N);

    printf("\n\n");

    //il calcolo
    for(i=0; i<M; i++){
        for(j=0; j<N; j++){
            c[i][j] = a[i][j] * b[i][j];
        }
    }
    p = &c[0][0];
    stmpmat(p, M*N, N);

    return 0;

}

