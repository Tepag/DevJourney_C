/*funzione che randomizza una matrice di interi tramite puntatori
@param int* indirizzo prima cella della matrice
@param int dimensione della matrice data dal prodotto delle due dimensioni
@param int numero minimo del range randomizzato
@param int numero massimo del range randomizzato
@return void
*/
void randmat(int *, int, int, int);